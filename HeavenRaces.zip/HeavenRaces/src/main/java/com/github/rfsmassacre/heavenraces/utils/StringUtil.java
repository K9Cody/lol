package com.github.rfsmassacre.heavenraces.utils;

import java.util.Arrays;
import java.util.List;

public class StringUtil
{
    public static String formatTime(int timeInSeconds)
    {
        int hours = timeInSeconds / 3600;
        int secondsLeft = timeInSeconds - hours * 3600;
        int minutes = secondsLeft / 60;
        int seconds = secondsLeft - minutes * 60;

        String formattedTime = "";

        if (hours > 0)
        {
            if (hours == 1)
            {
                formattedTime += hours + " Hour, ";
            }
            else
            {
                formattedTime += hours + " Hours, ";
            }
        }

        if (minutes > 0)
        {
            if (minutes == 1)
            {
                formattedTime += minutes + " Minute, ";
            }
            else
            {
                formattedTime += minutes + " Minutes, ";
            }
        }

        if (seconds == 1)
        {
            formattedTime += seconds + " Second";
        }
        else
        {
            formattedTime += seconds + " Seconds";
        }

        return formattedTime;
    }

    public static List<String> toStringList(String string)
    {
        String stringList = string.substring(1, string.length() - 1);
        return Arrays.asList(stringList.split(", "));
    }
}
