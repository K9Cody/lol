package com.github.rfsmassacre.heavenraces.players;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.sk89q.worldguard.protection.flags.StateFlag;
import lombok.Getter;
import lombok.Setter;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.KeybindComponent;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Getter
@Setter
public abstract class Origin implements Comparable<Origin>
{
    public enum Race
    {
        HUMAN,
        VAMPIRE,
        WEREWOLF,
        ANGEL,
        DEMON;

        public static Race fromString(String name)
        {
            try
            {
                return Race.valueOf(name.toUpperCase());
            }
            catch (IllegalArgumentException exception)
            {
                return null;
            }
        }

        public NamespacedKey getKey(String key)
        {
            return new NamespacedKey("heavenraces", this.name().toLowerCase() + "." + key);
        }
    }

    public enum KeyBind
    {
        //Default
        DROP("key.drop"),
        SWAP("key.swapOffhand"),
        LEFT_CLICK("key.attack"),
        RIGHT_CLICK("key.use");

        private final String key;

        KeyBind(String key)
        {
            this.key = key;
        }

        public KeybindComponent getComponent()
        {
            return Component.keybind(key);
        }

        public static KeyBind fromString(String name)
        {
            try
            {
                return KeyBind.valueOf(name);
            }
            catch (IllegalArgumentException exception)
            {
                return null;
            }
        }
    }

    @Getter
    public static class RaceFlag extends StateFlag
    {
        private static final Map<Race, RaceFlag> FLAGS = new HashMap<>();

        public static Set<RaceFlag> getFlags()
        {
            return new HashSet<>(FLAGS.values());
        }

        public static void loadFlags()
        {
            for (Race race : Race.values())
            {
                FLAGS.put(race, new RaceFlag(race));
            }
        }

        public static RaceFlag getFlag(Race race)
        {
            return FLAGS.get(race);
        }

        private final Race race;

        public RaceFlag(Race race)
        {
            super(race.toString().toLowerCase(), false);

            this.race = race;
        }
    }

    @Getter
    public static class Leader
    {
        private final UUID leaderId;
        private final Race race;
        private Clan clan;

        public Leader(UUID playerId, Race race)
        {
            this.leaderId = playerId;
            this.race = race;
        }

        public Leader(UUID playerId, Clan clan)
        {
            this.leaderId = playerId;
            this.race = Race.WEREWOLF;
            this.clan = clan;
        }
    }

    protected UUID playerId;
    protected Race race;
    protected String displayName;
    protected String name;
    protected double lastHealth;
    protected double lastMaxHealth;
    protected Map<Race, Double> levels;
    protected long lastLogin;
    protected int corruption;
    protected boolean abilityActive;
    protected final Set<String> talentNames;
    protected final Map<KeyBind, String> spells;

    /*
     * This is intended to be used to load player data.
     */
    public Origin()
    {
        this.levels = new HashMap<>();
        this.talentNames = new HashSet<>();
        this.spells = new HashMap<>();
        this.abilityActive = false;
        this.corruption = 0;
    }

    /*
     * This is intended to convert a player into a race player.
     */
    public Origin(Player player, Race race)
    {
        this();

        this.playerId = player.getUniqueId();
        this.race = race;
        this.name = player.getName();
        setDisplayName(player.getDisplayName());
        this.lastLogin = System.currentTimeMillis();
        this.lastHealth = player.getHealth();
    }

    public Origin(Origin origin)
    {
        this();

        this.playerId = origin.playerId;
        this.levels = origin.levels;
        this.race = origin.race;
        this.name = origin.name;
        setDisplayName(origin.displayName);
        this.lastLogin = origin.lastLogin;
        this.lastHealth = origin.lastHealth;
        this.lastMaxHealth = origin.lastMaxHealth;
        this.abilityActive = origin.abilityActive;
    }

    public Spell getSpell(KeyBind key)
    {
        String spellName = spells.get(key);
        if (spellName == null)
        {
            return null;
        }

        return Spell.getSpell(spellName);
    }

    /*
     * GETTERS/SETTERS
     */
    public Player getPlayer()
    {
        return Bukkit.getPlayer(playerId);
    }

    public void setPlayer(Player player)
    {
        this.playerId = player.getUniqueId();
        setDisplayName(player.getDisplayName());
    }

    public boolean isOnline()
    {
        return getPlayer() != null;
    }

    public String getDisplayName()
    {
        Player player = getPlayer();
        if (player != null)
        {
            this.displayName = player.getDisplayName();
            return player.getDisplayName();
        }

        return displayName != null ? LocaleData.format(displayName) : null;
    }

    public String getName()
    {
        Player player = getPlayer();
        if (player != null)
        {
            this.name = player.getName();
        }

        return name;
    }

    public void setDisplayName(String displayName)
    {
        this.displayName = LocaleData.undoFormat(displayName);
    }

    public void setCorruption(int corruption)
    {
        this.corruption = Math.max(0, Math.min(corruption, 100));
    }

    public void addCorruption(int corruption)
    {
        setCorruption(this.corruption + corruption);
    }

    public void addLevel(double level)
    {
        levels.put(race, getLevel() + level);
    }

    public double getLevel()
    {
        return levels.getOrDefault(race, 0.0);
    }

    public int getLevelProgress()
    {
        double level = getLevel();
        return (int) ((level - (int) level) * 100);
    }

    public void setLevel(double level)
    {
        this.levels.put(race, level);
    }

    public Set<Talent> getTalents()
    {
        Set<Talent> talents = new HashSet<>();
        for (String talentName : talentNames)
        {
            Talent talent = Talent.get(talentName);
            if (talent != null)
            {
                talents.add(talent);
            }
        }

        return talents;
    }

    public boolean hasTalent(Talent talent)
    {
        return hasTalent(talent.getInternalName());
    }

    public boolean hasTalent(String internalName)
    {
        return talentNames.contains(internalName);
    }

    public Talent getTalent(String internalName)
    {
        if (hasTalent(internalName))
        {
            return Talent.get(internalName);
        }

        return null;
    }

    public void addTalent(Talent talent)
    {
        this.talentNames.add(talent.getInternalName());
    }

    public void removeTalent(String internalName)
    {
        this.talentNames.remove(internalName);
    }

    public boolean offlineFor(long hours)
    {
        if (getPlayer() != null)
        {
            return false;
        }

        // Calculate days between last login and now
        long offlineHours = Instant.ofEpochMilli(lastLogin).until(Instant.now(), ChronoUnit.HOURS);
        Bukkit.getLogger().info(name + " has been offline for " + offlineHours + " hours");
        return offlineHours > hours;
    }

    public abstract void updateStats();

    protected void updateStats(String raceKey)
    {
        clearStats();
        Player player = getPlayer();
        if (player == null)
        {
            return;
        }

        PaperConfiguration config = HeavenRaces.getInstance().getConfiguration();
        ConfigurationSection section = config.getSection("attributes." + race.toString().toLowerCase() + "." +
                raceKey);
        for (String key : section.getKeys(false))
        {
            try
            {
                AttributeModifier.Operation operation = AttributeModifier.Operation.valueOf(section.getString(key +
                        ".operation"));
                double amount = section.getDouble(key + ".amount");
                Attribute attribute = Registry.ATTRIBUTE.getOrThrow(Key.key("minecraft", key.toLowerCase()));
                AttributeModifier modifier = new AttributeModifier(race.getKey(raceKey), amount, operation);
                player.getAttribute(attribute).addTransientModifier(modifier);
            }
            catch (Exception exception)
            {
                //Do nothing.
            }
        }
    }

    public void clearStats()
    {
        Player player = getPlayer();
        if (player == null)
        {
            return;
        }

        for (Attribute attribute : Registry.ATTRIBUTE)
        {
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance != null)
            {
                for (AttributeModifier modifier : new ArrayList<>(instance.getModifiers()))
                {
                    if (modifier.getKey().getNamespace().equals("heavenraces"))
                    {
                        instance.removeModifier(modifier);
                    }
                }
            }
        }
    }

    /*
     * To String
     */
    @Override
    public String toString()
    {
        String info = " ";
        info += "\n\n&7" + playerId.toString();
        info += "\n&f" + displayName;
        return info;
    }

    @Override
    public int compareTo(@NotNull Origin other)
    {
        return Double.compare(this.getLevel(), other.getLevel());
    }
}
