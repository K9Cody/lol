package com.github.rfsmassacre.heavenraces.tasks.werewolves;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Getter
@Setter
public class RabiesTask extends BukkitRunnable
{
    private final Map<UUID, List<RabiesTask>> rabiesTasks;
    private final LivingEntity entity;
    private final Werewolf werewolf;
    private double percent;
    private int times;
    private double level;
    private BukkitTask task;

    public RabiesTask(Map<UUID, List<RabiesTask>> rabiesTasks, LivingEntity entity, Werewolf werewolf, double percent,
                      int times, int level)
    {
        this.rabiesTasks = rabiesTasks;
        this.entity = entity;
        this.werewolf = werewolf;
        this.percent = percent;
        this.times = times;
        this.level = level;
    }

    @Override
    public boolean isCancelled()
    {
        return task == null || task.isCancelled();
    }

    public void updateTimer(int times, int interval)
    {
        this.times = times;
        if (isCancelled())
        {
            this.task = this.runTaskTimer(HeavenRaces.getInstance(), interval, interval);
        }
    }

    @Override
    public void run()
    {
        List<RabiesTask> tasks = rabiesTasks.getOrDefault(entity.getUniqueId(), new ArrayList<>());
        if (times <= 0 || entity.isDead() || werewolf.getPlayer() == null)
        {
            tasks.remove(this);
            if (tasks.isEmpty())
            {
                rabiesTasks.remove(entity.getUniqueId());
            }

            this.cancel();
            return;
        }

        AttributeInstance attribute = entity.getAttribute(Attribute.MAX_HEALTH);
        if (attribute == null)
        {
            tasks.remove(this);
            if (tasks.isEmpty())
            {
                rabiesTasks.remove(entity.getUniqueId());
            }

            this.cancel();
            return;
        }

        entity.damage((attribute.getValue() * percent) * level,
                DamageSource.builder(DamageType.INDIRECT_MAGIC)
                        .withDirectEntity(werewolf.getPlayer())
                        .withCausingEntity(werewolf.getPlayer())
                        .build());
        entity.getWorld().spawnParticle(Particle.SPIT, entity.getEyeLocation().subtract(0, 0.25, 0), 1,
                0.1, 0.1, 0.1);
        entity.getWorld().spawnParticle(Particle.BUBBLE, entity.getEyeLocation().subtract(0, 0.25, 0), 1,
                0.1, 0.1, 0.1);
        times--;
    }
}
