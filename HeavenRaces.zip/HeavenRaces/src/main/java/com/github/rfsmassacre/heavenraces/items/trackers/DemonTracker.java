package com.github.rfsmassacre.heavenraces.items.trackers;

import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import org.bukkit.inventory.Recipe;

public class DemonTracker extends TrackerItem
{
    public DemonTracker()
    {
        super("DemonTracker", Race.DEMON);
    }

    @Override
    protected Recipe createRecipe()
    {
        return null;
    }
}
