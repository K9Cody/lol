package com.github.rfsmassacre.heavenraces.items;

import org.bukkit.Material;
import org.bukkit.inventory.Recipe;

public class Ash extends RaceItem
{
    public Ash()
    {
        super("Ash", Material.GUNPOWDER);
    }

    @Override
    protected Recipe createRecipe()
    {
        return null;
    }
}
