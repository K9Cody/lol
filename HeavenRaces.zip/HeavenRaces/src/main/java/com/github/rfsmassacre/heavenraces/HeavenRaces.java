package com.github.rfsmassacre.heavenraces;

import com.codingforcookies.armorequipevent.ArmorListener;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.github.rfsmassacre.heavenlibrary.paper.HeavenPaperPlugin;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenlibrary.paper.managers.PaperTextManager;
import com.github.rfsmassacre.heavenraces.commands.*;
import com.github.rfsmassacre.heavenraces.listeners.*;
import com.github.rfsmassacre.heavenraces.managers.*;
import com.github.rfsmassacre.heavenraces.placeholders.Placeholders;
import com.github.rfsmassacre.heavenraces.players.Origin.RaceFlag;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.worldmap.WorldMapUtil;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.registry.FlagRegistry;
import lombok.Getter;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;

@Getter
public final class HeavenRaces extends HeavenPaperPlugin
{
    @Getter
    public enum ConfigType
    {
        CONFIG("config.yml"),
        ITEMS("items.yml"),
        TALENTS("talents.yml"),
        SPELLS("spells.yml");

        private final String fileName;

        ConfigType(String fileName)
        {
            this.fileName = fileName;
        }
    }

    /*
    private PaperConfiguration configuration;
     * INSTANCE
     */
    @Getter
    private static HeavenRaces instance;

    /*
     * INITIALIZE
     */
    private PaperTextManager textManager;
    private RaceManager raceManager;
    private SkinManager skinManager;
    private LeaderManager leaderManager;
    private ItemManager itemManager;
    private MoonManager moonManager;
    private TaskManager taskManager;
    private ProtocolManager protocolManager;

    @Override
    public void onLoad()
    {
        instance = this;;
        RaceFlag.loadFlags();
        FlagRegistry registry = WorldGuard.getInstance().getFlagRegistry();
        for (RaceFlag flag : RaceFlag.getFlags())
        {
            try
            {
                registry.register(flag);
                getServer().getLogger().info(flag.getName() + " Flag has been registered to WorldGuard!");
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
        }
    }

    @Override
    public void onEnable()
    {
        getDataFolder().mkdirs();

        //Load managers
        addYamlManager(new PaperConfiguration(this, "", "config.yml", true));
        addYamlManager( new PaperConfiguration(this, "", "items.yml", true));
        addYamlManager(new PaperConfiguration(this, "", "talents.yml", true));
        addYamlManager(new PaperConfiguration(this, "", "spells.yml", true));
        addYamlManager(new PaperLocale(this, "", "locale.yml", true));
        this.raceManager = new RaceManager();
        this.skinManager = new SkinManager();
        this.leaderManager = new LeaderManager();
        this.itemManager = new ItemManager();
        this.moonManager = new MoonManager();
        this.taskManager = new TaskManager();
        this.textManager = new PaperTextManager(this, "menus");

        //Load listeners
        PluginManager plugins = getServer().getPluginManager();
        plugins.registerEvents(new PlayerListener(), this);
        plugins.registerEvents(new RaceListener(), this);
        plugins.registerEvents(new VampireListener(), this);
        plugins.registerEvents(new WerewolfListener(), this);
        plugins.registerEvents(new SpiritListener(), this);
        plugins.registerEvents(new AngelListener(), this);
        plugins.registerEvents(new DemonListener(), this);
        plugins.registerEvents(new ItemListener(), this);
        plugins.registerEvents(new ArmorListener(), this);
        plugins.registerEvents(new XPListener(), this);
        plugins.registerEvents(new TalentListener(), this);
        plugins.registerEvents(new KeyBindListener(), this);

        //Register commands
        getCommand("race").setExecutor(new RaceCommand());
        getCommand("raceadmin").setExecutor(new AdminCommand());
        getCommand("vampire").setExecutor(new VampireCommand());
        getCommand("werewolf").setExecutor(new WerewolfCommand());
        getCommand("human").setExecutor(new HumanCommand());
        getCommand("angel").setExecutor(new AngelCommand());
        getCommand("demon").setExecutor(new DemonCommand());
        getCommand("clock").setExecutor(new ClockCommand());
        getCommand("talent").setExecutor(new TalentCommand());
        getCommand("spawn").setExecutor(new SpawnCommand());
        getCommand("keybind").setExecutor(new KeybindCommand());

        //Placeholders
        if (plugins.isPluginEnabled("PlaceholderAPI"))
        {
            new Placeholders(this).register();
        }

        Spell.loadSpells();
        leaderManager.loadLeaders();
        Talent.reloadData();
        raceManager.loadSpawns(false);
        if (plugins.isPluginEnabled("Squaremap"))
        {
            WorldMapUtil.registerSpawns();
        }

        if (plugins.isPluginEnabled("ProtocolLib"))
        {
            protocolManager = ProtocolLibrary.getProtocolManager();
            protocolManager.addPacketListener(new PacketAdapter(this, PacketType.Play.Client.USE_ENTITY,
                    PacketType.Play.Client.ARM_ANIMATION)
            {
                @Override
                public void onPacketReceiving(PacketEvent event)
                {
                    Player player = event.getPlayer();
                    ItemStack item = player.getInventory().getItemInMainHand();
                    if (player.getCooldown(item.getType()) > 0)
                    {
                        event.setCancelled(true);
                        player.playSound(player, Sound.ENTITY_PLAYER_ATTACK_WEAK, 0.5F, 1.5F);
                    }
                }
            });
        }
    }

    @Override
    public void onDisable()
    {
        //Save all online players
        raceManager.updateOrigins(false);
        raceManager.clearOrigins();
        leaderManager.saveLeaders();
        taskManager.cancelTasks();

        //Unregister all listeners
        HandlerList.unregisterAll(this);
    }

    public PaperConfiguration getConfiguration(ConfigType type)
    {
        return getYamlManager(type.getFileName(), PaperConfiguration.class);
    }
}
