package com.github.rfsmassacre.heavenraces.tasks.demon;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.PhaseFormEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class HoverTask extends BukkitRunnable
{
    private static final String KEY = "spirit.stamina";
    private final PaperConfiguration config;
    private final RaceManager races;

    public HoverTask()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @Override
    public void run()
    {
        for (Demon demon : races.getOrigins(Demon.class))
        {
            Player player = demon.getPlayer();
            if (player == null)
            {
                BossBarUtil.removeBossBar(KEY, demon.getPlayerId());
                continue;
            }

            if (demon.isSpiritForm() && demon.isPhaseForm() && demon.getStamina() > 0.0 &&
                    demon.getPossessedId() == null)
            {
                double strength = config.getDouble("demon.spirit-form.glide");
                double terminal = config.getDouble("demon.spirit-form.terminal");
                Vector direction = player.getEyeLocation().getDirection().normalize().setY(0);
                double length = Math.max(strength, Math.min(player.getVelocity().length() + strength, terminal));
                player.setVelocity(direction.multiply(length));
                double newLength = player.getVelocity().length();
                double stamina = config.getDouble("demon.spirit-form.stamina.loss");
                demon.addStamina(-(stamina * newLength));
                if (demon.getStamina() <= 0)
                {
                    PhaseFormEvent event = new PhaseFormEvent(demon, false);
                    Bukkit.getPluginManager().callEvent(event);
                }
            }
            else if (!demon.isPhaseForm() && demon.getStamina() < 1.0)
            {
                double stamina = config.getDouble("demon.spirit-form.stamina.gain");
                demon.addStamina(stamina);
            }

            if (demon.getStamina() < 1.0)
            {
                BossBarUtil.updateBossBar(player, demon.getStamina(), KEY);
            }
            else
            {
                BossBarUtil.removeBossBar(KEY, player.getUniqueId());
            }
        }
    }
}