package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.SpiritFormEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.managers.SkinManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Spirit;
import com.github.rfsmassacre.heavenraces.tasks.LocationTask;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.metadata.FixedMetadataValue;

public class SpiritListener implements Listener
{
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;
    private final SkinManager skins;

    public SpiritListener()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.locale = HeavenRaces.getInstance().getLocale();
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.skins = HeavenRaces.getInstance().getSkinManager();
    }

    /*
     * Ensure everything goes consistently when spirits transform.
     */
    @EventHandler(ignoreCancelled = true)
    public void onSpiritTransform(SpiritFormEvent event)
    {
        Spirit spirit = event.getSpirit();
        String race = spirit.getRace().toString().toLowerCase();
        Player player = spirit.getPlayer();
        if (event.isToggled())
        {
            if (player.isDead())
            {
                return;
            }

            skins.applySkin(player, skins.getSkin(spirit), () ->
            {
                spirit.setSpiritForm(true);
                player.setAllowFlight(true);
                player.setFlySpeed((float) config.getDouble(race + ".spirit-form.speed.fly"));
                player.setWalkSpeed((float) config.getDouble(race + ".spirit-form.speed.walk"));
                AttributeInstance scale = player.getAttribute(Attribute.SCALE);
                scale.setBaseValue(scale.getDefaultValue() * config.getDouble(race + ".spirit-form.scale.size"));
                AttributeInstance interactRange = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
                interactRange.setBaseValue(interactRange.getDefaultValue() *
                        config.getDouble(race + ".spirit-form.scale.reach"));
                AttributeInstance blockRange = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
                blockRange.setBaseValue(blockRange.getDefaultValue() *
                        config.getDouble(race + ".spirit-form.scale.reach"));
                locale.sendLocale(player, true, race + ".spirit-form.enabled");
                Location last = LocationTask.LOCATIONS.get(player.getUniqueId());
                if (last != null && last.getWorld().equals(player.getWorld()))
                {
                    player.setMetadata("teleport", new FixedMetadataValue(HeavenRaces.getInstance(),
                            "transform"));
                    last.setYaw(player.getYaw());
                    last.setPitch(player.getPitch());
                    player.teleport(last, PlayerTeleportEvent.TeleportCause.PLUGIN);
                    player.removeMetadata("teleport", HeavenRaces.getInstance());
                }
            });
        }
        else
        {
            if (player.getWorld().getName().toLowerCase().contains("heaven"))
            {
                locale.sendLocale(player, true, race + ".spirit-form.cant-toggle");
                return;
            }

            skins.removeSkin(player, () ->
            {
                spirit.setSpiritForm(false);
                player.setFlying(false);
                player.setAllowFlight(false);
                player.setFlySpeed(0.2F);
                player.setWalkSpeed(0.2F);
                player.setGliding(false);
                AttributeInstance scale = player.getAttribute(Attribute.SCALE);
                scale.setBaseValue(scale.getDefaultValue());
                AttributeInstance interactRange = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
                interactRange.setBaseValue(interactRange.getDefaultValue());
                AttributeInstance blockRange = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
                blockRange.setBaseValue(blockRange.getDefaultValue());
                locale.sendLocale(player, true, race + ".spirit-form.disabled");
                Location last = LocationTask.LOCATIONS.get(player.getUniqueId());
                if (last != null && last.getWorld().equals(player.getWorld()))
                {
                    player.setMetadata("teleport", new FixedMetadataValue(HeavenRaces.getInstance(),
                            "transform"));
                    last.setYaw(player.getYaw());
                    last.setPitch(player.getPitch());
                    player.teleport(last, PlayerTeleportEvent.TeleportCause.PLUGIN);
                    player.removeMetadata("teleport", HeavenRaces.getInstance());
                }
            });
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpiritHit(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (!(origin instanceof Spirit spirit))
        {
            return;
        }

        if (spirit.isSpiritForm() && event.getCause().equals(EntityDamageEvent.DamageCause.FLY_INTO_WALL))
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpiritHunger(FoodLevelChangeEvent event)
    {
        Player player = (Player) event.getEntity();
        Spirit spirit = races.getOrigin(player.getUniqueId(), Spirit.class);
        if (spirit != null && spirit.isSpiritForm() && event.getFoodLevel() <= player.getFoodLevel())
        {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onSpiritRespawn(PlayerRespawnEvent event)
    {
        Player player = event.getPlayer();
        Spirit spirit = races.getOrigin(player.getUniqueId(), Spirit.class);
        if (spirit != null && spirit.isSpiritForm())
        {
            player.setAllowFlight(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpiritWorldChange(PlayerChangedWorldEvent event)
    {
        Player player = event.getPlayer();
        Spirit spirit = races.getOrigin(player.getUniqueId(), Spirit.class);
        if (spirit == null)
        {
            return;
        }

        World world = player.getWorld();
        if (world.getName().toLowerCase().contains("heaven"))
        {
            SpiritFormEvent formEvent = new SpiritFormEvent(spirit, true);
            Bukkit.getPluginManager().callEvent(formEvent);
        }
        else
        {
            SpiritFormEvent formEvent = new SpiritFormEvent(spirit, false);
            Bukkit.getPluginManager().callEvent(formEvent);
        }
    }
}
