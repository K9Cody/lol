package com.github.rfsmassacre.heavenraces.tasks.angels;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Angel;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class GlideTask extends BukkitRunnable
{
    private static final String KEY = "spirit.stamina";
    private final PaperConfiguration config;
    private final RaceManager races;

    public GlideTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
    }

    @Override
    public void run()
    {
        for (Angel angel : races.getOrigins(Angel.class))
        {
            Player player = angel.getPlayer();
            if (player == null)
            {
                BossBarUtil.removeBossBar(KEY, angel.getPlayerId());
                continue;
            }

            if (angel.isSpiritForm() && player.isGliding() && angel.getStamina() > 0.0)
            {
                double strength = config.getDouble( "angel.spirit-form.glide");
                double terminal = config.getDouble("angel.spirit-form.terminal");
                Vector direction = player.getEyeLocation().getDirection().normalize().clone();
                double length = Math.max(strength, Math.min(player.getVelocity().length() + strength, terminal));
                player.setVelocity(direction.multiply(length));
                double newLength = player.getVelocity().length();
                double stamina = config.getDouble("angel.spirit-form.stamina.loss");
                angel.addStamina(-(stamina * newLength));
            }
            else if (!player.isGliding() && angel.getStamina() < 1.0)
            {
                double stamina = config.getDouble("angel.spirit-form.stamina.gain");
                angel.addStamina(stamina);
            }

            if (angel.getStamina() < 1.0)
            {
                BossBarUtil.updateBossBar(player, angel.getStamina(), KEY);
            }
            else
            {
                BossBarUtil.removeBossBar(KEY, player.getUniqueId());
            }
        }
    }
}