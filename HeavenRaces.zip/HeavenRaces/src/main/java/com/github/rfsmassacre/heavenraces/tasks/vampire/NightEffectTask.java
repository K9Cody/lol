package com.github.rfsmassacre.heavenraces.tasks.vampire;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.utils.ConfigUtil;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;

public class NightEffectTask extends BukkitRunnable
{
    private final RaceManager races;

    private final HashSet<PotionEffect> passives;
    private final HashSet<PotionEffect> batPassives;
    private final HashSet<PotionEffect> bloodlustPassives;

    public NightEffectTask(HeavenRaces instance)
    {
        PaperConfiguration config = instance.getConfiguration();
        this.races = instance.getRaceManager();

        this.passives = ConfigUtil.getPotionEffects(config, "vampire.passives.effects");
        this.batPassives = ConfigUtil.getPotionEffects(config, "vampire.bat-form.effects");
        this.bloodlustPassives = ConfigUtil.getPotionEffects(config, "vampire.bloodlust.effects");
    }

    @Override
    public void run()
    {
        for (Vampire vampire : races.getOrigins(Vampire.class))
        {
            Player player = vampire.getPlayer();
            if (player == null)
            {
                continue;
            }

            for (PotionEffect effect : passives)
            {
                if (!vampire.isNightVision() && effect.getType().equals(PotionEffectType.NIGHT_VISION))
                {
                    player.removePotionEffect(PotionEffectType.NIGHT_VISION);
                    continue;
                }

                if (!vampire.isJumpBoost() && effect.getType().equals(PotionEffectType.JUMP_BOOST))
                {
                    player.removePotionEffect(PotionEffectType.JUMP_BOOST);
                    continue;
                }

                PotionEffect first = player.getPotionEffect(effect.getType());
                if (first == null || first.getAmplifier() <= effect.getAmplifier())
                {
                    player.addPotionEffect(effect);
                }
            }

            if (vampire.inBatForm())
            {
                for (PotionEffect effect : batPassives)
                {
                    PotionEffect first = player.getPotionEffect(effect.getType());
                    if (first == null || first.getAmplifier() <= effect.getAmplifier())
                    {
                        player.addPotionEffect(effect);
                    }
                }
            }

            if (vampire.inBloodLust())
            {
                for (PotionEffect effect : bloodlustPassives)
                {
                    PotionEffect first = player.getPotionEffect(effect.getType());
                    if (first == null || first.getAmplifier() <= effect.getAmplifier())
                    {
                        player.addPotionEffect(effect);
                    }
                }
            }
        }
    }
}
