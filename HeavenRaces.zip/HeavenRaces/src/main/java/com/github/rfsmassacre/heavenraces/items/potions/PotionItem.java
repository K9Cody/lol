package com.github.rfsmassacre.heavenraces.items.potions;

import com.github.rfsmassacre.heavenraces.items.RaceItem;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.meta.PotionMeta;

public abstract class PotionItem extends RaceItem
{
    public PotionItem(String name, Color color)
    {
        super(name, Material.POTION);

        setColor(color);

        this.recipe = createRecipe();
    }
    public PotionItem(String name, Color color, boolean splash)
    {
        super(name, splash ? Material.SPLASH_POTION : Material.POTION);

        setColor(color);

        this.recipe = createRecipe();
    }

    protected void setColor(Color color)
    {
        //Set the color of the potion
        PotionMeta meta = (PotionMeta) item.getItemMeta();
        meta.setColor(color);
        item.setItemMeta(meta);
    }
    public Color getColor()
    {
        //Get the color of the potion
        PotionMeta meta = (PotionMeta) item.getItemMeta();
        return meta.getColor();
    }
}
