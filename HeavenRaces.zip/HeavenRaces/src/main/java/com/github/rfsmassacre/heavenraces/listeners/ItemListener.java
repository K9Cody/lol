package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenclans.HeavenClansAPI;
import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.*;
import com.github.rfsmassacre.heavenraces.events.VampireFoodEvent.VampireAction;
import com.github.rfsmassacre.heavenraces.events.VampireHealthRegainEvent.HealthReason;
import com.github.rfsmassacre.heavenraces.items.Ash;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import com.github.rfsmassacre.heavenraces.items.armor.PurifiedArmor;
import com.github.rfsmassacre.heavenraces.items.armor.WashedArmor;
import com.github.rfsmassacre.heavenraces.items.potions.*;
import com.github.rfsmassacre.heavenraces.items.trackers.TrackerItem;
import com.github.rfsmassacre.heavenraces.items.weapons.SilverSword;
import com.github.rfsmassacre.heavenraces.items.weapons.WoodenStake;
import com.github.rfsmassacre.heavenraces.managers.ItemManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.*;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.utils.FXUtil;
import com.github.rfsmassacre.heavenraces.utils.FoodUtil;
import com.github.rfsmassacre.heavenraces.utils.RandomUtil;
import com.github.rfsmassacre.heavenraces.utils.SunUtil;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.FurnaceSmeltEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.FurnaceInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ArmorMeta;

import java.util.*;

public class ItemListener implements Listener
{
    private static final int MAX_FOOD = 20;

    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;
    private final ItemManager items;
    private final Map<UUID, ItemStack> furnaces;

    public ItemListener()
    {
        HeavenRaces instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
        this.items = instance.getItemManager();
        this.furnaces = new HashMap<>();
    }

    /*
     * CONSUMING CUSTOM POTIONS
     */
    @EventHandler(ignoreCancelled = true)
    public void onPotionConsume(PlayerItemConsumeEvent event)
    {
        Player player = event.getPlayer();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        ItemStack item = event.getItem();

        if (new CurePotion().equals(item))
        {
            if (origin instanceof Human human)
            {
                if (!human.isInfected())
                {
                    locale.sendLocale(player, true, "items.no-effect");
                }
                else
                {
                    human.cure();
                    locale.sendLocale(player, true, "items.cure-potion.human");
                }
            }
            else if (origin instanceof Werewolf werewolf)
            {
                //Untransform first
                if (werewolf.isWolfForm())
                {
                    WerewolfFormEvent formEvent = new WerewolfFormEvent(werewolf, false);
                    Bukkit.getPluginManager().callEvent(formEvent);
                    if (formEvent.isCancelled())
                    {
                        locale.sendLocale(player, true, "werewolf.wolf-form.cant-toggle");
                    }
                }

                RaceChangeEvent changeEvent = new RaceChangeEvent(werewolf, Race.HUMAN);
                Bukkit.getPluginManager().callEvent(changeEvent);
                if (changeEvent.isCancelled())
                {
                    return;
                }

                //Then cure player
                Human human = new Human(player);
                races.deleteOrigin(origin);
                races.saveOrigin(human, true);
                races.addOrigin(human);
                locale.sendLocale(player, true, "items.cure-potion.werewolf");
            }
            else
            {
                locale.sendLocale(player, true, "items.no-effect");
            }
        }
        else if (new InfectionPotion().equals(item))
        {
            if (origin instanceof Human human)
            {
                if (human.isInfected())
                {
                    locale.sendLocale(player, true, "infection.not-healthy");
                    return;
                }

                double amount = config.getDouble("werewolf.infection.potion");
                Human.Infection infection = new Human.Infection(Clan.WITHERFANG, amount);
                human.setInfection(infection);
                locale.sendLocale(player, true, "items.infection-potion.human");
            }
            else
            {
                locale.sendLocale(player, true, "items.no-effect");
            }
        }
        else if (new HumanBloodBottle().equals(item))
        {
            if (origin instanceof Vampire vampire)
            {
                consumeBottle(vampire, "HUMAN");

                double heal = Math.abs(config.getDouble("vampire.bottle.human-blood.health"));
                double health = player.getHealth();
                double maxHealth = player.getAttribute(Attribute.MAX_HEALTH).getValue();
                VampireHealthRegainEvent healthEvent = new VampireHealthRegainEvent(vampire, heal,
                        HealthReason.HUMAN_BLOOD);
                Bukkit.getPluginManager().callEvent(healthEvent);
                if (!healthEvent.isCancelled())
                {
                    heal = healthEvent.getHealth();
                }

                double healthLeft = Math.min(health + heal, maxHealth);
                player.setHealth(healthLeft);
            }
            else
            {
                locale.sendLocale(player, true, "items.no-effect");
            }
        }
        else if (new AnimalBloodBottle().equals(item))
        {
            if (origin instanceof Vampire vampire)
            {
                consumeBottle(vampire, "ANIMAL", new AnimalBloodBottle(item));
            }
            else
            {
                locale.sendLocale(player, true, "items.no-effect");
            }
        }
        else if (new VampireBloodBottle().equals(item))
        {
            if (origin instanceof Vampire vampire)
            {
                consumeBottle(vampire, "VAMPIRE");
            }
            else if (origin instanceof Human human)
            {
                VampireBloodBottle vampireBlood = new VampireBloodBottle(item);
                double amount = config.getDouble("infection.rate");
                if (!human.isInfected())
                {
                    Human.Infection infection = new Human.Infection(Race.VAMPIRE, vampireBlood.getVampireId(),
                            amount);
                    human.setInfection(infection);
                }
            }

            double damage = Math.abs(config.getDouble("vampire.bottle.vampire-blood.health"));
            double health = player.getHealth();
            double healthLeft = health - damage;
            if (healthLeft < 0)
            {
                healthLeft = 0;
            }

            player.setHealth(healthLeft);
            player.playEffect(EntityEffect.HURT);
            locale.sendLocale(player, true, "items.vampire-potion.hurt");
        }
    }

    private void consumeBottle(Vampire vampire, String type)
    {
        consumeBottle(vampire, type, null);
    }
    private void consumeBottle(Vampire vampire, String type, AnimalBloodBottle bottle)
    {
        Player player = vampire.getPlayer();
        int hunger = player.getFoodLevel();
        VampireAction action = VampireAction.HUMAN_BOTTLE;
        int bloodFood = config.getInt("vampire.bottle.human-blood.food");
        if (type.equals("ANIMAL"))
        {
            bloodFood = config.getInt("vampire.bottle.animal-blood.food");
            if (bottle != null)
            {
                bloodFood = bottle.getFoodPoints();
                action = VampireAction.ANIMAL_BOTTLE;
            }
        }
        else if (type.equals("VAMPIRE"))
        {
            bloodFood = config.getInt("vampire.bottle.vampire-blood.food");
            action = VampireAction.VAMPIRE_BOTTLE;
        }

        int food = hunger + bloodFood;
        VampireFoodEvent foodEvent = new VampireFoodEvent(vampire, bloodFood, action);
        Bukkit.getPluginManager().callEvent(foodEvent);
        if (!foodEvent.isCancelled())
        {
            food = hunger + (int)foodEvent.getFood();
        }

        player.setFoodLevel(Math.min(food, FoodUtil.MAX_FOOD));
    }

    /*
     * ARMOR STUFF
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPurifyWashedArmor(FurnaceSmeltEvent event)
    {
        ItemStack armor = event.getResult();
        if ((!armor.getType().toString().contains("HELMET")
        & !armor.getType().toString().contains("CHESTPLATE")
        & !armor.getType().toString().contains("LEGGINGS")
        & !armor.getType().toString().contains("BOOTS")))
        {
            return;
        }

        ItemStack source = event.getSource();
        RaceItem raceItem = items.getItem(source);
        if (raceItem == null)
        {
            event.setResult(new Ash().getItemStack());
            return;
        }

        int leather = this.config.getInt("human.smelt.leather");
        int golden = this.config.getInt("human.smelt.golden");
        int chainmail = this.config.getInt("human.smelt.chainmail");
        int iron = this.config.getInt("human.smelt.iron");
        int diamond = this.config.getInt("human.smelt.diamond");
        int netherite = this.config.getInt("human.smelt.netherite");
        if ((raceItem.getName().contains("Leather") && !RandomUtil.check(leather))
        || (raceItem.getName().contains("Golden") && !RandomUtil.check(golden))
        || (raceItem.getName().contains("Chainmail") && !RandomUtil.check(chainmail))
        || (raceItem.getName().contains("Iron") && !RandomUtil.check(iron))
        || (raceItem.getName().contains("Diamond") && !RandomUtil.check(diamond))
        || (raceItem.getName().contains("Netherite") && !RandomUtil.check(netherite)))
        {
            event.setResult(new Ash().getItemStack());
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onHumanItemCraft(PrepareItemCraftEvent event)
    {
        RaceItem result = items.getItem(event.getInventory().getResult());
        if (result == null)
        {
            return;
        }

        Player player = (Player) event.getView().getPlayer();
        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        switch (result)
        {
            case WoodenStake woodenStake ->
            {
                if (human == null)
                {
                    event.getInventory().setResult(null);
                    return;
                }

                for (ItemStack item : event.getInventory().getMatrix())
                {
                    if (item != null && item.getType().equals(woodenStake.getType()) && items.getItem(item) == null)
                    {
                        event.getInventory().setResult(new WoodenStake(item.getItemMeta()).getItemStack());
                        return;
                    }
                }

                event.getInventory().setResult(null);
            }
            case WashedArmor washedArmor ->
            {
                if (human == null)
                {
                    event.getInventory().setResult(null);
                    return;
                }

                for (ItemStack item : event.getInventory().getMatrix())
                {
                    if (item != null && item.getType().equals(washedArmor.getType()) &&
                            item.getItemMeta() instanceof ArmorMeta armorMeta && items.getItem(item) == null)
                    {
                        event.getInventory().setResult(new WashedArmor(item.getType(), armorMeta).getItemStack());
                        return;
                    }
                }

                event.getInventory().setResult(null);
            }
            default ->
            {
                //Do nothing
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFurnaceOpen(InventoryClickEvent event)
    {
        if (!(event.getInventory() instanceof FurnaceInventory))
        {
            return;
        }

        ItemStack item = null;
        if (event.getClickedInventory() instanceof FurnaceInventory)
        {
            item = event.getCursor();
        }
        else if (event.getClickedInventory() instanceof PlayerInventory &&
                event.getClick().equals(ClickType.SHIFT_LEFT))
        {
            item = event.getCurrentItem();
        }

        if (item == null)
        {
            return;
        }

        if (new SilverSword().equals(item))
        {
            event.setCancelled(true);
        }
        else if (item.getType().equals(Material.IRON_SWORD))
        {
            Player player = (Player) event.getWhoClicked();
            Human human = races.getOrigin(player.getUniqueId(), Human.class);
            if (human != null)
            {
                furnaces.put(player.getUniqueId(), item.clone());
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPurifyIronSword(FurnaceSmeltEvent event)
    {
        if (new SilverSword().equals(event.getResult()))
        {
            ItemStack item = event.getSource();
            boolean authorized = false;
            for (Map.Entry<UUID, ItemStack> entry : new HashSet<>(furnaces.entrySet()))
            {
                if (entry.getValue().isSimilar(item) &&
                        races.getOrigin(entry.getKey(), Human.class) != null)
                {
                    authorized = true;
                    furnaces.remove(entry.getKey());
                    break;
                }
            }

            event.setResult(authorized ? new SilverSword(item.getItemMeta()).getItemStack() : new Ash().getItemStack());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onWashedArmorInfection(StartInfectEvent event)
    {
        Human human = event.getHuman();
        Player player = human.getPlayer();
        boolean wearing = true;
        ItemStack[] equipment = player.getInventory().getArmorContents();
        for (ItemStack armor : equipment)
        {
            RaceItem item = items.getItem(armor);
            if (!(item instanceof WashedArmor || item instanceof PurifiedArmor))
            {
                wearing = false;
            }
        }

        if (wearing)
        {
            event.setCancelled(true);
            locale.sendLocale(player, true, "item.washed-armor.success");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onWashedArmorStop(InfectGrowEvent event)
    {
        Human human = event.getHuman();
        Player player = human.getPlayer();
        boolean wearing = true;
        ItemStack[] equipment = player.getInventory().getArmorContents();
        for (ItemStack armor : equipment)
        {
            RaceItem item = items.getItem(armor);
            if (!(item instanceof WashedArmor))
            {
                wearing = false;
            }

            if (!(item instanceof PurifiedArmor))
            {
                wearing = false;
            }
        }

        if (wearing)
        {
            event.setCancelled(true);
            locale.sendLocale(player, true, "item.washed-armor.success");
        }
    }

    /*
     * WEAPON STUFF
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onSilverSword(EntityDamageByEntityEvent event)
    {
        if (event.getDamager() instanceof Player attacker && event.getEntity() instanceof Player defender)
        {
            if (attacker.hasMetadata("NPC") || defender.hasMetadata("NPC"))
            {
                return;
            }

            ItemStack item = attacker.getInventory().getItemInMainHand();
            SilverSword weapon = new SilverSword();
            if (!weapon.equals(item))
            {
                return;
            }

            Werewolf werewolf = races.getOrigin(defender.getUniqueId(), Werewolf.class);
            if (werewolf == null)
            {
                return;
            }

            Human human = races.getOrigin(attacker.getUniqueId(), Human.class);
            if (human == null)
            {
                return;
            }

            double multiplier = config.getDouble("human.items.silver-sword.damage-percent");
            double damage = (event.getDamage() + 2) * multiplier;
            if (werewolf.isWolfForm())
            {
                Talent werewolfSlayer = human.getTalent("WerewolfSlayer");
                if (werewolfSlayer != null)
                {
                    double ratio = werewolfSlayer.getDouble("percent");
                    event.setDamage(damage * ratio);
                }

                HunterWeaponEvent weaponEvent = new HunterWeaponEvent(human, werewolf, weapon, damage);
                Bukkit.getPluginManager().callEvent(weaponEvent);
                if (!weaponEvent.isCancelled())
                {
                    Talent ironWill = werewolf.getTalent("IronWill");
                    if (ironWill != null)
                    {
                        double percent = ironWill.getDouble("percent");
                        event.setDamage(weaponEvent.getDamage() * percent);
                    }
                    else
                    {
                        event.setDamage(weaponEvent.getDamage());
                    }
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onWoodenStake(EntityDamageByEntityEvent event)
    {
        if (event.getDamager() instanceof Player attacker && event.getEntity() instanceof Player defender)
        {
            if (attacker.hasMetadata("NPC") || defender.hasMetadata("NPC"))
            {
                return;
            }

            ItemStack item = attacker.getInventory().getItemInMainHand();
            WoodenStake weapon = new WoodenStake();
            if (!weapon.equals(item))
            {
                return;
            }

            Human human = races.getOrigin(attacker.getUniqueId(), Human.class);
            if (human == null)
            {
                return;
            }

            Vampire vampire = races.getOrigin(defender.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                return;
            }

            double multiplier = config.getDouble("human.items.wooden-stake.damage-percent");
            Talent apathy = vampire.getTalent("Apathy");
            double percent = 1.0;
            if (apathy != null)
            {
                percent = apathy.getDouble("percent");
            }

            double damage = (event.getDamage() + 3) * multiplier;
            HunterWeaponEvent weaponEvent = new HunterWeaponEvent(human, vampire, weapon, damage);
            Bukkit.getPluginManager().callEvent(weaponEvent);
            if (!weaponEvent.isCancelled())
            {
                event.setDamage(damage * percent);
                Talent vampireSlayer = human.getTalent("VampireSlayer");
                if (vampireSlayer != null)
                {
                    int vampireFood = vampireSlayer.getInt("food");
                    defender.setFoodLevel(Math.max(0, defender.getFoodLevel() - vampireFood));
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPurifiedDefense(EntityDamageByEntityEvent event)
    {
        if (event.getDamager() instanceof Player attacker && event.getEntity() instanceof Player defender)
        {
            if (attacker.hasMetadata("NPC") || defender.hasMetadata("NPC"))
            {
                return;
            }

            Human human = races.getOrigin(defender.getUniqueId(), Human.class);
            if (human == null)
            {
                return;
            }

            Origin origin = races.getOrigin(attacker.getUniqueId(), Origin.class);
            if (origin == null || origin.getRace().equals(Race.HUMAN))
            {
                return;
            }

            double mitigation = 1.0;
            ItemStack[] equipment = defender.getInventory().getArmorContents();
            Set<String> armorTypes = Set.of("leather", "chainmail", "golden", "iron", "diamond", "netherite");
            for (ItemStack armor : equipment)
            {
                RaceItem item = items.getItem(armor);
                if (item instanceof PurifiedArmor)
                {
                    for (String armorType : armorTypes)
                    {
                        if (item.getType().toString().contains(armorType.toUpperCase()))
                        {
                            mitigation -= config.getDouble("human.armor.mitigation." + armorType);
                        }
                    }
                }
            }

            Talent holyArmor = human.getTalent("HolyArmor");
            Talent razorResistance = human.getTalent("RazorResistance");
            Talent radiance = human.getTalent("Radiance");
            if (mitigation > 0.0 && mitigation <= 1.0)
            {
                if (holyArmor != null && origin instanceof Vampire)
                {
                    double percent = holyArmor.getDouble("percent");
                    event.setDamage(event.getDamage() * (Math.max(0.0, mitigation) * percent));
                }

                if (razorResistance != null && origin instanceof Werewolf)
                {
                    double percent = razorResistance.getDouble("percent");
                    event.setDamage(event.getDamage() * (Math.max(0.0, mitigation) * percent));
                }


                if (radiance != null && origin instanceof Demon)
                {
                    double percent = radiance.getDouble("percent");
                    event.setDamage(event.getDamage() * (Math.max(0.0, mitigation) * percent));
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onFortyDurabilityDamage(PlayerItemDamageEvent event)
    {
        Player player = event.getPlayer();
        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        ItemStack item = event.getItem();
        if (!(items.getItem(item) instanceof PurifiedArmor))
        {
            return;
        }

        Talent fortify = human.getTalent("Fortify");
        if (fortify == null)
        {
            return;
        }

        double percent = fortify.getDouble("percent");
        int damage = (int) (event.getDamage() * percent);
        event.setDamage(damage);
    }


    /*
     * WOLFSBANE POTION
     */
    @EventHandler(ignoreCancelled = true)
    public void onWolfsbaneSplash(PotionSplashEvent event)
    {
        ThrownPotion potion = event.getPotion();
        ItemStack item = potion.getItem();
        if (new WolfsbanePotion().equals(item))
        {
            for (LivingEntity entity : event.getAffectedEntities())
            {
                if (!(entity instanceof Player player))
                {
                    continue;
                }

                Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
                if (werewolf == null)
                {
                    continue;
                }

                if (werewolf.isWolfForm())
                {
                    WerewolfFormEvent formEvent = new WerewolfFormEvent(werewolf, false);
                    Bukkit.getPluginManager().callEvent(formEvent);
                    if (!formEvent.isCancelled())
                    {
                        locale.sendLocale(player, true, "werewolf.wolfsbane.splashed");
                    }
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onHolyWaterSplash(PotionSplashEvent event)
    {
        ThrownPotion potion = event.getPotion();
        HolyWater holyWater = new HolyWater();
        if (!holyWater.equals(potion.getItem()))
        {
            return;
        }

        if (!(potion.getShooter() instanceof LivingEntity shooter))
        {
            return;
        }

        Human human = races.getOrigin(shooter.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        for (LivingEntity entity : event.getAffectedEntities())
        {
            if (!(entity instanceof Player player))
            {
                continue;
            }

            Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
            if (origin == null)
            {
                continue;
            }

            switch (origin)
            {
                case Human hunter ->
                {
                    ItemStack[] armor = player.getInventory().getArmorContents();
                    for (int slot = 0; slot < armor.length; slot++)
                    {
                        ItemStack item = armor[slot];
                        if (item == null)
                        {
                            continue;
                        }

                        WashedArmor washedArmor = WashedArmor.of(item);
                        if (washedArmor == null)
                        {
                            continue;
                        }

                        PurifiedArmor purifiedArmor = new PurifiedArmor(washedArmor);
                        armor[slot] = purifiedArmor.getItemStack();

                        locale.sendLocale(shooter, "items.purified-armor.priest", "{washedArmor}",
                                washedArmor.getDisplayName(), "{hunter}", hunter.getDisplayName());
                        if (!shooter.equals(player))
                        {
                            locale.sendLocale(player, "items.purified-armor.hunter", "{washedArmor}",
                                    washedArmor.getDisplayName(), "{priest}", human.getDisplayName());
                        }
                    }

                    player.getInventory().setArmorContents(armor);
                }
                case Vampire vampire ->
                {
                    EntityDamageByEntityEvent damageEvent = new EntityDamageByEntityEvent(player, shooter,
                            EntityDamageEvent.DamageCause.MAGIC, DamageSource.builder(DamageType.MAGIC)
                            .withDirectEntity(shooter)
                            .withCausingEntity(shooter)
                            .build(), 0.0);
                    Bukkit.getPluginManager().callEvent(damageEvent);
                    if (damageEvent.isCancelled())
                    {
                        continue;
                    }

                    vampire.addTemperature(config.getDouble("human.items.holy-water.radiation"));
                    FXUtil.playEffect(player, Effect.GHAST_SHRIEK);
                    FXUtil.smokeBurst(player, config.getInt("vampire.effects.smoke-burst"));
                    FXUtil.flameBurst(player, config.getInt("vampire.effects.flame-burst"));
                }
                default ->
                {
                    //Do nothing.
                }
            }
        }
    }

    /*
     * Trackers
     */
    @EventHandler
    public void onTrackerActivate(PlayerInteractEvent event)
    {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Human hunter = races.getOrigin(player.getUniqueId(), Human.class);
        Action action = event.getAction();
        TrackerItem tracker = TrackerItem.getFromItem(event.getItem());
        if (tracker == null)
        {
            return;
        }

        if (!(action.equals(Action.RIGHT_CLICK_AIR) || action.equals(Action.RIGHT_CLICK_BLOCK)))
        {
            return;
        }

        if (HeavenClansAPI.isPeaceful(playerId))
        {
            locale.sendLocale(player, "human.trackers.peaceful");
            return;
        }

        UUID targetId = Human.getTarget(playerId);
        if (targetId != null)
        {
            Human.removeTarget(playerId);
            locale.sendLocale(player, true, "human.trackers.unloaded");
            return;
        }

        if (hunter == null)
        {
            locale.sendLocale(player, true, "human.trackers.not-human");
            return;
        }

        double range = config.getDouble("trackers.range");
        if (!player.getInventory().contains(Material.COAL) && !player.getInventory().contains(Material.CHARCOAL))
        {
            locale.sendLocale(player, true, "human.trackers.no-fuel");
            return;
        }

        Location location = player.getLocation();
        List<Player> potentials = player.getWorld().getPlayers();
        potentials.sort(new DistanceSort(player));
        for (Player potential : potentials)
        {
            Location targetLocation = potential.getLocation();
            if (location.distance(targetLocation) > range)
            {
                continue;
            }

            Origin target = races.getOrigin(potential.getUniqueId(), Origin.class);
            if (target == null)
            {
                continue;
            }

            if (!target.getRace().equals(tracker.getRace()))
            {
                continue;
            }

            if (HeavenClansAPI.isPeaceful(potential.getUniqueId()))
            {
                continue;
            }

            if (SunUtil.inGodModeRegion(potential))
            {
                continue;
            }

            TrackerTargetEvent targetEvent = new TrackerTargetEvent(hunter, target);
            Bukkit.getPluginManager().callEvent(targetEvent);
            if (targetEvent.isCancelled())
            {
                continue;
            }

            if (target.getLevel() < 40)
            {
                continue;
            }

            Human.setTarget(player.getUniqueId(), potential.getUniqueId());
            locale.sendLocale(player, true, "human.trackers.found", "{race}",
                    LocaleData.capitalize(target.getRace().toString()), "{player}", target.getDisplayName(),
                    "{distance}", Integer.toString((int) player.getLocation().distance(potential.getLocation())));

            return;
        }

        locale.sendLocale(player, true, "human.trackers.empty");
    }

    private record DistanceSort(Player player) implements Comparator<Player>
    {
        @Override
        public int compare(Player target1, Player target2)
        {
            double distance1 = player.getLocation().distance(target1.getLocation());
            double distance2 = player.getLocation().distance(target2.getLocation());
            return Double.compare(distance1, distance2);
        }
    }
}
