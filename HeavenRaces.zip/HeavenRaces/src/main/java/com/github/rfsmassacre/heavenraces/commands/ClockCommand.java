package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.paper.commands.SimplePaperCommand;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.MoonManager;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.moons.Moon.MoonPhase;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClockCommand extends SimplePaperCommand
{
    private final MoonManager moons;

    public ClockCommand()
    {
        super(HeavenRaces.getInstance(), "clock");

        this.moons = HeavenRaces.getInstance().getMoonManager();
    }

    @Override
    protected void onRun(CommandSender sender, String[] args)
    {
        if (!(sender instanceof Player player))
        {
            locale.sendLocale(sender, true, "invalid.console");
            return;
        }

        World world = player.getWorld();
        Moon moon = moons.getMoon(world);
        String info = " ";
        if (moon == null)
        {
            info += "\n\n&7" + "Not In Overworld\n&r";
            locale.sendMessage(player, info);
            return;
        }

        info += "\n\n&7" + world.getEnvironment();

        MoonPhase today = moon.getCurrentPhase();
        MoonPhase tomorrow = moon.getNextPhase();
        if (tomorrow == null)
        {
            tomorrow = MoonPhase.FULL_MOON;
        }

        if (today == null)
        {
            info += "\n&e" + "Today: " + "DAYTIME";
            info += "\n&d" + "Tonight: " + tomorrow;
            info += "\n&b" + "Days Left: " + tomorrow.getPosition();
        }
        else
        {
            info += "\n&e" + "Tonight: " + today;
            info += "\n&d" + "Tomorrow: " + tomorrow;
            info += "\n&b" + "Days Left: " + today.getPosition();
        }
        info += "\n&r";

        locale.sendMessage(player, info);
    }
}
