package com.github.rfsmassacre.heavenraces.items.potions;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapelessRecipe;

public class WolfsbanePotion extends PotionItem
{
    public WolfsbanePotion()
    {
        super("WolfsbanePotion", Color.YELLOW, true);
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapelessRecipe recipe = new ShapelessRecipe(this.key, getItemStack());
        recipe.addIngredient(Material.GLASS_BOTTLE);
        recipe.addIngredient(Material.MILK_BUCKET);
        recipe.addIngredient(Material.CARROT);
        recipe.addIngredient(Material.GUNPOWDER);
        recipe.addIngredient(Material.CACTUS);
        return recipe;
    }
}
