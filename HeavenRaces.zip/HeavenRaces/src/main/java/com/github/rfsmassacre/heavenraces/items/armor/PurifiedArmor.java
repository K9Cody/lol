package com.github.rfsmassacre.heavenraces.items.armor;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import lombok.Getter;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.meta.ArmorMeta;

import java.util.ArrayList;
import java.util.List;

@Getter
public class PurifiedArmor extends RaceItem
{
    private final WashedArmor washedArmor;

    public PurifiedArmor(WashedArmor washedArmor)
    {
        super("Purified" + LocaleData.capitalize(washedArmor.getType().toString()).replaceAll(" ",
                ""), washedArmor.getType());

        this.washedArmor = washedArmor;
    }

    public PurifiedArmor(Material material)
    {
        this(new WashedArmor(material, null));
    }

    @Override
    public ItemStack getItemStack()
    {
        ArmorMeta armorMeta = washedArmor.getArmorMeta();
        if (armorMeta == null)
        {
            return item;
        }

        if (item.getItemMeta() instanceof ArmorMeta meta)
        {
            armorMeta.setCustomModelData(meta.getCustomModelData());
            armorMeta.displayName(meta.displayName());
            List<Component> newLore = meta.lore();
            if (newLore != null)
            {
                List<Component> oldLore = armorMeta.lore();
                if (oldLore == null)
                {
                    oldLore = new ArrayList<>();
                }

                List<String> defaultLore = washedArmor.getDefaultLore()
                        .stream()
                        .map(LocaleData::format)
                        .toList();
                List<String> oldLoreStrings = new ArrayList<>(oldLore
                        .stream()
                        .map((component) -> LocaleData.format(LegacyComponentSerializer.legacySection()
                                .serialize(component)))
                        .toList());
                oldLoreStrings.removeAll(defaultLore);
                List<String> newLoreString = new ArrayList<>(newLore
                        .stream()
                        .map((component) -> LocaleData.format(LegacyComponentSerializer.legacySection()
                                .serialize(component)))
                        .toList());
                newLoreString.addAll(oldLoreStrings);
                item.setItemMeta(armorMeta);
                setItemLore(newLoreString);
            }

            this.removeNBT(washedArmor.getKey());
            this.setNBT(key, name);
        }

        return item;
    }


    @Override
    protected Recipe createRecipe()
    {
        return null;
    }
}
