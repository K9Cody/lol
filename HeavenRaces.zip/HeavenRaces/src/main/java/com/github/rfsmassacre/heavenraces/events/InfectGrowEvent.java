package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.players.Human;
import lombok.Getter;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;

public class InfectGrowEvent extends Event implements Cancellable
{
    private static final HandlerList HANDLERS = new HandlerList();

    @Override
    public HandlerList getHandlers()
    {
        return HANDLERS;
    }
    public static HandlerList getHandlerList()
    {
        return HANDLERS;
    }

    @Getter
    private final Human human;
    @Getter
    private final Race race;
    @Getter
    private final double amount;
    private boolean cancel;

    public InfectGrowEvent(Human human, Race race, double amount)
    {
        this.human = human;
        this.race = race;
        this.amount = amount;
        this.cancel = false;
    }

    @Override
    public boolean isCancelled()
    {
        return cancel;
    }
    @Override
    public void setCancelled(boolean cancel)
    {
        this.cancel = cancel;
    }
}
