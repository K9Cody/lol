package com.github.rfsmassacre.heavenraces.tasks.vampire;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.VampireBatEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.utils.CombatUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class BatFoodTask extends BukkitRunnable
{
    private final RaceManager races;

    public BatFoodTask(HeavenRaces instance)
    {
        this.races = instance.getRaceManager();
    }

    @Override
    public void run()
    {
        for (Vampire vampire : races.getOrigins(Vampire.class))
        {
            Player player = vampire.getPlayer();
            if (player == null || player.isDead() || !vampire.inBatForm() || CombatUtil.isSpawnProtected(vampire)
                || vampire.hasTalent("StrongWings"))
            {
                continue;
            }

            player.setFoodLevel(Math.max(0, player.getFoodLevel() - 1));
            if (player.getFoodLevel() == 0)
            {
                VampireBatEvent event = new VampireBatEvent(vampire, false);
                Bukkit.getPluginManager().callEvent(event);
            }
        }
    }
}
