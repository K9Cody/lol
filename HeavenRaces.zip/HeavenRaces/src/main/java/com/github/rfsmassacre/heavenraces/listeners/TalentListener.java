package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.VampireFoodEvent;
import com.github.rfsmassacre.heavenraces.events.VampireFoodEvent.VampireAction;
import com.github.rfsmassacre.heavenraces.events.VampireHealthRegainEvent;
import com.github.rfsmassacre.heavenraces.events.VampireHealthRegainEvent.HealthReason;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.tasks.humans.GlowTask;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent.Action;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public class TalentListener implements Listener
{
    private final RaceManager races;
    private final Set<UUID> angels;

    public TalentListener()
    {
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.angels = new HashSet<>();
    }

    /*
     * VAMPIRES
     */

    //Tier 1 - Siphon & Gluttonous Diet
    @EventHandler(ignoreCancelled = true)
    public void onVampireFood(VampireFoodEvent event)
    {
        Vampire vampire = event.getVampire();
        Talent siphon = vampire.getTalent("Siphon");
        if (siphon != null && event.getAction().equals(VampireAction.ATTACK))
        {
            double percent = siphon.getDouble("percent");
            event.setFood(event.getFood() * percent);
        }

        Talent gluttonousDiet = vampire.getTalent("GluttonousDiet");
        if (gluttonousDiet != null && event.getAction().toString().contains("BOTTLE"))
        {
            double percent = gluttonousDiet.getDouble("percent");
            event.setFood(event.getFood() * percent);
        }
    }

    //Tier 1 - Healthy Diet
    @EventHandler(ignoreCancelled = true)
    public void onVampireHeal(VampireHealthRegainEvent event)
    {
        Vampire vampire = event.getVampire();
        Talent healthyDiet = vampire.getTalent("HealthyDiet");
        if (healthyDiet != null && event.getReason().equals(HealthReason.HUMAN_BLOOD))
        {
            double percent = healthyDiet.getDouble("percent");
            event.setHealth(event.getHealth() * percent);
        }
    }

    //Tier 2 - LastWill & No Fear
    @EventHandler(ignoreCancelled = true)
    public void onVampireDamagedPercent(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        Talent lastWill = vampire.getTalent("LastWill");
        if (lastWill != null)
        {
            double healthRatio = lastWill.getDouble("health-ratio");
            double maxHealth = player.getAttribute(Attribute.MAX_HEALTH).getValue();
            double health = player.getHealth();
            if (health / maxHealth <= healthRatio)
            {
                double percent = lastWill.getDouble("percent");
                event.setDamage(event.getDamage() * percent);
            }
        }

        Talent noFear = vampire.getTalent("NoFear");
        if (noFear != null && vampire.inBloodLust())
        {
            double percent = noFear.getDouble("percent");
            event.setDamage(event.getDamage() * percent);
        }
    }

    /*
     * WEREWOLVES
     */

    //Thick Skin
    @EventHandler(ignoreCancelled = true)
    public void onPlayerSneak(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null || !werewolf.isWolfForm())
        {
            return;
        }

        Talent thickSkin = werewolf.getTalent("ThickSkin");
        if (thickSkin != null && player.isSneaking())
        {
            double percent = thickSkin.getDouble("percent");
            event.setDamage(event.getDamage() * percent);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPotionImmunity(EntityPotionEffectEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        if (!event.getAction().equals(Action.ADDED))
        {
            return;
        }

        PotionEffectType weakness = Objects.requireNonNull(event.getNewEffect()).getType();
        if (werewolf.isWolfForm() && weakness.equals(PotionEffectType.WEAKNESS))
        {
            event.setCancelled(true);
        }

        Talent swiftFeet = werewolf.getTalent("SwiftFeet");
        if (swiftFeet == null)
        {
            return;
        }

        switch (werewolf.getClan())
        {
            case WITHERFANG ->
            {
                PotionEffectType type = Objects.requireNonNull(event.getNewEffect()).getType();
                if (type.equals(PotionEffectType.SLOWNESS))
                {
                    event.setCancelled(true);
                }
            }
            case SILVERMANE ->
            {
                PotionEffectType type = Objects.requireNonNull(event.getNewEffect()).getType();
                if (type.equals(PotionEffectType.POISON) || type.equals(PotionEffectType.WITHER))
                {
                    event.setCancelled(true);
                }
            }
            case BLOODMOON ->
            {
                PotionEffectType type = Objects.requireNonNull(event.getNewEffect()).getType();
                if (type.equals(PotionEffectType.INSTANT_DAMAGE))
                {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPurifiedHeal(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        Talent guardianAngel = human.getTalent("GuardianAngel");
        if (guardianAngel == null)
        {
            return;
        }

        double percent = guardianAngel.getDouble("percent");
        double heal = guardianAngel.getDouble("heal");
        double maxHealth = player.getAttribute(Attribute.MAX_HEALTH).getValue();
        double remainingHealth = Math.max(0.0, player.getHealth() - event.getFinalDamage());
        int delay = guardianAngel.getInt("delay");
        if (remainingHealth / maxHealth > percent)
        {
            return;
        }

        if (angels.contains(player.getUniqueId()))
        {
            return;
        }

        Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), ()->
        {
            if (!player.isDead())
            {
                player.setHealth(Math.min(player.getHealth() + heal, maxHealth));
            }
        }, 1L);

        angels.add(player.getUniqueId());
        Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), () ->
        {
            angels.remove(player.getUniqueId());
        }, delay);
    }

    @EventHandler(ignoreCancelled = true)
    public void onGlowDamage(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Player player))
        {
            return;
        }

        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        Talent executioner = human.getTalent("Executioner");
        if (executioner == null)
        {
            return;
        }

        if (!(event.getEntity() instanceof Player victim))
        {
            return;
        }

        Origin origin = races.getOrigin(victim.getUniqueId(), Origin.class);
        if (origin instanceof Human)
        {
            return;
        }

        if (GlowTask.GLOWS.contains(victim.getUniqueId()))
        {
            double percent = executioner.getDouble("percent");
            event.setDamage(event.getDamage() * percent);
        }
    }
}
