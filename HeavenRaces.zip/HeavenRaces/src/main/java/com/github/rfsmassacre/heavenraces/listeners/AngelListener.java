package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.SpellTargetEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Angel;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Spirit;
import com.github.rfsmassacre.heavenraces.spells.HolyPresenceSpell;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;

public class AngelListener implements Listener
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public AngelListener()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @EventHandler(ignoreCancelled = true)
    public void onAngelFly(PlayerToggleFlightEvent event)
    {
        Player player = event.getPlayer();
        Angel angel = races.getOrigin(player.getUniqueId(), Angel.class);
        if (angel == null)
        {
            return;
        }

        if (angel.isSpiritForm())
        {
            if (event.isFlying())
            {
                player.setGliding(true);
                event.setCancelled(true);
            }
            else
            {
                player.setGliding(false);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onAngelGlide(EntityToggleGlideEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Angel angel = races.getOrigin(player.getUniqueId(), Angel.class);
        if (angel == null)
        {
            return;
        }

        Block block = player.getLocation().getBlock().getRelative(BlockFace.DOWN);
        if (angel.isSpiritForm() && !event.isGliding() && !block.isSolid())
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onSeraphPresence(EntityRegainHealthEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null || origin instanceof Spirit)
        {
            return;
        }

        if (origin.getCorruption() > 0)
        {
            return;
        }

        double range = config.getDouble("angel.seraph.range");
        double multiplier = config.getDouble("angel.seraph.multiplier");
        for (Entity entity : player.getNearbyEntities(range, range, range))
        {
            if (!(entity instanceof Player support))
            {
                continue;
            }

            Angel angel = races.getOrigin(support.getUniqueId(), Angel.class);
            if (angel == null || !angel.isSpiritForm() || !angel.getRank().equals(Spirit.Rank.SERAPH))
            {
                continue;
            }

            HolyPresenceSpell holyPresence = (HolyPresenceSpell) Spell.getSpell("holyPresence");
            SpellTargetEvent targetEvent = new SpellTargetEvent(support, holyPresence, player);
            if (!targetEvent.isCancelled())
            {
                event.setAmount(event.getAmount() * multiplier);
                return;
            }
        }
    }
}
