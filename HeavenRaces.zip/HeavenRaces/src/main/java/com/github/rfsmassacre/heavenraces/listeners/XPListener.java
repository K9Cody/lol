package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.ExperienceGainEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import io.lumine.mythic.api.mobs.MythicMob;
import io.lumine.mythic.bukkit.events.MythicMobDeathEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.List;

public class XPListener implements Listener
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public XPListener()
    {
        HeavenRaces instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
    }

    @EventHandler(ignoreCancelled = true)
    public void onRaceKill(EntityDeathEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Player killer = player.getKiller();
        if (killer == null)
        {
            return;
        }

        Human human = races.getOrigin(killer.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin instanceof Human)
        {
            return;
        }

        double amount = config.getDouble("xp.human.player");
        ExperienceGainEvent experienceEvent = new ExperienceGainEvent(human, amount);
        Bukkit.getPluginManager().callEvent(experienceEvent);
        if (!experienceEvent.isCancelled())
        {
            human.addLevel(experienceEvent.getXp());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onRaceKillMob(MythicMobDeathEvent event)
    {
        if (!(event.getKiller() instanceof Player player))
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        MythicMob mythicMob = event.getMobType();
        List<String> allowedFactions = config.getStringList("xp." + origin.getRace().toString().toLowerCase() +
                ".mobs");
        if (!allowedFactions.contains(mythicMob.getFaction()))
        {
            return;
        }

        double amount = config.getDouble("xp." + origin.getRace().toString().toLowerCase() + ".amount");
        ExperienceGainEvent experienceEvent = new ExperienceGainEvent(origin, amount);
        Bukkit.getPluginManager().callEvent(experienceEvent);
        if (!experienceEvent.isCancelled())
        {
            origin.addLevel(experienceEvent.getXp());
        }
    }
}
