package com.github.rfsmassacre.heavenraces.players;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

import java.util.*;

@Getter
@Setter
public class Werewolf extends Origin
{
    public enum Clan
    {
        WITHERFANG,
        SILVERMANE,
        BLOODMOON;

        public static Clan fromString(String name)
        {
            try
            {
                return Clan.valueOf(name.toUpperCase());
            }
            catch (IllegalArgumentException exception)
            {
                return null;
            }
        }
    }

    private Clan clan;
    private boolean wolfForm;
    private UUID trackerId;
    private boolean tracking;
    private int transformTime;
    private int fatigueTime;
    private int negatedTicks;

    public Werewolf()
    {
        super();

        this.race = Race.WEREWOLF;
        this.wolfForm = false;
        this.fatigueTime = 0;
        this.negatedTicks = 0;
    }

    public Werewolf(Player player)
    {
        super(player, Race.WEREWOLF);

        this.clan = Clan.WITHERFANG;
        this.wolfForm = false;
        this.fatigueTime = 0;
        this.negatedTicks = 0;
        updateStats();
    }
    public Werewolf(Player player, Clan clan)
    {
        super(player, Race.WEREWOLF);

        this.clan = clan;
        this.wolfForm = false;
        this.fatigueTime = 0;
        this.negatedTicks = 0;
        updateStats();
    }
    public Werewolf(Origin origin)
    {
        super(origin);

        this.race = Race.WEREWOLF;
        this.clan = Clan.WITHERFANG;
        this.wolfForm = false;
        this.fatigueTime = 0;
        this.negatedTicks = 0;
        updateStats();
    }
    public Werewolf(Origin origin, Clan clan)
    {
        super(origin);

        this.race = Race.WEREWOLF;
        this.clan = clan;
        this.wolfForm = false;
        this.fatigueTime = 0;
        this.negatedTicks = 0;
        updateStats();
    }

    public void updateStats()
    {
        int level = HeavenRaces.getInstance().getConfiguration().getInt("level-reward.werewolf.human-passives");
        if (wolfForm)
        {
            updateStats(clan.toString().toLowerCase() + ".werewolf");
        }
        else if (getLevel() >= level)
        {
            updateStats(clan.toString().toLowerCase() + ".human");
        }
        else
        {
            clearStats();
        }
    }

    /*
     * GETTERS/SETTERS
     */
    public void addTransformTime(int transformTime)
    {
        this.transformTime += transformTime;
    }

    public void removeTransformTime(int transformTime)
    {
        this.transformTime -= transformTime;
    }

    public void addFatigueTime(int fatigue)
    {
        this.fatigueTime += fatigue;
    }

    public void removeFatigueTime(int fatigue)
    {
        this.fatigueTime -= fatigue;
    }

}
