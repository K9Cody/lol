package com.github.rfsmassacre.heavenraces.tasks.vampire;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.utils.CombatUtil;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class HungerHealTask extends BukkitRunnable
{
    private final RaceManager races;

    public HungerHealTask(HeavenRaces instance)
    {
        this.races = instance.getRaceManager();
    }

    @Override
    public void run()
    {
        for (Vampire vampire : races.getOrigins(Vampire.class))
        {
            Player player = vampire.getPlayer();
            if (player == null || player.isDead())
            {
                continue;
            }

            double maxHealth = player.getAttribute(Attribute.MAX_HEALTH).getValue();
            double health = player.getHealth();
            if (health < maxHealth && player.getFoodLevel() > 0)
            {
                double healBack = Math.min(maxHealth, health + 1);
                player.setHealth(healBack);
                if (!CombatUtil.isSpawnProtected(vampire))
                {
                    int food = Math.max(0, player.getFoodLevel() - 1);
                    player.setFoodLevel(food);
                }
            }
        }
    }
}
