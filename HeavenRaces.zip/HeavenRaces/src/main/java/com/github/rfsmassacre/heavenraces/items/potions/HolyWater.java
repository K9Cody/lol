package com.github.rfsmassacre.heavenraces.items.potions;

import org.bukkit.Color;
import org.bukkit.inventory.Recipe;

public class HolyWater extends PotionItem
{
    public HolyWater()
    {
        super("HolyWater", Color.BLUE, true);
    }

    @Override
    protected Recipe createRecipe()
    {
        return null;
    }
}
