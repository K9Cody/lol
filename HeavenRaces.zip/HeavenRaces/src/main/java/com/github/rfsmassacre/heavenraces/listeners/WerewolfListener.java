package com.github.rfsmassacre.heavenraces.listeners;

import com.codingforcookies.armorequipevent.ArmorEquipEvent;
import com.github.rfsmassacre.heavenduels.HeavenDuelsAPI;
import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.*;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.MoonManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.managers.SkinManager;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.moons.Moon.MoonPhase;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Human.Infection;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.tasks.LocationTask;
import com.github.rfsmassacre.heavenraces.tasks.werewolves.RabiesTask;
import com.github.rfsmassacre.heavenraces.utils.*;
import io.lumine.mythic.bukkit.MythicBukkit;
import io.lumine.mythic.core.mobs.ActiveMob;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class WerewolfListener implements Listener
{
    private final HeavenRaces instance;
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;
    private final MoonManager moons;
    private final SkinManager skins;
    private final LeaderManager leaders;

    private final HashSet<UUID> sniffers;
    private final Map<UUID, BukkitTask> relentlessTasks;
    private final Map<UUID, List<RabiesTask>> rabiesTasks;

    public WerewolfListener()
    {
        this.instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
        this.moons = instance.getMoonManager();
        this.skins = instance.getSkinManager();
        this.leaders = instance.getLeaderManager();
        this.sniffers = new HashSet<>();
        this.relentlessTasks = new HashMap<>();
        this.rabiesTasks = new HashMap<>();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onWerewolfFall(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Werewolf werewolf = this.races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        if (werewolf.isWolfForm() && event.getCause().equals(DamageCause.FALL))
        {
            event.setCancelled(true);
            player.setMetadata("heavenraces", new FixedMetadataValue(HeavenRaces.getInstance(),
                    "werewolf"));
            Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), () ->
                    player.removeMetadata("heavenraces", HeavenRaces.getInstance()), 1L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onWerewolfDefense(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Werewolf werewolf = this.races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null || !werewolf.isWolfForm())
        {
            return;
        }

        //Override combat damage based on what's on your hands
        String clan = werewolf.getClan().toString().toLowerCase();
        Leader alpha = leaders.getLeader(werewolf.getClan());
        String type = alpha != null && werewolf.getPlayerId().equals(alpha.getLeaderId()) ? "alpha" : "werewolf";
        double defenseStat = config.getDouble("werewolf.stats." + clan + "." + type + ".defense");
        double levelScale = config.getDouble("werewolf.stats.level-scale");
        double baseScale = config.getDouble("werewolf.stats.base-scale");
        double baseReduction = defenseStat * baseScale;  // Base % reduction (e.g., 35%)
        double levelReduction = defenseStat * levelScale * werewolf.getLevel(); // Scaled by level
        double totalReduction = Math.min(defenseStat, baseReduction + levelReduction); // Cap at 100%
        event.setDamage(event.getDamage() * (1.0 - totalReduction));
    }

    /*
     * Ensure everything goes consistently when werewolves transform.
     */
    @EventHandler(ignoreCancelled = true)
    public void onWerewolfTransform(WerewolfFormEvent event)
    {
        Werewolf werewolf = event.getWerewolf();
        Player player = werewolf.getPlayer();
        Clan clan = werewolf.getClan();
        int transformTime = config.getInt("werewolf.transform-time.max");
        int fatigueTime = config.getInt("werewolf.transform-time.fatigue");
        HashSet<PotionEffect> witherfangForm = ConfigUtil.getPotionEffects(config,
                "werewolf.wolf-effects.witherfang");
        HashSet<PotionEffect> silvermaneForm = ConfigUtil.getPotionEffects(config,
                "werewolf.wolf-effects.silvermane");
        HashSet<PotionEffect> bloodmoonForm = ConfigUtil.getPotionEffects(config,
                "werewolf.wolf-effects.bloodmoon");

        Leader alpha = leaders.getLeader(werewolf.getClan());
        if (event.isToggled())
        {
            if (player.isDead())
            {
                return;
            }

            werewolf.setWolfForm(true);
            skins.applySkin(player, skins.getSkin(werewolf), () ->
            {
                Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
                {
                    switch (clan)
                    {
                        case WITHERFANG -> PotionEffectUtil.addPotionEffects(player, witherfangForm);
                        case SILVERMANE -> PotionEffectUtil.addPotionEffects(player, silvermaneForm);
                        case BLOODMOON -> PotionEffectUtil.addPotionEffects(player, bloodmoonForm);
                    }

                    werewolf.setTransformTime(transformTime);
                    werewolf.setFatigueTime(0);
                    FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_HOWL);
                    dropArmor(werewolf);
                    werewolf.updateStats();
                    locale.sendLocale(player, true, "werewolf.wolf-form.enabled");
                    Location last = LocationTask.LOCATIONS.get(player.getUniqueId());
                    if (last != null && last.getWorld().equals(player.getWorld()))
                    {
                        player.setMetadata("teleport", new FixedMetadataValue(HeavenRaces.getInstance(),
                                "transform"));
                        last.setYaw(player.getYaw());
                        last.setPitch(player.getPitch());
                        player.teleport(last, PlayerTeleportEvent.TeleportCause.PLUGIN);
                        player.removeMetadata("teleport", HeavenRaces.getInstance());
                    }
                });
            });

        }
        else
        {
            skins.removeSkin(werewolf.getPlayer(), () ->
            {
                Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
                {
                    switch (clan)
                    {
                        case WITHERFANG -> PotionEffectUtil.removePotionEffects(player, witherfangForm);
                        case SILVERMANE -> PotionEffectUtil.removePotionEffects(player, silvermaneForm);
                        case BLOODMOON -> PotionEffectUtil.removePotionEffects(player, bloodmoonForm);
                    }

                    werewolf.setWolfForm(false);
                    werewolf.setTransformTime(0);
                    werewolf.setFatigueTime(fatigueTime);
                    if (alpha != null && alpha.getLeaderId().equals(werewolf.getPlayerId()))
                    {
                        werewolf.setFatigueTime(1200);
                    }

                    FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_GROWL);
                    werewolf.updateStats();
                    locale.sendLocale(player, true, "werewolf.wolf-form.disabled");
                    Location last = LocationTask.LOCATIONS.get(player.getUniqueId());
                    if (last != null && last.getWorld().equals(player.getWorld()))
                    {
                        player.setMetadata("teleport", new FixedMetadataValue(HeavenRaces.getInstance(),
                                "transform"));
                        last.setYaw(player.getYaw());
                        last.setPitch(player.getPitch());
                        player.teleport(last, PlayerTeleportEvent.TeleportCause.PLUGIN);
                        player.removeMetadata("teleport", HeavenRaces.getInstance());
                    }
                });
            });
        }
    }

    //Drops or places armor when werewolf is transforming
    public void dropArmor(Werewolf werewolf)
    {
        Player player = werewolf.getPlayer();
        ItemStack[] equipment = player.getInventory().getArmorContents();

        //Drop each item
        for (ItemStack armor : equipment)
        {
            if (armor != null && !armor.getType().equals(Material.AIR))
            {
                //High level werewolves just have it placed back in their inventory
                if (werewolf.getLevel() >= config.getInt("level-reward.werewolf.no-drop") &&
                        player.getInventory().firstEmpty() > -1)
                {
                    player.getInventory().addItem(armor);
                }
                else
                {
                    player.getWorld().dropItemNaturally(player.getLocation(), armor);
                }
            }

            player.updateInventory();
        }

        //Then remove each item equipped
        for (int slot = 0; slot < equipment.length; slot++)
        {
            equipment[slot] = new ItemStack(Material.AIR);
        }

        player.getInventory().setArmorContents(equipment);
    }

    /*
     * Prevent untransforming during a full moon
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOW)
    public void onWerewolfFullMoon(WerewolfFormEvent event)
    {
        Werewolf werewolf = event.getWerewolf();
        Player player = werewolf.getPlayer();
        Moon moon = moons.getMoon(player.getWorld());
        if (event.isToggled() || moon == null)
        {
            return;
        }

        if (moon.getCurrentPhase() != null && moon.getCurrentPhase().equals(MoonPhase.FULL_MOON))
        {
            if (!event.isForced())
            {
                event.setCancelled(true);
            }
        }
    }

    /*
     * Sniff tracking ability
     */
    @EventHandler(ignoreCancelled=true)
    public void onWerewolfSniff(PlayerInteractEntityEvent event)
    {
        if (!(event.getRightClicked() instanceof Player target))
        {
            return;
        }
        if (!event.getHand().equals(EquipmentSlot.HAND))
        {
            return;
        }

        if (SunUtil.inGodModeRegion(target))
        {
            return;
        }

        Player player = event.getPlayer();
        final UUID playerId = player.getUniqueId();
        Werewolf werewolf = this.races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        if (!werewolf.isWolfForm() || !player.isSneaking())
        {
            return;
        }

        int level = config.getInt("level-reward.werewolf.scent");
        if (werewolf.getLevel() < level)
        {
            return;
        }

        if (sniffers.contains(playerId))
        {
            return;
        }

        int chance = config.getInt("werewolf.tracking.chance");
        if (RandomUtil.check(chance))
        {
            werewolf.setTrackerId(target.getUniqueId());
            locale.sendLocale(player, true, "werewolf.scent.found", "{player}",
                    target.getDisplayName());
        }
        else
        {
            locale.sendLocale(player, true, "werewolf.scent.failed");
        }

        this.sniffers.add(playerId);
        new BukkitRunnable()
        {
            public void run()
            {
                WerewolfListener.this.sniffers.remove(playerId);
            }
        }.runTaskLater(instance, config.getInt("werewolf.cooldown.scent"));
    }

    /*
     * Untransform on death
     */
    @EventHandler
    public void onWerewolfDeath(PlayerDeathEvent event)
    {
        Player player = event.getEntity();
        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf != null && werewolf.isWolfForm())
        {
            FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_GROWL);
        }
    }

    @EventHandler
    public void onWerewolfRespawn(PlayerRespawnEvent event)
    {
        Player player = event.getPlayer();
        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        Moon moon = moons.getMoon(player.getWorld());
        if (werewolf.isWolfForm() && !(moon != null && MoonPhase.FULL_MOON.equals(moon.getCurrentPhase())))
        {
            WerewolfFormEvent transformEvent = new WerewolfFormEvent(werewolf, false);
            Bukkit.getPluginManager().callEvent(transformEvent);
        }
    }

    /*
     * Werewolves can infect humans but only with their fists.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onWerewolfInfect(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Player player) || !(event.getEntity() instanceof Player))
        {
            return;
        }

        if (player.hasMetadata("NPC"))
        {
            return;
        }

        if (!player.getInventory().getItemInMainHand().getType().equals(Material.AIR))
        {
            return;
        }

        Player target = CombatUtil.getOriginalSource(event.getEntity());
        if (target == null)
        {
            return;
        }

        if (target.hasMetadata("NPC"))
        {
            return;
        }

        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        Human human = races.getOrigin(target.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        int amount = config.getInt("werewolf.infection.bite.amount");
        int chance = config.getInt("werewolf.infection.bite.chance");
        if (RandomUtil.check(chance) & !human.isInfected())
        {
            StartInfectEvent infectionEvent = new StartInfectEvent(human, Race.WEREWOLF, amount);
            Bukkit.getPluginManager().callEvent(infectionEvent);
            if (infectionEvent.isCancelled())
            {
                return;
            }

            Infection infection = new Infection(Clan.BLOODMOON, player.getUniqueId(), amount);
            human.setInfection(infection);
            locale.sendLocale(target, true, "werewolf.infection.start.bite");
            double xp = config.getDouble("xp.werewolf.player-infect");
            ExperienceGainEvent xpEvent = new ExperienceGainEvent(werewolf, xp);
            Bukkit.getPluginManager().callEvent(xpEvent);
            if (!xpEvent.isCancelled())
            {
                int oldLevel = (int) werewolf.getLevel();
                werewolf.addLevel(xpEvent.getXp());
                int newLevel = (int) werewolf.getLevel();
                if (newLevel > oldLevel)
                {
                    LevelUpEvent levelEvent = new LevelUpEvent(werewolf, newLevel);
                    Bukkit.getPluginManager().callEvent(levelEvent);
                }
            }
        }
    }

    /*
     * Werewolves can infect humans but only with their fists.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFeralWerewolfInfect(EntityDamageByEntityEvent event)
    {
        ActiveMob activeMob = MythicBukkit.inst().getMobManager().getActiveMob(event.getDamager().getUniqueId())
                .orElse(null);
        if (activeMob == null || !activeMob.getFaction().equals("Werewolf"))
        {
            return;
        }

        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        if (player.hasMetadata("NPC"))
        {
            return;
        }

        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        int amount = config.getInt("werewolf.infection.bite.amount");
        int chance = config.getInt("werewolf.infection.bite.chance");
        if (RandomUtil.check(chance) & !human.isInfected())
        {
            StartInfectEvent infectionEvent = new StartInfectEvent(human, Race.WEREWOLF, amount);
            Bukkit.getPluginManager().callEvent(infectionEvent);
            if (infectionEvent.isCancelled())
            {
                return;
            }

            Infection infection = new Infection(Clan.BLOODMOON, amount);
            human.setInfection(infection);
            locale.sendLocale(player, true, "werewolf.infection.start.bite");
        }
    }

    /*
     * Wild wolf mobs can infect humans.
     */
    @EventHandler(ignoreCancelled=true, priority=EventPriority.MONITOR)
    public void onWolfInfect(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Wolf wolf) || !(event.getEntity() instanceof Player player))
        {
            return;
        }

        if (player.hasMetadata("NPC") || wolf.hasMetadata("NPC"))
        {
            return;
        }

        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        int amount = config.getInt("werewolf.infection.wolf.amount");
        int chance = config.getInt("werewolf.infection.wolf.chance");
        if (RandomUtil.check(chance) & !human.isInfected())
        {
            Human.Infection infection = new Human.Infection(Clan.SILVERMANE, amount);
            human.setInfection(infection);
            locale.sendLocale(player, true, "werewolf.infection.start.wolf");
        }
    }

    /*
     * Untransform on log out
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onWerewolfQuit(PlayerQuitEvent event)
    {
        Player player = event.getPlayer();
        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        if (werewolf.isWolfForm())
        {
            WerewolfFormEvent transformEvent = new WerewolfFormEvent(werewolf, false, true);
            Bukkit.getPluginManager().callEvent(transformEvent);
        }
    }

    /*
     * Werewolves hit harder when using their fist. Using a weapon would make it do almost no damage.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onWerewolfAttack(EntityDamageByEntityEvent event)
    {
        //Cancel if the event was cancelled or not a player
        if (!(event.getDamager() instanceof Player attacker))
        {
            return;
        }

        if (event.getDamageSource().getDamageType().equals(DamageType.INDIRECT_MAGIC))
        {
            return;
        }

        UUID playerId = attacker.getUniqueId();
        Werewolf werewolf = races.getOrigin(playerId, Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        ItemStack item = attacker.getInventory().getItemInMainHand();
        Leader alpha = leaders.getLeader(werewolf.getClan());
        String type = alpha != null &&
                werewolf.getPlayerId().equals(alpha.getLeaderId()) ? "alpha" : "werewolf";
        if (werewolf.isWolfForm())
        {
            double levelScale = config.getDouble("werewolf.stats.level-scale");
            double baseScale = config.getDouble("werewolf.stats.base-scale");
            if (event.getCause().equals(DamageCause.ENTITY_ATTACK))
            {
                if (item.getType().equals(Material.AIR))
                {
                    double punchStat = config.getDouble("werewolf.stats." +
                            werewolf.getClan().toString().toLowerCase() + "." + type + ".fist-damage");
                    event.setDamage(event.getDamage() + Math.min(punchStat * (levelScale * werewolf.getLevel()),
                            punchStat) + (punchStat * baseScale));
                }
                else
                {
                    double itemStat = config.getDouble("werewolf.stats." +
                            werewolf.getClan().toString().toLowerCase() + "." + type + ".item-damage");
                    event.setDamage(itemStat);
                }
            }
        }
        else
        {
            return;
        }

        if (!(event.getEntity() instanceof LivingEntity entity))
        {
            return;
        }

        //Override combat damage based on what's on your hands
        String clan = werewolf.getClan().toString().toLowerCase();
        if (item.getType().equals(Material.AIR))
        {
            if (!event.getCause().equals(DamageCause.ENTITY_ATTACK))
            {
                return;
            }

            Talent shredder = werewolf.getTalent("Shredder");
            Talent relentless = werewolf.getTalent("Relentless");
            Talent rabies = werewolf.getTalent("Rabies");
            Talent beastmaster = werewolf.getTalent("Beastmaster");
            Talent disable = werewolf.getTalent("Disable");
            if (entity instanceof Player defender)
            {
                if (shredder != null && (HeavenDuelsAPI.isDueling(defender.getUniqueId(),
                        attacker.getUniqueId()) || !event.isCancelled()))
                {
                    int addition = shredder.getInt("durability");
                    for (ItemStack armor : defender.getInventory().getArmorContents())
                    {
                        if (armor != null && armor.getItemMeta() instanceof Damageable damageable &&
                                damageable.hasMaxDamage())
                        {
                            int maxDurability = damageable.getMaxDamage();
                            short durability = (short) (damageable.getDamage() + addition);
                            if (werewolf.isWolfForm())
                            {
                                damageable.setDamage(Math.min((durability + addition), maxDurability));
                            }
                        }
                    }
                }

                if (disable != null && (HeavenDuelsAPI.isDueling(defender.getUniqueId(),
                    attacker.getUniqueId()) || !event.isCancelled()))
                {
                    double percent = disable.getDouble("percent");
                    int duration = disable.getInt("duration");
                    if (RandomUtil.check(percent))
                    {
                        ItemStack current = defender.getInventory().getItemInMainHand();
                        if (!current.getType().equals(Material.AIR))
                        {
                            defender.setCooldown(current.getType(), duration);
                            defender.getWorld().playSound(defender, Sound.ITEM_CROSSBOW_SHOOT, 1.0F, 0.75F);
                        }
                    }
                }
            }

            BukkitRunnable relentlessTask = new BukkitRunnable()
            {
                @Override
                public void run()
                {
                    if (relentlessTasks.get(attacker.getUniqueId()) != null)
                    {
                        relentlessTasks.get(attacker.getUniqueId()).cancel();
                        relentlessTasks.remove(attacker.getUniqueId());
                    }
                }
            };

            if (relentless != null)
            {
                if (relentlessTasks.get(entity.getUniqueId()) != null)
                {
                    relentlessTasks.get(entity.getUniqueId()).cancel();
                    relentlessTasks.remove(entity.getUniqueId());
                }

                int delay = relentless.getInt("delay");
                relentlessTasks.put(entity.getUniqueId(), relentlessTask.runTaskLater(HeavenRaces.getInstance(),
                        delay));
            }

            double relentlessPercent = Talent.get("Relentless").getDouble("percent");
            if (relentlessTasks.get(attacker.getUniqueId()) != null && (HeavenDuelsAPI.isDueling(attacker.getUniqueId())
                    || !event.isCancelled()))
            {
                event.setDamage(event.getDamage() * relentlessPercent);
            }

            if (rabies != null && (HeavenDuelsAPI.isDueling(attacker.getUniqueId()) || !event.isCancelled()))
            {
                double percent = rabies.getDouble("percent");
                int times = rabies.getInt("times");
                int interval = rabies.getInt("interval");
                int level = 1;
                if (attacker.hasPotionEffect(PotionEffectType.HASTE))
                {
                    level += (attacker.getPotionEffect(PotionEffectType.HASTE).getAmplifier() + 1);
                }

                List<RabiesTask> tasks = rabiesTasks.getOrDefault(entity.getUniqueId(),
                        new ArrayList<>());
                boolean alreadyGiven = false;
                for (RabiesTask task : new ArrayList<>(tasks))
                {
                    if (task.getWerewolf().equals(werewolf))
                    {
                        task.updateTimer(times, interval);
                        alreadyGiven = true;
                    }
                }

                if (!alreadyGiven)
                {
                    RabiesTask task = new RabiesTask(rabiesTasks, entity, werewolf, percent, times, level);
                    tasks.add(task);
                    task.updateTimer(times, interval);
                }

                if (!tasks.isEmpty())
                {
                    rabiesTasks.put(entity.getUniqueId(), tasks);
                }
            }

            if (beastmaster != null && (HeavenDuelsAPI.isDueling(attacker.getUniqueId()) || !event.isCancelled()))
            {
                double damage = beastmaster.getDouble("damage");
                int range = beastmaster.getInt("range");
                double maxDamage = beastmaster.getDouble("max-damage");
                for (Entity nearbyEntity: attacker.getNearbyEntities(range, range, range))
                {
                    if (nearbyEntity instanceof Wolf wolf && wolf.isTamed() && attacker.equals(wolf.getOwner()))
                    {
                        damage++;
                    }
                }

                event.setDamage(Math.max(event.getDamage() + damage, maxDamage));
            }
        }
        else
        {
            double itemStat = config.getDouble("werewolf.stats." + clan + "." + type + ".item-damage");
            event.setDamage(itemStat);
        }
    }

    /*
     * If a werewolf of the same clan kills their alpha, they become the new alpha.
     */
    @EventHandler(ignoreCancelled = true)
    public void onAlphaDeath(PlayerDeathEvent event)
    {
        Player player = event.getEntity();
        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        Leader alpha = leaders.getLeader(werewolf.getClan());
        if (alpha == null)
        {
            return;
        }

        if (!alpha.getLeaderId().equals(werewolf.getPlayerId()))
        {
            return;
        }

        Player killer = player.getKiller();
        if (killer == null)
        {
            return;
        }

        Werewolf werewolfKiller = races.getOrigin(killer.getUniqueId(), Werewolf.class);
        if (werewolfKiller == null)
        {
            return;
        }

        Clan clan = werewolf.getClan();
        if (!clan.equals(werewolfKiller.getClan()))
        {
            return;
        }

        leaders.setLeader(werewolfKiller);
        skins.removeSkin(player);
        skins.applySkin(killer, "alpha");
        for (Player spectator : Bukkit.getOnlinePlayers())
        {
            locale.sendLocale(spectator, true, "werewolf.alpha.killed", "{killer}",
                    killer.getDisplayName(), "{player}", player.getDisplayName(), "{clan}",
                    LocaleData.capitalize(clan.toString()));
        }
    }

    /*
     * First Alpha is made from showing dominance.
     */
    @EventHandler(ignoreCancelled = true)
    public void onAlphaDominate(PlayerDeathEvent event)
    {
        Player player = event.getEntity();
        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        Leader alpha = leaders.getLeader(werewolf.getClan());
        if (alpha == null)
        {
            return;
        }

        if (!alpha.getLeaderId().equals(werewolf.getPlayerId()))
        {
            return;
        }

        Player killer = player.getKiller();
        if (killer == null)
        {
            return;
        }

        Werewolf werewolfKiller = races.getOrigin(killer.getUniqueId(), Werewolf.class);
        if (werewolfKiller == null)
        {
            return;
        }

        Clan clan = werewolf.getClan();
        if (!clan.equals(werewolfKiller.getClan()))
        {
            return;
        }

        leaders.setLeader(werewolfKiller);
        skins.removeSkin(player);
        if (werewolfKiller.isWolfForm())
        {
            skins.applySkin(killer, "alpha");
        }

        for (Player spectator : Bukkit.getOnlinePlayers())
        {
            locale.sendLocale(spectator, true, "werewolf.alpha.killed", "{killer}",
                    killer.getDisplayName(), "{player}", player.getDisplayName(), "{clan}",
                    LocaleData.capitalize(clan.toString()));
        }
    }


    /*
     * Werewolves cannot wear armor in wolf form.
     */
    @EventHandler(ignoreCancelled = true)
    public void onWerewolfArmorEquip(ArmorEquipEvent event)
    {
        Player player = event.getPlayer();
        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf != null && werewolf.isWolfForm())
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTamedWolfAttack(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Wolf wolf))
        {
            return;
        }

        if (!wolf.isTamed())
        {
            return;
        }

        if (!(wolf.getOwner() instanceof Player player))
        {
            return;
        }

        Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
        if (werewolf == null)
        {
            return;
        }

        Talent beastmaster = werewolf.getTalent("Beastmaster");
        if (beastmaster == null)
        {
            return;
        }

        double percent = beastmaster.getDouble("wolf-buff");
        event.setDamage(event.getDamage() * percent);
    }

    @EventHandler(ignoreCancelled = true)
    public void onWerewolfHowl(WerewolfHowlEvent event)
    {
        Werewolf werewolf = event.getWerewolf();
        Player player = werewolf.getPlayer();
        FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_HOWL);
        Moon moon = moons.getMoon(player.getWorld());
        double power = 0.0;
        if (moon != null)
        {
            Moon.MoonPhase phase = moon.getCurrentPhase();
            if (phase != null)
            {
                power = phase.getPower();
            }
        }

        double xp = config.getDouble("xp.werewolf.howl") * power;
        ExperienceGainEvent xpEvent = new ExperienceGainEvent(werewolf, xp);
        Bukkit.getPluginManager().callEvent(xpEvent);
        if (!xpEvent.isCancelled())
        {
            if (xp > 0)
            {
                int oldLevel = (int) werewolf.getLevel();
                werewolf.addLevel(xpEvent.getXp());
                int newLevel = (int) werewolf.getLevel();
                if (newLevel > oldLevel)
                {
                    LevelUpEvent levelEvent = new LevelUpEvent(werewolf, newLevel);
                    Bukkit.getPluginManager().callEvent(levelEvent);
                }

                locale.sendLocale(player, "werewolf.howl.xp", "{xp}",
                        String.format("%.2f", xp), "{total}", String.format("%.2f", werewolf.getLevel()));
            }
            else
            {
                locale.sendLocale(player, true, "werewolf.howl.activate");
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onWerewolfGrowl(WerewolfGrowlEvent event)
    {
        Werewolf werewolf = event.getWerewolf();
        Player player = werewolf.getPlayer();
        FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_GROWL);
    }
}
