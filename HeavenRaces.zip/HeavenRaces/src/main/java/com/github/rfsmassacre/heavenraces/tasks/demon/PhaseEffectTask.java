package com.github.rfsmassacre.heavenraces.tasks.demon;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class PhaseEffectTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final RaceManager races;
    private final int amount;
    private final double spread;

    public PhaseEffectTask()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.amount = config.getInt("demon.phase-form.amount");
        this.spread = config.getDouble("demon.phase-form.spread");
    }

    /**
     * Runs this operation.
     */
    @Override
    public void run()
    {
        for (Demon demon : races.getOrigins(Demon.class))
        {
            if (!demon.isOnline() || !demon.isPhaseForm())
            {
                continue;
            }

            Player player = demon.getPlayer();
            player.getWorld().spawnParticle(Particle.LARGE_SMOKE,
                    player.getLocation().add(0, player.getHeight() / 2, 0), amount, spread, spread, spread);
        }
    }
}
