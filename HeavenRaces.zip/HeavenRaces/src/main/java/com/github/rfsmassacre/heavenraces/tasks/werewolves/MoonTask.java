package com.github.rfsmassacre.heavenraces.tasks.werewolves;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.WerewolfFormEvent;
import com.github.rfsmassacre.heavenraces.managers.MoonManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.moons.Moon.MoonPhase;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import com.github.rfsmassacre.heavenraces.utils.SunUtil;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Collection;
import java.util.Set;
import java.util.UUID;

public class MoonTask extends BukkitRunnable
{
    private static final String KEY = "werewolf.full-moon";

    private final PaperLocale locale;
    private final RaceManager races;
    private final MoonManager moons;

    public MoonTask(HeavenRaces instance)
    {
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
        this.moons = instance.getMoonManager();
    }

    @Override
    public void run()
    {
        Set<Werewolf> werewolves = races.getOrigins(Werewolf.class);
        Collection<Moon> allMoons = moons.getMoons();
        if (werewolves.isEmpty() || allMoons.isEmpty())
        {
            return;
        }

        for (Origin origin : races.getOrigins(Origin.class))
        {
            if (!(origin instanceof Werewolf werewolf))
            {
                BossBarUtil.removeBossBar(KEY, origin.getPlayerId());
                continue;
            }

            Player player = werewolf.getPlayer();
            if (player == null || player.isDead())
            {
                continue;
            }

            UUID playerId = player.getUniqueId();
            Moon moon = moons.getMoon(player.getWorld());
            if (moon == null)
            {
                BossBarUtil.removeBossBar(KEY, playerId);
                continue;
            }

            MoonPhase moonPhase = moon.getCurrentPhase();
            if (moonPhase != null)
            {
                double progress = 1.0 - ((double)(moon.getTime() - moonPhase.getStart()) /
                        (double)(moonPhase.getEnd() - moonPhase.getStart()));
                BossBarUtil.updateBossBar(player, progress, KEY, "{moonPhase}",
                        LocaleData.capitalize(moonPhase.toString()), "{power}",
                        Integer.toString((int) (moonPhase.getPower() * 100)));
                Block block = player.getLocation().getBlock().getRelative(BlockFace.UP);
                double terrain = SunUtil.getTerrainOpacity(block);
                if (terrain == 1.0)
                {
                    continue;
                }

                if (werewolf.isWolfForm())
                {
                    moon.addTransformed(player.getUniqueId());
                    werewolf.setTransformTime(-1);
                    continue;
                }

                WerewolfFormEvent event = new WerewolfFormEvent(werewolf, true);
                Bukkit.getPluginManager().callEvent(event);
                if (!event.isCancelled())
                {
                    moon.addTransformed(player.getUniqueId());
                    werewolf.setTransformTime(-1);
                    locale.sendLocale(player, true, "werewolf.wolf-form.full-moon");
                }
            }
            else
            {
                BossBarUtil.removeBossBar(KEY, playerId);
                if (!moon.hasTransformed(playerId))
                {
                    continue;
                }

                moon.removeTransformed(playerId);
                if (!werewolf.isWolfForm())
                {
                    continue;
                }

                WerewolfFormEvent event = new WerewolfFormEvent(werewolf, false);
                Bukkit.getPluginManager().callEvent(event);
                if (!event.isCancelled())
                {
                    locale.sendLocale(player, true, "werewolf.wolf-form.sun");
                }
            }
        }
    }
}
