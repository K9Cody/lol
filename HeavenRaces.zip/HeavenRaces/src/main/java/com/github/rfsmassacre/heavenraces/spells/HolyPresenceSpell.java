package com.github.rfsmassacre.heavenraces.spells;

import org.bukkit.entity.LivingEntity;

public class HolyPresenceSpell extends Spell
{
    public HolyPresenceSpell()
    {
        super("holyPresence");
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        return true;
    }
}
