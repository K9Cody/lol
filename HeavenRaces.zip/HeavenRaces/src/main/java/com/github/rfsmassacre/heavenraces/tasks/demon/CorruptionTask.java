package com.github.rfsmassacre.heavenraces.tasks.demon;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.SpellTargetEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Spirit;
import com.github.rfsmassacre.heavenraces.spells.CorruptionSpell;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class CorruptionTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public CorruptionTask()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    /**
     * Runs this operation.
     */
    @Override
    public void run()
    {
        for (Demon demon : races.getOrigins(Demon.class))
        {
            if (!demon.isOnline() || !(demon.isSpiritForm() && demon.getRank().equals(Spirit.Rank.SERAPH)))
            {
                continue;
            }

            double range = config.getDouble("demon.range");
            for (Entity entity : demon.getPlayer().getNearbyEntities(range, range, range))
            {
                if (!(entity instanceof Player player))
                {
                    continue;
                }

                Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
                if (origin == null || !origin.isOnline() || origin instanceof Spirit)
                {
                    continue;
                }

                CorruptionSpell spell = (CorruptionSpell) Spell.getSpell("corruption");
                if (spell == null)
                {
                    continue;
                }

                SpellTargetEvent event = new SpellTargetEvent(demon.getPlayer(), spell, player);
                Bukkit.getPluginManager().callEvent(event);
                if (!event.isCancelled())
                {
                    origin.addCorruption(1);
                }
            }
        }
    }
}
