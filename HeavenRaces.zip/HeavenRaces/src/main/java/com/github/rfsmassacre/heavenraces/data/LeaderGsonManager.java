package com.github.rfsmassacre.heavenraces.data;

import com.github.rfsmassacre.heavenlibrary.paper.managers.PaperGsonManager;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import org.bukkit.Bukkit;

public class LeaderGsonManager extends PaperGsonManager<Leader>
{
    public LeaderGsonManager()
    {
        super(HeavenRaces.getInstance(), "leaders", Leader.class);
    }

    public void write(Leader leader)
    {
        String fileName;
        if (leader.getRace().equals(Race.WEREWOLF) && leader.getClan() != null)
        {
            fileName = leader.getClan().toString().toLowerCase();
        }
        else
        {
            fileName = leader.getRace().toString().toLowerCase();
        }

        write(fileName, leader);
    }

    public void writeAsync(Leader leader)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () -> write(leader));
    }

    public void delete(Leader leader)
    {
        String fileName = leader.getRace().toString().toLowerCase();
        if (leader.getRace().equals(Race.WEREWOLF) && leader.getClan() != null)
        {
            fileName = leader.getClan().toString().toLowerCase();
        }

        delete(fileName);
    }

    public void deleteAsync(Leader leader)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () -> delete(leader));
    }
}
