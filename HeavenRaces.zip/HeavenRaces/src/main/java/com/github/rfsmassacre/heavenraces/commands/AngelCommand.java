package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.SpiritFormEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Angel;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public class AngelCommand extends PaperCommand
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public AngelCommand()
    {
        super(HeavenRaces.getInstance(), "angel");

        HeavenRaces instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
    }

    /*
     * Werewolf main command
     */
    private class InfoCommand extends PaperSubCommand
    {
        public InfoCommand()
        {
            super("info", "heavenraces.angel.info");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Angel angel = races.getOrigin(player.getUniqueId(), Angel.class);
            if (angel == null)
            {
                locale.sendLocale(player, true, "invalid.not-angel");
                return;
            }

            locale.sendMessage(player, RaceCommand.getMenu(angel));
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Spirit Form
     */
    private class SpiritFormCommand extends PaperSubCommand
    {
        public SpiritFormCommand()
        {
            super("transform", "heavenraces.angel.transform");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Angel angel = races.getOrigin(player.getUniqueId(), Angel.class);
            if (angel == null)
            {
                locale.sendLocale(player, true, "angel.spirit-form.not-angel");
                return;
            }

            if (angel.isSpiritForm())
            {
                SpiritFormEvent event = new SpiritFormEvent(angel, false);
                Bukkit.getPluginManager().callEvent(event);
                if (event.isCancelled())
                {
                    locale.sendLocale(player, true, "angel.spirit-form.cant-toggle");
                }
            }
            else
            {
                int level = config.getInt("level-reward.angel.spirit-form");
                if (angel.getLevel() < level)
                {
                    locale.sendLocale(player, true, "level-reward.not-level", "{level}",
                            Integer.toString(level), "{ability}", "Spirit Form");
                    return;
                }

                SpiritFormEvent event = new SpiritFormEvent(angel, true);
                Bukkit.getPluginManager().callEvent(event);
                if (event.isCancelled())
                {
                    locale.sendLocale(player, true, "angel.spirit-form.cant-toggle");
                }
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }
}
