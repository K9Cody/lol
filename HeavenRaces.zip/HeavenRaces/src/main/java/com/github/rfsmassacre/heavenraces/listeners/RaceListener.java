package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenclans.HeavenClansAPI;
import com.github.rfsmassacre.heavenclans.clans.Clan;
import com.github.rfsmassacre.heavenduels.HeavenDuelsAPI;
import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.LevelUpEvent;
import com.github.rfsmassacre.heavenraces.events.RaceChangeEvent;
import com.github.rfsmassacre.heavenraces.events.SpellTargetEvent;
import com.github.rfsmassacre.heavenraces.items.food.GoldenFood;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.managers.SkinManager;
import com.github.rfsmassacre.heavenraces.players.*;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.tasks.LocationTask;
import com.github.rfsmassacre.heavenraces.utils.CombatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RaceListener implements Listener
{
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;
    private final LeaderManager leaders;
    private final SkinManager skins;

    public RaceListener()
    {
        HeavenRaces instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
        this.leaders = instance.getLeaderManager();
        this.skins = instance.getSkinManager();
    }

    /*
     * Diets: Handling the diet of each race respectively.
     *
     * Eating also gives XP to the player.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPlayerFoodChange(FoodLevelChangeEvent event)
    {
        Player player = (Player) event.getEntity();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        Race race = origin.getRace();
        String raceKey = race.toString().toLowerCase();
        List<String> dietList = config.getStringList("diet." + raceKey);
        if (event.getItem() == null)
        {
            return;
        }

        Material food = event.getItem().getType();
        if (player.getFoodLevel() > event.getFoodLevel())
        {
            return;
        }

        if (dietList.contains("ALL"))
        {
            return;
        }

        if (dietList.contains("NONE") || !dietList.contains(food.toString()))
        {
            if (origin instanceof Werewolf werewolf)
            {
                Talent omnivore = werewolf.getTalent("Omnivore");
                if (omnivore != null && !werewolf.isWolfForm())
                {
                    double percent = omnivore.getDouble("percent");
                    int foodGain = (int) ((event.getFoodLevel() - player.getFoodLevel()) * percent);
                    event.setFoodLevel(player.getFoodLevel() + foodGain);
                    return;
                }
            }

            event.setCancelled(true);
        }
        else
        {
            GoldenFood goldenFood = GoldenFood.of(event.getItem());
            if (goldenFood != null)
            {
                player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, 0));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
            }

            if (origin instanceof Werewolf werewolf)
            {
                if (werewolf.hasTalent("Satisfied"))
                {
                    int foodGain = event.getFoodLevel() - player.getFoodLevel();
                    PotionEffect saturation = new PotionEffect(PotionEffectType.SATURATION, foodGain, 0);
                    player.addPotionEffect(saturation);
                }

                Talent nourishment = werewolf.getTalent("Nourishment");
                if (nourishment != null)
                {
                    double percent = nourishment.getDouble("percent");
                    AttributeInstance attribute = player.getAttribute(Attribute.MAX_HEALTH);
                    if (attribute == null)
                    {
                        return;
                    }

                    int foodGain = event.getFoodLevel() - player.getFoodLevel();
                    int heal = (int) (foodGain * percent);
                    player.setHealth(Math.min(player.getHealth() + heal, attribute.getValue()));
                }
            }
        }
    }

    /*
     * Clear potion effects when someone is changing races.
     */
    @EventHandler
    public void onRaceChange(RaceChangeEvent event)
    {
        Origin origin = event.getOrigin();
        Player player = origin.getPlayer();
        Race race = origin.getRace();
        //Clear potion effects from previous race.
        for (PotionEffect effect : player.getActivePotionEffects())
        {
            player.removePotionEffect(effect.getType());
        }

        //Remove and delete leader when changing races, even if it's the same one.
        Leader leader = leaders.getLeader(race);
        if (origin instanceof Werewolf werewolf)
        {
            skins.removeSkin(player);
            Werewolf.Clan clan = werewolf.getClan();
            if (clan != null)
            {
                leader = leaders.getLeader(clan);
            }
        }
        else if (origin instanceof Spirit)
        {
            skins.removeSkin(player);
        }

        if (leader != null && leader.getLeaderId().equals(player.getUniqueId()))
        {
            leaders.removeLeader(leader);
            leaders.deleteLeaderAsync(leader);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onTeleportDuringForm(PlayerTeleportEvent event)
    {
        Player player = event.getPlayer();
        Location location = event.getTo();
        Location last = LocationTask.LOCATIONS.get(player.getUniqueId());
        if (last == null || (!last.getBlock().equals(location.getBlock())))
        {
            LocationTask.LOCATIONS.put(player.getUniqueId(), location);
        }
    }

    @EventHandler
    public void onLevelUp(LevelUpEvent event)
    {
        handleLeaderAssignment(event.getOrigin(), config.getInt("leader-timeout"));
    }

    private void handleLeaderAssignment(Origin origin, long timeOut)
    {
        Werewolf.Clan clan = origin instanceof Werewolf werewolf ? werewolf.getClan() : null;
        Leader currentLeader = (clan != null) ? leaders.getLeader(clan) : leaders.getLeader(origin.getRace());
        if (currentLeader != null)
        {
            races.getOrLoadOrigin(currentLeader.getLeaderId(), origin.getClass(), (leaderOrigin) ->
            {
                if (leaderOrigin == null || !leaderOrigin.getRace().equals(origin.getRace()) ||
                        leaderOrigin.offlineFor(timeOut) || HeavenClansAPI.isPeaceful(currentLeader.getLeaderId()))
                {
                    leaders.removeLeader(currentLeader);
                    leaders.deleteLeader(currentLeader);
                }

                if (clan != null && leaders.getLeader(clan) != null && origin.getRace().equals(Race.WEREWOLF))
                {
                    return; // Exit early, since we do not want to assign a new leader in this case
                }

                assignNewLeader(origin, timeOut);
            });
        }
        else
        {
            assignNewLeader(origin, timeOut);
        }
    }

    private void assignNewLeader(Origin origin, long timeOut)
    {
        // Fetch all candidates asynchronously
        races.getAllOrigins(origin.getClass(), (allOrigins) ->
        {
            if (allOrigins.isEmpty())
            {
                return;
            }

            // Filter and sort the candidates
            List<Origin> sorted = new ArrayList<>(allOrigins);
            sorted.sort(Comparator.reverseOrder());
            Leader oldLeader;
            if (origin instanceof Werewolf werewolf)
            {
                oldLeader = leaders.getLeader(werewolf.getClan());
                sorted.removeIf((sortedOrigin) -> !(sortedOrigin instanceof Werewolf sortedWerewolf &&
                        werewolf.getClan().equals(sortedWerewolf.getClan())));
            }
            else
            {
                oldLeader = leaders.getLeader(origin.getRace());
            }

            for (Origin candidate : sorted)
            {
                if (candidate.offlineFor(timeOut) || HeavenClansAPI.isPeaceful(candidate.getPlayerId()))
                {
                    continue;
                }

                Leader newLeader;
                if (candidate instanceof Werewolf sortedWerewolf)
                {
                    newLeader = new Leader(sortedWerewolf.getPlayerId(), Race.WEREWOLF);
                }
                else
                {
                    newLeader = new Leader(candidate.getPlayerId(), candidate.getRace());
                }

                if (oldLeader != null && oldLeader.getLeaderId().equals(newLeader.getLeaderId()))
                {
                    return;
                }

                leaders.setLeader(newLeader);
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    String localeKey = candidate.getRace().name().toLowerCase();
                    locale.sendLocale(player, true, localeKey, "{player}", candidate.getDisplayName(),
                            "{clan}", (newLeader.getClan() != null ?
                                    LocaleData.capitalize(newLeader.getClan().toString()) : ""));
                }

                return;
            }
        });
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onSpawnDamage(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        if (HeavenDuelsAPI.isDueling(player.getUniqueId()))
        {
            return;
        }

        if (CombatUtil.isSpawnProtected(origin))
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onSpawnFoodLoss(FoodLevelChangeEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        if (player.getFoodLevel() > event.getFoodLevel() && CombatUtil.isSpawnProtected(origin))
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onSpawnTeleport(PlayerTeleportEvent event)
    {
        Player player = event.getPlayer();
        if (player.hasMetadata("teleport"))
        {
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        Race race = origin.getRace();
        if (CombatUtil.isRaceSpawn(event.getTo()) && !CombatUtil.isRaceSpawn(race, event.getTo()) &&
                !player.hasMetadata("teleport"))
        {
            event.setCancelled(true);
            locale.sendLocale(player, "race-spawn.teleport");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onRespawn(PlayerRespawnEvent event)
    {
        Player player = event.getPlayer();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        Location spawn = races.getSpawn(origin.getRace());
        if (spawn != null)
        {
            event.setRespawnLocation(spawn);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onSpellTargetSpawn(SpellTargetEvent event)
    {
        if (!(event.getTarget() instanceof Player player))
        {
            return;
        }


        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        Player defender = com.github.rfsmassacre.heavenclans.utils.CombatUtil.getSource(event.getTarget());
        Player attacker = com.github.rfsmassacre.heavenclans.utils.CombatUtil.getSource(event.getCaster());
        if (defender == null || attacker == null)
        {
            return;
        }


        if (!event.getSpell().isBeneficial())
        {
            if (HeavenDuelsAPI.isDueling(defender.getUniqueId(), attacker.getUniqueId()))
            {
                return;
            }

            Location location = player.getLocation();
            Race race = origin.getRace();
            if (CombatUtil.isRaceSpawn(location) && !CombatUtil.isRaceSpawn(race, location))
            {
                event.setCancelled(true);
                return;
            }

            if (HeavenClansAPI.isPeaceful(attacker.getUniqueId()) || HeavenClansAPI.isPeaceful(defender.getUniqueId()))
            {
                event.setCancelled(true);
                return;
            }

            Clan defendingClan = Clan.getClan(defender);
            Clan attackingClan = Clan.getClan(attacker);
            if ((defendingClan != null && attackingClan != null) && (defendingClan.equals(attackingClan) ||
                    defendingClan.getRelation(attackingClan).equals(Clan.Relation.ALLY)))
            {
                event.setCancelled(true);
            }

        }
        else
        {
            if (HeavenDuelsAPI.isDueling(defender.getUniqueId(), attacker.getUniqueId()))
            {
                event.setCancelled(true);
                return;
            }

            Clan defendingClan = Clan.getClan(defender);
            Clan attackingClan = Clan.getClan(attacker);
            if ((defendingClan != null && attackingClan != null) && (defendingClan.equals(attackingClan) ||
                    !defendingClan.getRelation(attackingClan).equals(Clan.Relation.ALLY)))
            {
                event.setCancelled(true);
            }
        }
    }
}
