package com.github.rfsmassacre.heavenraces.items.trackers;

import org.bukkit.Material;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;

public class VampireTracker extends TrackerItem
{
    public VampireTracker()
    {
        super("VampireTracker", Race.VAMPIRE);
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapedRecipe recipe = new ShapedRecipe(key, item);
        recipe.shape("GGG", "GCG", "GGG");
        recipe.setIngredient('G', Material.GHAST_TEAR);
        recipe.setIngredient('C', Material.COMPASS);
        return recipe;
    }
}
