package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenraces.events.WerewolfGrowlEvent;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;

public class GrowlSpell extends Spell
{
    public GrowlSpell()
    {
        super("growl");
    }

    @Override
    public boolean canCast(LivingEntity entity)
    {
        Werewolf werewolf = getOrigin(entity);
        return werewolf != null && werewolf.getLevel() >= level && werewolf.isWolfForm();
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        Werewolf werewolf = getOrigin(entity);
        WerewolfGrowlEvent event = new WerewolfGrowlEvent(werewolf);
        Bukkit.getPluginManager().callEvent(event);
        return true;
    }
}
