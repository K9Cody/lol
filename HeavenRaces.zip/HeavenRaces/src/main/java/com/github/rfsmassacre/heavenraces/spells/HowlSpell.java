package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenraces.events.WerewolfHowlEvent;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;

public class HowlSpell extends Spell
{
    public HowlSpell()
    {
        super("howl");
    }

    @Override
    public boolean canCast(LivingEntity entity)
    {
        Werewolf werewolf = getOrigin(entity);
        return werewolf != null && werewolf.getLevel() >= level && werewolf.isWolfForm();
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        Werewolf werewolf = getOrigin(entity);
        WerewolfHowlEvent event = new WerewolfHowlEvent(werewolf);
        Bukkit.getPluginManager().callEvent(event);
        return true;
    }
}
