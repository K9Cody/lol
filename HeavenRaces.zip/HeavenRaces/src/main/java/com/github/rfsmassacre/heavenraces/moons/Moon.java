package com.github.rfsmassacre.heavenraces.moons;

import lombok.Getter;
import org.bukkit.World;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


public class Moon
{
    @Getter
    public enum MoonPhase
    {
        FULL_MOON(13000L, 24000L, 8, 1.0),
        WANING_GIBBOUS(37000L, 48000L, 7, 0.75),
        LAST_QUARTER(61000L, 72000L, 6, 0.5),
        WANING_CRESCENT(85000L, 94000L, 5, 0.25),
        NEW_MOON(109000L, 120000L, 4, 0.1),
        WAXING_CRESCENT(133000L, 144000L, 3, 0.25),
        FIRST_QUARTER(157000L, 168000L, 2, 0.5),
        WAXING_GIBBOUS(181000L, 192000L, 1, 0.75);

        private final long start;
        private final long end;
        private final int position;
        private final double power;

        MoonPhase(long start, long end, int position, double power)
        {
            this.start = start;
            this.end = end;
            this.position = position;
            this.power = power;
        }

        public boolean inCycle(World world)
        {
            long ticks = world.getFullTime() % WEEKEND;
            return ticks >= this.start && ticks <= this.end;
        }

        public static MoonPhase fromString(String name)
        {
            for (MoonPhase phase : MoonPhase.values())
            {
                if (phase.toString().equalsIgnoreCase(name))
                {
                    return phase;
                }
            }

            return null;
        }
    }

    private static final long WEEKEND = 192000L;
    private final World world;
    private final Set<UUID> transformedIds;

    public long getTime()
    {
        return world.getFullTime() % WEEKEND;
    }

    public Moon(World world) 
    {
        this.world = world;
        this.transformedIds = new HashSet<>();
    }

    public World getWorld()
    {
        return this.world;
    }
    public boolean hasTransformed(UUID playerId)
    {
        return this.transformedIds.contains(playerId);
    }
    public void addTransformed(UUID playerId)
    {
        this.transformedIds.add(playerId);
    }
    public void removeTransformed(UUID playerId)
    {
        this.transformedIds.remove(playerId);
    }
    public void clearTransformed()
    {
        this.transformedIds.clear();
    }
    public Set<UUID> getTransformedIds()
    {
        return this.transformedIds;
    }

    public MoonPhase getCurrentPhase()
    {
        for (MoonPhase phase : MoonPhase.values())
        {
            if (phase.inCycle(this.world))
            {
                return phase;
            }
        }

        return null;
    }

    public MoonPhase getNextPhase()
    {
        for (MoonPhase phase : MoonPhase.values())
        {
            if (getTime() <= phase.start)
            {
                return phase;
            }
        }

        return null;
    }

    public MoonPhase getMoonPhase()
    {
        return this.getCurrentPhase() != null ? this.getCurrentPhase() : this.getNextPhase();
    }
    public void setPhase(MoonPhase phase)
    {
        this.world.setFullTime(phase.start);
    }
}
