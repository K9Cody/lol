package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.CooldownEvent;
import com.github.rfsmassacre.heavenraces.events.RaceChangeEvent;
import com.github.rfsmassacre.heavenraces.events.SpellCastEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public abstract class BuffSpell extends Spell
{
    private final Set<BukkitTask> tasks;

    protected final Map<UUID, Long> casters;
    protected final int duration, effectInterval;
    protected final boolean toggle;

    public BuffSpell(String internalName)
    {
        super(internalName);

        this.tasks = new HashSet<>();
        this.casters = new HashMap<>();
        this.duration = config.getInt(internalName + ".duration");
        this.effectInterval = config.getInt(internalName + ".effect.interval");
        this.toggle = config.getBoolean(internalName + ".toggle");
    }

    public boolean isActive(LivingEntity entity)
    {
        return casters.containsKey(entity.getUniqueId());
    }

    public long getDuration(LivingEntity entity)
    {
        Long lastCast = casters.getOrDefault(entity.getUniqueId(), 0L);
        if (lastCast != null)
        {
            return (this.duration / 20L * 1000L) - (System.currentTimeMillis() - lastCast);
        }

        return 0L;
    }

    protected void activateTimer()
    {
        tasks.add(new BukkitRunnable()
        {
            @Override
            public void run()
            {
                for (UUID casterId : casters.keySet())
                {
                    if (Bukkit.getEntity(casterId) instanceof LivingEntity caster)
                    {
                        effect(caster);
                    }
                }
            }
        }.runTaskTimer(HeavenRaces.getInstance(), 0L, effectInterval));
    }

    protected void deactivateTimers()
    {
        for (BukkitTask task : tasks)
        {
            task.cancel();
        }

        tasks.clear();
    }

    protected abstract void effect(LivingEntity entity);

    public void end(LivingEntity entity)
    {
        if (!deactivate(entity))
        {
            return;
        }

        casters.remove(entity.getUniqueId());
        cooldowns.put(entity.getUniqueId(), System.currentTimeMillis());
        CooldownEvent cooldownEvent = new CooldownEvent(entity, this);
        Bukkit.getPluginManager().callEvent(cooldownEvent);
    }

    public abstract boolean deactivate(LivingEntity entity);

    public void cast(LivingEntity entity)
    {
        if (isActive(entity) && toggle)
        {
            end(entity);
            return;
        }

        if (!canCast(entity))
        {
            return;
        }

        long cooldown = cooldowns.getOrDefault(entity.getUniqueId(), 0L);
        if (System.currentTimeMillis() - cooldown > this.cooldown)
        {
            SpellCastEvent event = new SpellCastEvent(entity, this);
            Bukkit.getPluginManager().callEvent(event);
            if (!event.isCancelled())
            {
                if (activate(entity))
                {
                    if (!entity.isValid())
                    {
                        end(entity);
                        return;
                    }

                    casters.put(entity.getUniqueId(), System.currentTimeMillis());
                    if (duration <= 0)
                    {
                        return;
                    }

                    Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), () -> end(entity), duration);
                }
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onKitChange(RaceChangeEvent event)
    {
        Player player = event.getOrigin().getPlayer();
        if (player != null && isActive(player))
        {
            end(player);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event)
    {
        Player player = event.getPlayer();
        if (isActive(player))
        {
            end(player);
        }
    }
}
