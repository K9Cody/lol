package com.github.rfsmassacre.heavenraces.managers;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.tasks.CorruptionTrackTask;
import com.github.rfsmassacre.heavenraces.tasks.InfectionTask;
import com.github.rfsmassacre.heavenraces.tasks.LocationTask;
import com.github.rfsmassacre.heavenraces.tasks.NegateTickTask;
import com.github.rfsmassacre.heavenraces.tasks.angels.GlideTask;
import com.github.rfsmassacre.heavenraces.tasks.demon.CorruptionTask;
import com.github.rfsmassacre.heavenraces.tasks.demon.HoverTask;
import com.github.rfsmassacre.heavenraces.tasks.demon.PhaseEffectTask;
import com.github.rfsmassacre.heavenraces.tasks.demon.PossessionTask;
import com.github.rfsmassacre.heavenraces.tasks.humans.GlowTask;
import com.github.rfsmassacre.heavenraces.tasks.humans.TrackerTask;
import com.github.rfsmassacre.heavenraces.tasks.vampire.*;
import com.github.rfsmassacre.heavenraces.tasks.werewolves.FormEffectTask;
import com.github.rfsmassacre.heavenraces.tasks.werewolves.MoonTask;
import com.github.rfsmassacre.heavenraces.tasks.werewolves.ScentTask;
import com.github.rfsmassacre.heavenraces.tasks.werewolves.TransformTask;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashSet;
import java.util.Set;

public class TaskManager
{
    private final HeavenRaces instance;
    private final PaperConfiguration config;

    private final Set<BukkitTask> tasks;

    public TaskManager()
    {
        this.instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();

        this.tasks = new HashSet<>();

        startTasks();
    }

    public void startTasks()
    {
        tasks.add(new InfectionTask(instance).runTaskTimer(instance, 0L,
                config.getInt("infection.interval")));
        tasks.add(new TemperatureTask(instance).runTaskTimer(instance, 0L,
                config.getInt("radiation.interval")));
        tasks.add(new TruceTask(instance).runTaskTimer(instance, 0L,
                config.getInt("vampire.truce.interval")));
        tasks.add(new NightEffectTask(instance).runTaskTimer(instance, 0L,
                config.getInt("vampire.passives.interval")));
        tasks.add(new HungerHealTask(instance).runTaskTimer(instance, 0L,
                config.getInt("vampire.regen-interval")));
        tasks.add(new BatFoodTask(instance).runTaskTimer(instance, 0L,
                config.getInt("vampire.bat-form.food-interval")));
        tasks.add(new BloodLustFoodTask(instance).runTaskTimer(instance, 0L,
                config.getInt("vampire.bloodlust.food-interval")));
        tasks.add(new FormEffectTask(instance).runTaskTimer(instance, 0L,
                config.getInt("werewolf.wolf-effects.interval")));
        tasks.add(new MoonTask(instance).runTaskTimer(instance, 0L,
                config.getInt("werewolf.moon.interval")));
        tasks.add(new ScentTask(instance).runTaskTimer(instance, 0L,
                config.getInt("werewolf.tracking.interval")));
        tasks.add(new TransformTask(instance).runTaskTimer(instance, 0L,
                config.getInt("werewolf.transform-time.interval")));
        tasks.add(new NegateTickTask(instance).runTaskTimer(instance, 0L,
                config.getInt("human.item.interval")));
        tasks.add(new GlideTask(instance).runTaskTimer(instance, 0L, config.getInt("angel.interval.wings")));
        tasks.add(new LocationTask().runTaskTimerAsynchronously(instance, 0L, 1L));
        tasks.add(new TrackerTask().runTaskTimer(instance, 20L, config.getInt("trackers.interval")));
        tasks.add(new GlowTask().runTaskTimer(instance, 0L, 20L));
        tasks.add(new CorruptionTask().runTaskTimer(instance, 0L,
                config.getInt("demon.interval.corruption")));
        tasks.add(new CorruptionTrackTask().runTaskTimer(instance, 0L, 5L));
        tasks.add(new PhaseEffectTask().runTaskTimer(instance, 0L, config.getInt("demon.interval.phase")));
        tasks.add(new PossessionTask().runTaskTimer(instance, 0L, config.getInt("demon.interval.possession")));
        tasks.add(new HoverTask().runTaskTimer(instance, 0L, config.getInt("demon.interval.wings")));
    }

    public void cancelTasks()
    {
        for (BukkitTask task : tasks)
        {
            task.cancel();
        }

        tasks.clear();
    }
}
