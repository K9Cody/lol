package com.github.rfsmassacre.heavenraces.players;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

import java.util.UUID;

@Getter
@Setter
public class Demon extends Spirit
{
    private boolean phaseForm;
    private UUID possessedId;

    public Demon()
    {
        super();

        this.race = Race.DEMON;
        setCorruption(100);
    }

    @Override
    public void updateStats()
    {
        clearStats();
    }

    public Demon(Player player, Rank rank)
    {
        super(player, Race.DEMON, rank);

        setCorruption(100);
    }

    public Demon(Origin origin, Rank rank)
    {
        super(origin, Race.DEMON, rank);

        setCorruption(100);
    }

    /**
     * Demons are ALWAYS 100% corrupted.
     * @return 100%.
     */
    public int getCorruption()
    {
        return 100;
    }
}