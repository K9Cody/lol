package com.github.rfsmassacre.heavenraces.spells;

import org.bukkit.entity.LivingEntity;

public class PossessSpell extends Spell
{
    public PossessSpell()
    {
        super("possess");
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        return false;
    }
}