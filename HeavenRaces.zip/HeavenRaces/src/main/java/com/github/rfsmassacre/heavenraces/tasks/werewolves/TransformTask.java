package com.github.rfsmassacre.heavenraces.tasks.werewolves;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.WerewolfFormEvent;
import com.github.rfsmassacre.heavenraces.managers.MoonManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

public class TransformTask extends BukkitRunnable
{
    private static final String KEY = "werewolf.wolf-form";

    private final PaperConfiguration config;
    private final RaceManager races;
    private final MoonManager moons;
    private final int interval;

    public TransformTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
        this.moons = instance.getMoonManager();
        this.interval = this.config.getInt("werewolf.transform-time.interval");
    }

    @Override
    public void run()
    {
        //For werewolves
        for (Origin origin : races.getOrigins(Origin.class))
        {
            if (!(origin instanceof Werewolf werewolf))
            {
                BossBarUtil.removeBossBar(KEY, origin.getPlayerId());
                continue;
            }

            Player player = werewolf.getPlayer();
            if (player == null)
            {
                continue;
            }

            UUID playerId = player.getUniqueId();
            werewolf.removeFatigueTime(interval);
            if (werewolf.getTransformTime() == -1)
            {
                BossBarUtil.removeBossBar(KEY, playerId);
                continue;
            }

            if (!werewolf.isWolfForm())
            {
                BossBarUtil.removeBossBar(KEY, playerId);
                continue;
            }

            Moon moon = moons.getMoon(player.getWorld());
            if (moon != null && moon.getCurrentPhase() != null)
            {
                BossBarUtil.removeBossBar(KEY, playerId);
                continue;
            }

            werewolf.removeTransformTime(interval);
            int transformTime = werewolf.getTransformTime();
            int maxTime = config.getInt("werewolf.transform-time.max");
            BossBarUtil.updateBossBar(player, (double) transformTime / maxTime, KEY);
            if (transformTime > 0)
            {
                continue;
            }

            BossBarUtil.removeBossBar(KEY, playerId);
            WerewolfFormEvent event = new WerewolfFormEvent(werewolf, false);
            Bukkit.getPluginManager().callEvent(event);
        }
    }
}
