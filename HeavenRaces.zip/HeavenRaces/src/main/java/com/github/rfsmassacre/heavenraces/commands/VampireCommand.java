package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.managers.TextManager;
import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.items.potions.HumanBloodBottle;
import com.github.rfsmassacre.heavenraces.items.potions.VampireBloodBottle;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.spells.BatFormSpell;
import com.github.rfsmassacre.heavenraces.spells.BloodlustSpell;
import com.github.rfsmassacre.heavenraces.spells.ShriekSpell;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import com.github.rfsmassacre.heavenraces.utils.FXUtil;
import com.github.rfsmassacre.heavenraces.utils.RandomUtil;
import com.google.common.collect.Lists;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.EntityEffect;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class VampireCommand extends PaperCommand
{
    private record Offer(UUID playerId, double health)
    {
    }

    private final HeavenRaces instance;
    private final PaperConfiguration config;
    private final TextManager text;
    private final RaceManager races;
    private final LeaderManager leaders;

    private final HashSet<UUID> shriekers;
    private final HashMap<UUID, Offer> offers;

    public VampireCommand()
    {
        super(HeavenRaces.getInstance(), "vampire");

        this.instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.text = instance.getTextManager();
        this.races = instance.getRaceManager();
        this.leaders = instance.getLeaderManager();

        this.shriekers = new HashSet<>();
        this.offers = new HashMap<>();
    }

    /*
     * Info command
     */
    private class InfoCommand extends PaperSubCommand
    {
        public InfoCommand()
        {
            super("info", "heavenraces.vampire.info");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "invalid.not-vampire");
                return;
            }

            locale.sendMessage(player, RaceCommand.getMenu(vampire));
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Bat Form
     */
    private class BatFormCommand extends PaperSubCommand
    {
        public BatFormCommand()
        {
            super("transform", "heavenraces.vampire.transform");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "vampire.bat-form.not-vampire");
                return;
            }

            BatFormSpell spell = (BatFormSpell) Spell.getSpell("bat-form");
            if (spell != null)
            {
                spell.cast(player);
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Bloostlust
     */
    private class BloodLustCommand extends PaperSubCommand
    {
        public BloodLustCommand()
        {
            super("bloodlust", "heavenraces.vampire.bloodlust");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "vampire.bloodlust.not-vampire");
                return;
            }

            BloodlustSpell spell = (BloodlustSpell) Spell.getSpell("blood-lust");
            if (spell != null)
            {
                spell.cast(player);
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Humans can offer their blood to vampires.
     */
    private class BloodOfferCommand extends PaperSubCommand
    {
        public BloodOfferCommand()
        {
            super("offer", "heavenraces.vampire.offer");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            //v o <player> <amount>
            if (args.length >= 3)
            {
                String playerName = args[1];
                String amount = args[2];
                try
                {
                    final Player target = Bukkit.getPlayer(playerName);
                    if (target == null)
                    {
                        locale.sendLocale(player, true, "invalid.no-player", "{name}", playerName);
                        return;
                    }

                    if (player.equals(target))
                    {
                        locale.sendLocale(player, true, "invalid.self");
                        return;
                    }

                    int health = (int)Double.parseDouble(amount);
                    if (health < 1 || health > 20)
                    {
                        locale.sendLocale(player, true, "vampire.offer.invalid");
                        return;
                    }

                    double distance = player.getLocation().distance(target.getLocation());
                    double max = config.getDouble("vampire.offer.distance");
                    if (distance > max)
                    {
                        locale.sendLocale(player, true, "vampire.offer.too-far");
                        return;
                    }

                    offers.put(target.getUniqueId(), new Offer(player.getUniqueId(), health));
                    new BukkitRunnable()
                    {
                        public void run()
                        {
                            offers.remove(target.getUniqueId());
                        }
                    }.runTaskLater(instance, config.getInt("vampire.offer.timeout"));

                    locale.sendLocale(player, true, "vampire.offer.sent", "{target}",
                            target.getDisplayName());
                    locale.sendLocale(target, true, "vampire.offer.received", "{player}",
                            player.getDisplayName(), "{hp}", Integer.toString(health));
                }
                catch (NumberFormatException exception)
                {
                    locale.sendLocale(player, true, "invalid.number", "{arg}", amount);
                }
            }
            else
            {
                locale.sendLocale(sender, true, "invalid.args", "{args}",
                        "vampire offer <player> <amount>");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }
            return suggestions;
        }
    }

    private class BloodAcceptCommand extends PaperSubCommand
    {
        public BloodAcceptCommand()
        {
            super("accept", "heavenraces.vampire.accept");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            UUID playerId = player.getUniqueId();
            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (!offers.containsKey(playerId))
            {
                locale.sendLocale(player, true, "vampire.offer.none");
                return;
            }

            Offer offer = offers.get(playerId);
            Player offerer = Bukkit.getPlayer(offer.playerId);
            if (offerer == null)
            {
                locale.sendLocale(player, true, "vampire.offer.logged-out");
                return;
            }

            double distance = offerer.getLocation().distance(player.getLocation());
            double max = config.getDouble("vampire.offer.distance");
            if (distance > max)
            {
                locale.sendLocale(player, true, "vampire.offer.too-far");
                return;
            }

            double senderHealth = offerer.getHealth() - offer.health;
            if (senderHealth < 0.0)
            {
                senderHealth = 0.0;
            }

            offerer.playEffect(EntityEffect.HURT);
            offerer.setHealth(senderHealth);
            Vampire raceSender = races.getOrigin(offerer.getUniqueId(), Vampire.class);
            if (raceSender != null)
            {
                int chance = config.getInt("vampire.infection.offer");
                double cost = config.getDouble("vampire.offer.cost");
                double amount = config.getDouble("vampire.offer.amount");
                double playerHealth = player.getHealth() - offer.health * cost;
                if (playerHealth < 0.0)
                {
                    playerHealth = 0.0;
                }

                player.playEffect(EntityEffect.HURT);
                player.setHealth(playerHealth);
                Human human = races.getOrigin(player.getUniqueId(), Human.class);
                if (human != null && RandomUtil.check(chance))
                {
                    human.setInfection(new Human.Infection(Race.VAMPIRE, amount));
                    locale.sendLocale(player, true, "infection.vampire.start.bite");
                }
            }

            if (vampire != null)
            {
                int hunger = player.getFoodLevel() + (int)offer.health;

                double cost = VampireCommand.this.config.getDouble("vampire.offer.cost");
                AttributeInstance healthAttribute = player.getAttribute(Attribute.MAX_HEALTH);
                if (healthAttribute == null)
                {
                    return;
                }

                double maxHealth = healthAttribute.getValue();
                double health = player.getHealth() + offer.health * cost;
                if (health > maxHealth)
                {
                    health = maxHealth;
                }
                player.setHealth(health);

                if (hunger > 20)
                {
                    hunger = 20;
                }
                player.setFoodLevel(hunger);
                FXUtil.playEffect(player, Effect.POTION_BREAK);
                FXUtil.playEffect(offerer, Effect.POTION_BREAK);
            }
            locale.sendLocale(player, true, "vampire.offer.accepted", "{hp}",
                    Integer.toString((int)offer.health));
            locale.sendLocale(offerer, true, "vampire.offer.filled", "{player}",
                    player.getDisplayName(), "{hp}", Integer.toString((int)offer.health));
            offers.remove(playerId);
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] strings)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Humans and Vampires can bottle up their blood
     */
    private class BloodBottleCommand extends PaperSubCommand
    {
        public BloodBottleCommand()
        {
            super("bloodbottle", "heavenraces.vampire.bloodbottle");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
            if (origin instanceof Vampire vampire && vampire.inBatForm())
            {
                locale.sendLocale(player, true, "bottle.bat-form");
                return;
            }

            ItemStack bottle = player.getInventory().getItemInMainHand();
            if (bottle.getType().equals(Material.GLASS_BOTTLE))
            {
                double cost = config.getDouble("vampire.bottle.cost");
                double health = player.getHealth() - cost;
                if (health <= 0.0)
                {
                    locale.sendLocale(player, true, "bottle.not-enough-health", "{health}",
                            Integer.toString((int) cost));
                    return;
                }

                if (origin instanceof Vampire)
                {
                    if (bottle.getAmount() <= 1)
                    {
                        player.getInventory().setItemInMainHand(new VampireBloodBottle(player.getUniqueId())
                                .getItemStack());
                    }
                    else
                    {
                        player.getInventory().removeItem(new ItemStack(Material.GLASS_BOTTLE, 1));
                        player.getInventory().addItem(new VampireBloodBottle(player.getUniqueId()).getItemStack());
                    }

                    locale.sendLocale(player, true, "bottle.vampire-blood");
                }
                else
                {
                    if (bottle.getAmount() <= 1)
                    {
                        player.getInventory().setItemInMainHand(new HumanBloodBottle(player.getUniqueId())
                                .getItemStack());
                    }
                    else
                    {
                        player.getInventory().removeItem(new ItemStack(Material.GLASS_BOTTLE, 1));
                        player.getInventory().addItem(new HumanBloodBottle(player.getUniqueId())
                                .getItemStack());
                    }

                    locale.sendLocale(player, true, "bottle.human-blood");
                }

                player.playEffect(EntityEffect.HURT);
                player.setHealth(health);
            }
            else
            {
                locale.sendLocale(player, true, "bottle.need-bottle");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] strings)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Vampires can shriek
     */
    private class ShriekCommand extends PaperSubCommand
    {
        public ShriekCommand()
        {
            super("shriek", "heavenraces.vampire.shriek");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "vampire.bloodlust.not-vampire");
                return;
            }

            ShriekSpell spell = (ShriekSpell) Spell.getSpell("shriek");
            if (spell != null)
            {
                spell.cast(player);
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] strings)
        {
            return Collections.emptyList();
        }
    }

    private class ListCommand extends PaperSubCommand
    {
        public ListCommand()
        {
            super("list", "heavenraces.vampire.list");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            int pageNumber = 1;
            if (args.length > 1)
            {
                try
                {
                    pageNumber = Integer.parseInt(args[1]);
                }
                catch (NumberFormatException exception)
                {
                    //Do nothing
                }
            }

            final int finalPageNumber = pageNumber;
            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "invalid.not-vampire");
                return;
            }

            locale.sendLocale(player, true, "admin.request");
            races.getAllOrigins(Vampire.class, (vampireSet) ->
            {
                List<Vampire> vampires = new ArrayList<>(vampireSet);
                vampires.sort(Comparator.reverseOrder());
                List<List<Vampire>> pages = Lists.partition(vampires, 6);
                int pageMax = pages.size();
                int page = finalPageNumber;
                if (page < 1)
                {
                    page = 1;
                }
                if (page > pageMax)
                {
                    page = pageMax;
                }

                String leaderName = "&7N/A";
                Leader leader = leaders.getLeader(Race.VAMPIRE);
                if (leader != null)
                {
                    Vampire elder = races.getOrigin(leader.getLeaderId(), Vampire.class);
                    if (elder == null)
                    {
                        elder = races.loadOrigin(leader.getLeaderId(), Vampire.class);
                    }

                    if (elder != null)
                    {
                        leaderName = elder.getDisplayName();
                    }
                }

                if (leaderName == null)
                {
                    leaderName = "&7N/A";
                }

                List<String> lines = text.getText("list.txt");
                String menu = String.join("\n", lines);
                menu = menu.replace("{race}", "&c&lVampire&r");
                menu = menu.replace("{page}", Integer.toString(page));
                menu = menu.replace("{pageMax}", Integer.toString(pageMax));
                menu = menu.replace("{leaderTitle}", "&4&lElder&r");
                menu = menu.replace("{leader}", leaderName);

                List<Vampire> topVampires = pages.get(page - 1);
                List<String> infoList = new ArrayList<>();
                for (Vampire top : topVampires)
                {
                    String line = " &b#";
                    for (int place = 0; place < vampires.size(); place++)
                    {
                        Vampire runner = vampires.get(place);
                        if (runner.getPlayerId().equals(top.getPlayerId()))
                        {
                            line += place + 1;
                            break;
                        }
                    }

                    line += " &f" + top.getDisplayName() + " &c(&eLVL " + String.format("%.2f", top.getLevel()) + "&c)";
                    infoList.add(line);
                }

                if (infoList.size() < 6)
                {
                    for (int remaining = 6 - infoList.size(); remaining > 0; remaining--)
                    {
                        infoList.add("&f");
                    }
                }

                String info = String.join("\n", infoList);
                menu = menu.replace("{players}", info);
                locale.sendMessage(player, menu);
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    private class NightVisionCommand extends PaperSubCommand
    {
        public NightVisionCommand()
        {
            super("nightvision", "heavenraces.vampire.nightvision");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                return;
            }

            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "invalid.not-vampire");
                return;
            }

            if (vampire.isNightVision())
            {
                vampire.setNightVision(false);
                player.removePotionEffect(PotionEffectType.NIGHT_VISION);
                locale.sendLocale(player, "vampire.night-vision.disabled");
            }
            else
            {
                vampire.setNightVision(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 200, 0));
                locale.sendLocale(player, "vampire.night-vision.enabled");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return List.of();
        }
    }

    private class JumpBoostCommand extends PaperSubCommand
    {
        public JumpBoostCommand()
        {
            super("jumpboost", "heavenraces.vampire.jumpboost");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                return;
            }

            Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
            if (vampire == null)
            {
                locale.sendLocale(player, true, "invalid.not-vampire");
                return;
            }

            if (vampire.isJumpBoost())
            {
                vampire.setJumpBoost(false);
                player.removePotionEffect(PotionEffectType.JUMP_BOOST);
                locale.sendLocale(player, "vampire.jump-boost.disabled");
            }
            else
            {
                vampire.setJumpBoost(true);
                locale.sendLocale(player, "vampire.jump-boost.enabled");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return List.of();
        }
    }

    /*
     * Vampire help command
     */
    private class HelpCommand extends PaperSubCommand
    {
        public HelpCommand()
        {
            super("help", "heavenraces.vampire.help");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            List<String> lines1 = text.getText("vampire-help1.txt");
            List<String> lines2 = text.getText("vampire-help2.txt");
            String menu1 = String.join("\n", lines1);
            String menu2 = String.join("\n", lines2);
            if (args.length == 1)
            {
                locale.sendMessage(sender, menu1);
            }
            else
            {
                try
                {
                    int page = Integer.parseInt(args[1]);
                    if (page <= 1)
                    {
                        //Page 1
                        locale.sendMessage(sender, menu1);
                    }
                    else
                    {
                        //Page 2
                        locale.sendMessage(sender, menu2);
                    }
                }
                catch (NumberFormatException exception)
                {
                    locale.sendLocale(sender, true, "invalid.number", "{arg}", args[1]);
                }
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            suggestions.add("1");
            suggestions.add("2");
            return suggestions;
        }
    }
}
