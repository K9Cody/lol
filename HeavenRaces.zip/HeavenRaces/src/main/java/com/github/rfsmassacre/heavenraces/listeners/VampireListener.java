package com.github.rfsmassacre.heavenraces.listeners;

import com.destroystokyo.paper.event.player.PlayerLaunchProjectileEvent;
import com.github.rfsmassacre.heavenduels.HeavenDuelsAPI;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.altars.Altar;
import com.github.rfsmassacre.heavenraces.altars.DarkAltar;
import com.github.rfsmassacre.heavenraces.altars.LightAltar;
import com.github.rfsmassacre.heavenraces.events.*;
import com.github.rfsmassacre.heavenraces.events.VampireFoodEvent.VampireAction;
import com.github.rfsmassacre.heavenraces.items.potions.AnimalBloodBottle;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.tasks.LocationTask;
import com.github.rfsmassacre.heavenraces.utils.*;
import io.lumine.mythic.bukkit.MythicBukkit;
import io.lumine.mythic.core.mobs.ActiveMob;
import me.libraryaddict.disguise.DisguiseAPI;
import me.libraryaddict.disguise.disguisetypes.DisguiseType;
import me.libraryaddict.disguise.disguisetypes.MobDisguise;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.damage.DamageSource;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;
import org.bukkit.event.player.*;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import su.nightexpress.combatpets.PetAPI;

import java.util.*;

public class VampireListener implements Listener
{
    private static final NamespacedKey BL_KEY = new NamespacedKey("heavenraces", "bloodlust");

    private final HeavenRaces instance;
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;
    private final Map<UUID, Long> drainCooldown;

    public VampireListener()
    {
        this.instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
        this.drainCooldown = new HashMap<>();
    }

    /*
     * Vampires do not naturally lose food bars.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onVampireHunger(FoodLevelChangeEvent event)
    {
        HumanEntity entity = event.getEntity();
        if (!(entity instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (event.getFoodLevel() < player.getFoodLevel())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires do not naturally lose food bars.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onVampireHunger(EntityExhaustionEvent event)
    {
        HumanEntity entity = event.getEntity();
        if (!(entity instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire != null)
        {
            event.setCancelled(true);;
        }
    }

    /*
     * Vampires do not naturally regenerate health.
     */
    @EventHandler(ignoreCancelled = true)
    public void onVampireHeal(EntityRegainHealthEvent event)
    {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (!event.getRegainReason().equals(RegainReason.CUSTOM))
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires do not get certain damage types.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onVampireHurt(EntityDamageEvent event)
    {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        List<String> damages = config.getStringList("vampire.block-damage");
        if (damages.contains(event.getCause().toString()))
        {
            event.setCancelled(true);
            player.setMetadata("heavenraces", new FixedMetadataValue(HeavenRaces.getInstance(),
                    "vampire"));
            Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), () ->
                    player.removeMetadata("heavenraces", HeavenRaces.getInstance()), 1L);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onFoodHurt(EntityDamageEvent event)
    {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        Talent evilPresence = vampire.getTalent("EvilPresence");
        if (evilPresence == null)
        {
            return;
        }

        if (!HeavenDuelsAPI.isDueling(player.getUniqueId()) && event.isCancelled())
        {
            return;
        }

        final int food = player.getFoodLevel();
        if (food > 0)
        {
            double percent = evilPresence.getDouble("percent");
            int foodLoss = (int) (event.getFinalDamage() * percent);
            int foodDifference = food - foodLoss;
            int finalFood = Math.max(0, food - foodLoss);
            if (foodDifference < 0)
            {
                player.setFoodLevel(0);
                event.setDamage(event.getDamage() - food);
            }
            else
            {
                player.setFoodLevel(finalFood);
                event.setDamage(0);
            }
        }
    }

    /*
     * Vampires can infect humans but only with their fists.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onVampireInfect(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Player player) || !(event.getEntity() instanceof Player))
        {
            return;
        }

        if (player.hasMetadata("NPC"))
        {
            return;
        }

        if (!player.getInventory().getItemInMainHand().getType().equals(Material.AIR))
        {
            return;
        }

        Player target = CombatUtil.getOriginalSource(event.getEntity());
        if (target == null)
        {
            return;
        }
        if (target.hasMetadata("NPC"))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        Human human = races.getOrigin(target.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        if (!HeavenDuelsAPI.isDueling(player.getUniqueId(), target.getUniqueId()) && event.isCancelled())
        {
            return;
        }

        int amount = config.getInt("vampire.infection.bite.amount");
        int chance = config.getInt("vampire.infection.bite.chance");
        if (RandomUtil.check(chance) & !human.isInfected())
        {
            Human.Infection infection = new Human.Infection(Race.VAMPIRE, player.getUniqueId(), amount);
            human.setInfection(infection);
            locale.sendLocale(target, true, "vampire.infection.start.bite");
            double xp = config.getDouble("xp.vampire.player-infect");
            ExperienceGainEvent xpEvent = new ExperienceGainEvent(vampire, xp);
            Bukkit.getPluginManager().callEvent(xpEvent);
            if (!xpEvent.isCancelled())
            {
                int oldLevel = (int) vampire.getLevel();
                vampire.addLevel(xpEvent.getXp());
                int newLevel = (int) vampire.getLevel();
                if (newLevel > oldLevel)
                {
                    LevelUpEvent levelEvent = new LevelUpEvent(vampire, newLevel);
                    Bukkit.getPluginManager().callEvent(levelEvent);
                }
            }
        }
    }

    /*
     * Vampires can infect humans but only with their fists.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onFeralVampireInfect(EntityDamageByEntityEvent event)
    {
        ActiveMob activeMob = MythicBukkit.inst().getMobManager().getActiveMob(event.getDamager().getUniqueId())
                .orElse(null);
        if (activeMob == null || !activeMob.getFaction().equals("Werewolf"))
        {
            return;
        }

        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        if (player.hasMetadata("NPC"))
        {
            return;
        }

        Human human = races.getOrigin(player.getUniqueId(), Human.class);
        if (human == null)
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        int amount = config.getInt("vampire.infection.bite.amount");
        int chance = config.getInt("vampire.infection.bite.chance");
        if (RandomUtil.check(chance) & !human.isInfected())
        {
            StartInfectEvent infectionEvent = new StartInfectEvent(human, Race.VAMPIRE, amount);
            Bukkit.getPluginManager().callEvent(infectionEvent);
            if (infectionEvent.isCancelled())
            {
                return;
            }

            Human.Infection infection = new Human.Infection(Race.VAMPIRE, amount);
            human.setInfection(infection);
            locale.sendLocale(player, true, "vampire.infection.start.bite");
        }
    }

    /*
     * Vampires gain food bars from attacking enemies with blood.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onVampireFoodsteal(EntityDamageByEntityEvent event)
    {
        if (!(event.getEntity() instanceof LivingEntity entity))
        {
            return;
        }

        if (!(event.getDamager() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        List<String> mobNames = config.getStringList("vampire.food.blocked-mobs");
        if (mobNames.contains(entity.getType().toString()))
        {
            return;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().equals(Material.GLASS_BOTTLE))
        {
            return;
        }

        if (!HeavenDuelsAPI.isDueling(player.getUniqueId()) && event.isCancelled())
        {
            return;
        }

        double damage = event.getDamage();
        double foodRatio = this.config.getDouble("vampire.food.food-ratio");
        if (entity.getHealth() < event.getDamage())
        {
            damage = entity.getHealth();
        }

        double foodLevel = (double)player.getFoodLevel() + (damage * foodRatio);
        VampireFoodEvent foodEvent = new VampireFoodEvent(vampire, (damage * foodRatio), VampireAction.ATTACK);
        Bukkit.getPluginManager().callEvent(foodEvent);
        if (!foodEvent.isCancelled())
        {
            foodLevel = Math.min(player.getFoodLevel() + foodEvent.getFood(), FoodUtil.MAX_FOOD);
        }

        player.setFoodLevel((int) Math.round(foodLevel));
    }

    /*
     * Sanguine Vampires in blood-lust mode can life-steal.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onBloodLustLifeSteal(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Player player) || !(event.getEntity() instanceof LivingEntity))
        {
            return;
        }

        if (player.hasMetadata("NPC"))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (!event.getCause().equals(DamageCause.ENTITY_ATTACK))
        {
            return;
        }


        if (!HeavenDuelsAPI.isDueling(player.getUniqueId()) && event.isCancelled())
        {
            return;
        }

        double heal = config.getDouble("vampire.bloodlust.lifesteal");
        double maxHeal = config.getDouble("vampire.bloodlust.max-heal");
        double health = player.getHealth();
        AttributeInstance healthAttribute = player.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttribute == null)
        {
            return;
        }

        List<String> mobNames = config.getStringList("vampire.food.blocked-mobs");
        double maxHealth = healthAttribute.getValue();
        if (health < maxHealth)
        {
            double percent = config.getDouble("vampire.food.health-ratio");
            if (vampire.inBloodLust())
            {
                Talent insatiable = vampire.getTalent("Insatiable");
                if (insatiable != null)
                {
                    if (health / maxHealth <= insatiable.getDouble("threshold"))
                    {
                        percent *= insatiable.getDouble("percent");
                    }
                }

                Talent shadowsCall = vampire.getTalent("ShadowsCall");
                if (shadowsCall != null && mobNames.contains(event.getEntity().getType().toString()))
                {
                    percent *= shadowsCall.getDouble("percent");
                }
            }
            else
            {
                Talent composure = vampire.getTalent("Composure");
                if (composure != null)
                {
                    percent *= composure.getDouble("percent");
                }
            }

            double finalHeal = health + Math.min(maxHeal, (heal * percent));
            if (finalHeal > maxHealth)
            {
                finalHeal = maxHealth;
            }

            player.setHealth(finalHeal);
        }
    }

    /*
     * Vampire toggles reset on death.
     */
    @EventHandler
    public void onVampireDeath(PlayerDeathEvent event)
    {
        Player player = event.getEntity();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        vampire.setTemperature(0.0);
        vampire.setBloodLust(false);
        FXUtil.playEffect(player, Effect.GHAST_SHRIEK);
        FXUtil.smokeBurst(player, config.getInt("vampire.effects.smoke-burst"));
        FXUtil.flameBurst(player, config.getInt("vampire.effects.flame-burst"));
        LocationTask.LOCATIONS.remove(player.getUniqueId());
    }

    @EventHandler
    public void onVampireRespawn(PlayerRespawnEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            VampireBatEvent batEvent = new VampireBatEvent(vampire, false);
            Bukkit.getPluginManager().callEvent(batEvent);
        }
    }

    @EventHandler
    public void onVampireLogout(PlayerQuitEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        vampire.setBloodLust(false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onVampireAttack(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        AttributeInstance healthAttribute = player.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttribute == null)
        {
            return;
        }

        Talent insatiable = vampire.getTalent("Insatiable");
        if (insatiable == null)
        {
            return;
        }

        double maxHealth = healthAttribute.getValue();
        double threshold = insatiable.getDouble("threshold");
        double percent = insatiable.getDouble("percent");
        if (vampire.hasTalent(insatiable))
        {
            if (vampire.isBloodLust() && player.getHealth() / maxHealth > threshold)
            {
                event.setDamage(event.getDamage() * percent);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMobTargetVampire(EntityTargetEvent event)
    {
        if (!(event.getTarget() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        List<String> mobNames = config.getStringList("vampire.truce.mobs");
        String mobType = event.getEntityType().toString();
        if (mobNames.contains(mobType) && vampire.getTruceTicks() <= 0)
        {
            if (event.getEntity() instanceof Ghast)
            {
                event.setTarget(null);
            }

            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onVampireHitMob(EntityDamageByEntityEvent event)
    {
        Player player = CombatUtil.getOriginalSource(event.getDamager());
        if (player == null)
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        int truceBreak = config.getInt("vampire.truce.length");
        List<String> mobNames = config.getStringList("vampire.truce.mobs");
        String mobType = event.getEntityType().toString();
        if (mobNames.contains(mobType))
        {
            if (vampire.getTruceTicks() <= 0)
            {
                locale.sendLocale(player, true, "vampire.truce.broken");
            }

            vampire.setTruceTicks(truceBreak);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onBatAttack(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof Player player))
        {
            return;
        }

        if (event.getEntity().hasMetadata("NPC"))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBatDamaged(EntityDamageByEntityEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        if (event.getEntity().hasMetadata("NPC"))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null || !vampire.inBatForm())
        {
            return;
        }

        if (!HeavenDuelsAPI.isDueling(player.getUniqueId()) && event.isCancelled())
        {
            return;
        }

        DamageSource original = event.getDamageSource();
        if (original.getDamageType().equals(DamageType.GENERIC))
        {
            return;
        }

        player.damage(event.getDamage(), DamageSource.builder(DamageType.GENERIC)
                .withDamageLocation(original.getDamageLocation())
                .withDirectEntity(original.getDirectEntity())
                .withCausingEntity(original.getCausingEntity())
                .build());
    }

    /*
     * Vampires in bat form can't interact with stuff.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onBatInteract(PlayerInteractEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't interact with entities.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onBatInteractEntity(PlayerInteractEntityEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't launch projectiles.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onBatThrow(PlayerLaunchProjectileEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't shoot bows.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onBatThrow(EntityShootBowEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't consume items.
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onBatConsume(PlayerItemConsumeEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't shoot bows.
     */
    @EventHandler(ignoreCancelled = true)
    public void onBatShoot(EntityShootBowEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't break blocks.
     */
    @EventHandler(ignoreCancelled = true)
    public void onBatBreakBlock(BlockBreakEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't pick up items.
     */
    @EventHandler(ignoreCancelled = true)
    public void onBatItemPickUp(EntityPickupItemEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Vampires in bat form can't drop items.
     */
    @EventHandler(ignoreCancelled = true)
    public void onBatItemDrop(PlayerDropItemEvent event)
    {
        Player player = event.getPlayer();
        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null)
        {
            return;
        }

        if (vampire.inBatForm())
        {
            event.setCancelled(true);
        }
    }

    /*
     * Ensure everything goes consistently when vampires transform.
     */
    @EventHandler(ignoreCancelled = true)
    public void onVampireTransform(VampireBatEvent event)
    {
        Vampire vampire = event.getVampire();
        Player player = vampire.getPlayer();
        AttributeInstance healthAttribute = player.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttribute == null)
        {
            return;
        }

        if (event.isToggled())
        {
            if (vampire.isBloodLust())
            {
                VampireBloodLustEvent bloodLustEvent = new VampireBloodLustEvent(vampire, false);
                Bukkit.getPluginManager().callEvent(bloodLustEvent);
            }

            player.setAllowFlight(true);
            player.setFlying(true);
            vampire.setLastHealth(player.getHealth());
            vampire.setLastMaxHealth(healthAttribute.getValue());
            vampire.setBatForm(true);
            double flightSpeed = config.getDouble("vampire.bat-form.speed.fly");
            player.setFlySpeed((float) flightSpeed);
            vampire.updateStats();
            MobDisguise disguise = new MobDisguise(DisguiseType.BAT);
            disguise.getWatcher().setScale(1.0);
            DisguiseAPI.disguiseToAll(player, disguise);
            locale.sendLocale(player, true, "vampire.bat-form.enabled");
        }
        else
        {
            player.setAllowFlight(false);
            player.setFlying(false);
            player.setFlySpeed(0.2F);
            vampire.setBatForm(false);
            vampire.updateStats();
            player.setHealth(Math.min(vampire.getLastHealth(), vampire.getLastMaxHealth()));
            vampire.setLastHealth(0.0);
            vampire.setLastMaxHealth(0.0);
            DisguiseAPI.undisguiseToAll(player);
            locale.sendLocale(player, true, "vampire.bat-form.disabled");
        }

        Location last = LocationTask.LOCATIONS.get(player.getUniqueId());
        if (last != null && last.getWorld().equals(player.getWorld()))
        {
            player.setMetadata("teleport", new FixedMetadataValue(HeavenRaces.getInstance(),
                    "transform"));
            last.setYaw(player.getYaw());
            last.setPitch(player.getPitch());
            player.teleport(last, TeleportCause.PLUGIN);
            player.removeMetadata("teleport", HeavenRaces.getInstance());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBloodLustToggle(VampireBloodLustEvent event)
    {
        Vampire vampire = event.getVampire();
        Player player = vampire.getPlayer();
        if (event.isToggled())
        {
            if (vampire.isBatForm())
            {
                VampireBatEvent batEvent = new VampireBatEvent(vampire, false);
                Bukkit.getPluginManager().callEvent(batEvent);
            }

            FXUtil.playEffect(player, Effect.GHAST_SHRIEK);
            FXUtil.smokeBurst(player, config.getInt("vampire.bloodlust.particles"));
            vampire.setBloodLust(true);
            locale.sendLocale(player, true, "vampire.bloodlust.enabled");
        }
        else
        {
            FXUtil.playEffect(player, Effect.GHAST_SHRIEK);
            FXUtil.smokeBurst(player, config.getInt("vampire.bloodlust.particles"));
            vampire.setBloodLust(false);
            locale.sendLocale(player, true, "vampire.bloodlust.disabled");
        }

        vampire.updateStats();
    }

    /*
     * On bottling up animal blood.
     */
    @EventHandler(ignoreCancelled = true)
    public void onAnimalBloodBottle(PlayerInteractEntityEvent event)
    {
        Player killer = event.getPlayer();
        if (!event.getHand().equals(EquipmentSlot.HAND) || event.getRightClicked() instanceof Player)
        {
            return;
        }

        ItemStack bottle = killer.getInventory().getItemInMainHand();
        if (!bottle.getType().equals(Material.GLASS_BOTTLE))
        {
            return;
        }

        Vampire vampire = races.getOrigin(killer.getUniqueId(), Vampire.class);
        if (vampire != null && vampire.inBatForm())
        {
            return;
        }

        if (!(event.getRightClicked() instanceof LivingEntity mob))
        {
            return;
        }

        if (Bukkit.getPluginManager().isPluginEnabled("CombatPets") && PetAPI.getPetManager().isPetEntity(mob))
        {
            return;
        }

        List<String> mobNames = config.getStringList("vampire.bottle.allowed-mobs");
        if (!mobNames.contains(mob.getType().toString()))
        {
            locale.sendLocale(killer, true, "bottle.not-tasty");
            return;
        }

        AttributeInstance healthAttribute = mob.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttribute == null)
        {
            return;
        }

        double maxHealth = healthAttribute.getValue();
        double health = mob.getHealth();
        double percent = config.getDouble("vampire.bottle.animal-blood.percent");
        if (health / maxHealth < percent)
        {
            this.locale.sendLocale(killer, true, "bottle.need-health");
            return;
        }
        if (bottle.getAmount() <= 1)
        {
            killer.getInventory().setItemInMainHand(new AnimalBloodBottle(mob.getType(),
                    (int) maxHealth).getItemStack());
        }
        else
        {
            killer.getInventory().removeItem(new ItemStack(Material.GLASS_BOTTLE, 1));
            killer.getInventory().addItem(new AnimalBloodBottle(mob.getType(), (int) maxHealth).getItemStack());
        }

        locale.sendLocale(killer, true, "bottle.animal-blood");
        mob.setHealth(0.0);
    }

    @EventHandler
    public void onAnimalKill(EntityDeathEvent event)
    {
        LivingEntity entity = event.getEntity();
        Player killer = entity.getKiller();
        if (killer == null)
        {
            return;
        }

        ItemStack item = killer.getInventory().getItemInMainHand();
        if (item.getType().equals(Material.GLASS_BOTTLE) || new AnimalBloodBottle().equals(item))
        {
            event.setDroppedExp(0);
            event.getDrops().clear();
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onLifeDrain(PlayerInteractEntityEvent event)
    {
        if (!event.getHand().equals(EquipmentSlot.HAND))
        {
            return;
        }

        Player player = event.getPlayer();
        if (player.getFoodLevel() == FoodUtil.MAX_FOOD)
        {
            return;
        }

        Vampire vampire = races.getOrigin(player.getUniqueId(), Vampire.class);
        if (vampire == null || !player.isSneaking())
        {
            return;
        }

        if (!(event.getRightClicked() instanceof LivingEntity entity))
        {
            return;
        }

        List<String> mobNames = config.getStringList("vampire.right-click.allowed-mobs");
        if (!mobNames.contains(entity.getType().toString()) || !entity.isValid())
        {
            return;
        }

        EntityDamageByEntityEvent damageEvent = new EntityDamageByEntityEvent(player, entity, DamageCause.ENTITY_ATTACK,
                DamageSource.builder(DamageType.GENERIC).build(), 1.0);
        Bukkit.getPluginManager().callEvent(damageEvent);
        if (damageEvent.isCancelled())
        {
            return;
        }

        if (Bukkit.getPluginManager().isPluginEnabled("CombatPets") && PetAPI.getPetManager().isPetEntity(entity))
        {
            return;
        }

        long cooldown = config.getLong("vampire.right-click.cooldown");
        long lastDrain = drainCooldown.getOrDefault(player.getUniqueId(), 0L);
        if (System.currentTimeMillis() - lastDrain <= cooldown)
        {
            return;
        }

        player.setFoodLevel(Math.min(player.getFoodLevel() + 1, FoodUtil.MAX_FOOD));
        double xp = config.getDouble("xp.vampire.right-click");
        ExperienceGainEvent xpEvent = new ExperienceGainEvent(vampire, xp);
        Bukkit.getPluginManager().callEvent(xpEvent);
        if (!xpEvent.isCancelled())
        {
            int oldLevel = (int) vampire.getLevel();
            vampire.addLevel(xpEvent.getXp());
            int newLevel = (int) vampire.getLevel();
            if (newLevel > oldLevel)
            {
                LevelUpEvent levelEvent = new LevelUpEvent(vampire, newLevel);
                Bukkit.getPluginManager().callEvent(levelEvent);
            }
        }

        drainCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        event.setCancelled(true);
        if (entity.getHealth() <= 1.0)
        {
            if (entity.getType().equals(EntityType.VILLAGER))
            {
                Location location = entity.getLocation();
                entity.remove();
                player.getWorld().spawnEntity(location, EntityType.WITCH);
                player.getWorld().playSound(location, Sound.ENTITY_ZOMBIE_INFECT, 1.0F, 1.0F);
                entity.getWorld().spawnParticle(Particle.WITCH, entity.getEyeLocation(), 1);
                double villagerXP = config.getDouble("xp.vampire.villager-transform");
                ExperienceGainEvent villagerXPEvent = new ExperienceGainEvent(vampire, villagerXP);
                Bukkit.getPluginManager().callEvent(xpEvent);
                if (!villagerXPEvent.isCancelled())
                {
                    int oldLevel = (int) vampire.getLevel();
                    vampire.addLevel(villagerXPEvent.getXp());
                    int newLevel = (int) vampire.getLevel();
                    if (newLevel > oldLevel)
                    {
                        LevelUpEvent levelEvent = new LevelUpEvent(vampire, newLevel);
                        Bukkit.getPluginManager().callEvent(levelEvent);
                    }
                }
            }
            else
            {
                entity.setHealth(0.0);
                entity.getWorld().spawnParticle(Particle.FALLING_DUST, entity.getLocation(), 1,
                        Material.NETHER_WART.createBlockData());
            }
        }
        else if (entity.getHealth() > 0.0)
        {
            entity.setHealth(Math.max(0.0, entity.getHealth() - 1.0));
            entity.getWorld().spawnParticle(Particle.FALLING_DUST, entity.getEyeLocation(), 1,
                    Material.NETHER_WART.createBlockData());
        }
    }

    /*
     * When using an altar
     */
    @EventHandler(ignoreCancelled=true)
    public void onAltarTouch(PlayerInteractEvent event)
    {
        if (event.getHand() == null || !event.getHand().equals(EquipmentSlot.HAND) || !event.hasBlock())
        {
            return;
        }

        Player player = event.getPlayer();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        Block block = event.getClickedBlock();
        int radius = this.config.getInt("altars.check-radius");
        ArrayList<Block> blocks = Altar.getCubedBlocks(block, radius);
        LightAltar lightAltar = new LightAltar(instance);
        DarkAltar darkAltar = new DarkAltar(instance);
        if (block == null)
        {
            return;
        }

        if (block.getType().equals(lightAltar.getCore()))
        {
            processAltar(lightAltar, origin, "light", blocks);
        }
        else if (block.getType().equals(darkAltar.getCore()))
        {
            processAltar(darkAltar, origin, "dark", blocks);
        }
    }

    private void processAltar(Altar altar, Origin origin, String type, ArrayList<Block> blocks)
    {
        HashMap<Material, Integer> materials = Altar.getMaterialCount(blocks,
                ConfigUtil.getMaterialSet(config, "altars." + type + ".materials"));
        HashMap<Material, Integer> missing = altar.getMissingMaterialsCount(materials);
        for (int amount : missing.values())
        {
            if (amount <= 0)
            {
                continue;
            }

            this.locale.sendLocale(origin.getPlayer(), true, "altars.missing-materials",
                    "{list}", Altar.convertToString(missing));
            return;
        }

        altar.use(origin);
    }
}
