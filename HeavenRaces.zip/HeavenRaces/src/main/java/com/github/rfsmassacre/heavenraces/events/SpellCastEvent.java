package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.spells.Spell;
import org.bukkit.entity.LivingEntity;

public class SpellCastEvent extends SpellEvent
{
    public SpellCastEvent(LivingEntity caster, Spell spell)
    {
        super(caster, spell);
    }
}
