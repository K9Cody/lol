package com.github.rfsmassacre.heavenraces.items.armor;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import lombok.Getter;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ArmorMeta;

import java.util.ArrayList;
import java.util.List;

@Getter
public class WashedArmor extends RaceItem
{
    public static WashedArmor of(ItemStack item)
    {
        if (!(item.getItemMeta() instanceof ArmorMeta meta))
        {
            return null;
        }

        WashedArmor washedArmor = new WashedArmor(item.getType(), meta);
        if (washedArmor.equals(item))
        {
            return washedArmor;
        }

        return null;
    }

    private final ArmorMeta armorMeta;

    public WashedArmor(Material material, ArmorMeta armorMeta)
    {
        super("Washed" + LocaleData.capitalize(material.toString()).replaceAll(" ", ""),
                material);

        this.armorMeta = armorMeta;
    }

    public WashedArmor(Material material)
    {
        this(material, null);
    }

    @Override
    public ItemStack getItemStack()
    {
        if (armorMeta == null)
        {
            return item;
        }

        if (item.getItemMeta() instanceof ArmorMeta meta)
        {
            armorMeta.setCustomModelData(meta.getCustomModelData());
            armorMeta.displayName(meta.displayName());
            List<Component> newLore = meta.lore();
            if (newLore != null)
            {
                List<Component> oldLore = armorMeta.lore();
                if (oldLore == null)
                {
                    oldLore = new ArrayList<>();
                }

                newLore.addAll(oldLore);
            }

            armorMeta.lore(newLore);
            item.setItemMeta(armorMeta);
            this.setNBT(key, name);
        }

        return item;
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapedRecipe recipe = new ShapedRecipe(key, item);
        recipe.shape("QBQ", "BOB", "QWQ");
        recipe.setIngredient('Q', Material.QUARTZ);
        recipe.setIngredient('B', Material.BLAZE_POWDER);
        recipe.setIngredient('O', getType());
        recipe.setIngredient('W', Material.WATER_BUCKET);
        return recipe;
    }
}
