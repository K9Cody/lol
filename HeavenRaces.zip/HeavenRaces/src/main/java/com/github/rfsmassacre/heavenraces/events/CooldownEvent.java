package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.spells.Spell;
import org.bukkit.entity.LivingEntity;

public class CooldownEvent extends SpellEvent
{
    public CooldownEvent(LivingEntity caster, Spell spell)
    {
        super(caster, spell);
    }
}
