package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenraces.events.SpellTargetEvent;
import com.github.rfsmassacre.heavenraces.events.VampireShriekEvent;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.utils.FXUtil;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ShriekSpell extends Spell
{
    private final double range;
    private final int fatigueLength, blindnessLength;

    public ShriekSpell()
    {
        super("shriek");

        this.range = config.getDouble(internalName + ".range");
        this.fatigueLength = config.getInt(internalName + ".fatigue-length");
        this.blindnessLength = config.getInt(internalName + ".blindness-length");
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        Vampire vampire = getOrigin(entity);
        Player player = vampire.getPlayer();
        VampireShriekEvent event = new VampireShriekEvent(vampire);
        Bukkit.getPluginManager().callEvent(event);
        if (!event.isCancelled())
        {
            FXUtil.playEffect(player, Effect.GHAST_SHRIEK);
            FXUtil.smokeBurst(player, config.getInt("vampire.effects.smoke-burst"));
            locale.sendLocale(player, true, "vampire.shriek.activate");
            for (Entity nearby : player.getNearbyEntities(range, range, range))
            {
                if (nearby instanceof LivingEntity target)
                {
                    SpellTargetEvent targetEvent = new SpellTargetEvent(entity, this, target);
                    Bukkit.getPluginManager().callEvent(targetEvent);
                    if (!targetEvent.isCancelled())
                    {
                        target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, blindnessLength,
                                0));
                        target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, fatigueLength,
                                0));
                    }
                }
            }
        }

        return true;
    }
}
