package com.github.rfsmassacre.heavenraces.items.potions;

import lombok.Getter;
import org.bukkit.Color;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

@Getter
public class VampireBloodBottle extends PotionItem
{
    private static final NamespacedKey KEY = new NamespacedKey("heavenraces", "vampire");
    private UUID vampireId;

    public VampireBloodBottle()
    {
        this((UUID) null);
    }

    public VampireBloodBottle(UUID vampireId)
    {
        super("VampireBloodBottle", Color.BLACK);

        this.vampireId = vampireId;
        if (vampireId != null)
        {
            setNBT(KEY, vampireId.toString());
        }
    }

    public VampireBloodBottle(ItemStack bottle)
    {
        this((UUID) null);

        String stringId = bottle.getPersistentDataContainer().get(KEY, PersistentDataType.STRING);
        if (stringId != null)
        {
            this.vampireId = UUID.fromString(stringId);
        }
    }

    @Override
    protected Recipe createRecipe()
    {
        return null;
    }
}
