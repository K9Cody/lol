package com.github.rfsmassacre.heavenraces.managers;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Spirit;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import net.skinsrestorer.api.SkinsRestorer;
import net.skinsrestorer.api.SkinsRestorerProvider;
import net.skinsrestorer.api.property.SkinProperty;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;

public class SkinManager
{
    private final SkinsRestorer api;

    private final PaperConfiguration config;
    private final PaperLocale locale;

    private final HashMap<String, SkinProperty> skins;

    public SkinManager()
    {
        this.api = SkinsRestorerProvider.get();
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.locale = HeavenRaces.getInstance().getLocale();
        this.skins = new HashMap<>();
        if (api != null)
        {
            textureSkins();
        }
    }

    public void applySkin(Player player, String skinName)
    {
        applySkin(player, skinName, () -> {});
    }

    public void applySkin(Player player, String skinName, Runnable runnable)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
        {
            try
            {
                if (skinName != null && skins.containsKey(skinName))
                {
                    SkinProperty skin = skins.get(skinName);
                    api.getSkinApplier(Player.class).applySkin(player, skin);
                    runnable.run();
                }
            }
            catch (Exception exception)
            {
                locale.sendLocale(Bukkit.getConsoleSender(), true, "skin.cannot-apply",
                        "{player}", player.getDisplayName());

                exception.printStackTrace();
            }
        });
    }

    public void removeSkin(Player player)
    {
        removeSkin(player, () -> {});
    }

    public void removeSkin(Player player, Runnable runnable)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
        {
            try
            {
                api.getSkinApplier(Player.class).applySkin(player);
                runnable.run();
            }
            catch (Exception exception)
            {
                locale.sendLocale(Bukkit.getConsoleSender(), true, "skin.cannot-clear",
                        "{player}", player.getDisplayName());

                exception.printStackTrace();
            }
        });
    }

    public String getSkin(Werewolf werewolf)
    {
        LeaderManager leaders = HeavenRaces.getInstance().getLeaderManager();
        Clan clan = werewolf.getClan();
        String skin = clan.toString().toLowerCase();
        Leader alpha = leaders.getLeader(clan);
        if (alpha != null && alpha.getLeaderId().equals(werewolf.getPlayerId()))
        {
            skin = skin + "_alpha";
        }

        return skin;
    }

    public String getSkin(Spirit spirit)
    {
        return spirit.getRank().toString().toLowerCase() + "_" + spirit.getRace().toString().toLowerCase();
    }

    private void textureSkins()
    {
        locale.sendLocale(Bukkit.getConsoleSender(), "skin.loading");

        skins.clear();
        skins.put("witherfang_alpha", getTexture(Clan.WITHERFANG, true));
        skins.put("silvermane_alpha", getTexture(Clan.SILVERMANE, true));
        skins.put("bloodmoon_alpha", getTexture(Clan.BLOODMOON, true));
        skins.put("witherfang", getTexture(Clan.WITHERFANG, false));
        skins.put("silvermane", getTexture(Clan.SILVERMANE, false));
        skins.put("bloodmoon", getTexture(Clan.BLOODMOON, false));

        skins.put("seraph_angel", getTexture(Race.ANGEL, Spirit.Rank.SERAPH));
        skins.put("cherub_angel", getTexture(Race.ANGEL, Spirit.Rank.CHERUB));
        skins.put("virtue_angel", getTexture(Race.ANGEL, Spirit.Rank.VIRTUE));
        skins.put("dominion_angel", getTexture(Race.ANGEL, Spirit.Rank.DOMINION));
        skins.put("power_angel", getTexture(Race.ANGEL, Spirit.Rank.POWER));

        skins.put("seraph_demon", getTexture(Race.DEMON, Spirit.Rank.SERAPH));
        skins.put("cherub_demon", getTexture(Race.DEMON, Spirit.Rank.CHERUB));
        skins.put("virtue_demon", getTexture(Race.DEMON, Spirit.Rank.VIRTUE));
        skins.put("dominion_demon", getTexture(Race.DEMON, Spirit.Rank.DOMINION));
        skins.put("power_demon", getTexture(Race.DEMON, Spirit.Rank.POWER));

        locale.sendLocale(Bukkit.getConsoleSender(), "skin.loaded");
    }

    private SkinProperty getTexture(Clan clan, boolean alpha)
    {
        String type = clan.toString().toLowerCase();
        String status = alpha ? "alpha" : "werewolf";
        String value = config.getString("skin." + type + "." + status + ".value");
        String signature = config.getString("skin." + type + "." + status + ".signature");
        return SkinProperty.of(value, signature);
    }

    private SkinProperty getTexture(Race race, Spirit.Rank rank)
    {
        String type = race.toString().toLowerCase();
        String status = rank.toString().toLowerCase();
        String value = config.getString("skin." + type + "." + status + ".value");
        String signature = config.getString("skin." + type + "." + status + ".signature");
        return SkinProperty.of(value, signature);
    }
}
