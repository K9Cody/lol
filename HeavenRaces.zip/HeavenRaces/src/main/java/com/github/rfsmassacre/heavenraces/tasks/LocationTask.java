package com.github.rfsmassacre.heavenraces.tasks;

import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Getter
public class LocationTask extends BukkitRunnable
{
    public static final Map<UUID, Location> LOCATIONS = new HashMap<>();

    @Override
    public void run()
    {
        for (Player player : Bukkit.getOnlinePlayers())
        {
            Location location = player.getLocation();
            Location last = LOCATIONS.get(player.getUniqueId());
            if (last == null || (!last.getBlock().equals(location.getBlock()) && (location.getBlock().isEmpty() ||
                    location.getBlock().isPassable())) || !hasBlockAboveAndNextTo(player))
            {
                LOCATIONS.put(player.getUniqueId(), location);
            }
        }
    }

    private boolean hasBlockAboveAndNextTo(Player player)
    {
        Location location = player.getLocation();
        Block blockAbove = location.getBlock().getRelative(0, 1, 0);
        if (blockAbove.getType().equals(Material.AIR))
        {
            return checkAdjacentBlocks(location);
        }

        return false;
    }

    private boolean checkAdjacentBlocks(Location location)
    {
        Block[] adjacentBlocks =
        {
            location.getBlock().getRelative(1, 0, 0),
            location.getBlock().getRelative(-1, 0, 0),
            location.getBlock().getRelative(0, 0, 1),
            location.getBlock().getRelative(0, 0, -1)
        };

        for (Block block : adjacentBlocks)
        {
            if (block.getType().equals(Material.AIR))
            {
                return true;
            }
        }

        return false;
    }
}