package com.github.rfsmassacre.heavenraces.tasks;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import org.bukkit.scheduler.BukkitRunnable;

public class NegateTickTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public NegateTickTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
    }

    @Override
    public void run()
    {
        int interval = config.getInt("human.item.interval");
        for (Vampire vampire : races.getOrigins(Vampire.class))
        {
            int negatedTicks = vampire.getNegatedTicks();
            if (negatedTicks > 0)
            {
                vampire.setNegatedTicks(negatedTicks - interval);
            }
            else if (negatedTicks < 0)
            {
                vampire.setNegatedTicks(0);
            }
        }
        for (Werewolf werewolf : races.getOrigins(Werewolf.class))
        {
            int negatedTicks = werewolf.getNegatedTicks();
            if (negatedTicks > 0)
            {
                werewolf.setNegatedTicks(negatedTicks - interval);
            }
            else if (negatedTicks < 0)
            {
                werewolf.setNegatedTicks(0);
            }
        }
    }
}
