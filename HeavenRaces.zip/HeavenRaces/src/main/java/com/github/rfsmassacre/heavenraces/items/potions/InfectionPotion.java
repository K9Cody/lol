package com.github.rfsmassacre.heavenraces.items.potions;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapelessRecipe;

public class InfectionPotion extends PotionItem
{
    public InfectionPotion()
    {
        super("InfectionPotion", Color.ORANGE);
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapelessRecipe recipe = new ShapelessRecipe(key, item);
        recipe.addIngredient(Material.GLASS_BOTTLE);
        recipe.addIngredient(Material.GHAST_TEAR);
        recipe.addIngredient(Material.BLAZE_POWDER);
        recipe.addIngredient(Material.LEATHER);
        recipe.addIngredient(Material.SLIME_BALL);
        return recipe;
    }
}
