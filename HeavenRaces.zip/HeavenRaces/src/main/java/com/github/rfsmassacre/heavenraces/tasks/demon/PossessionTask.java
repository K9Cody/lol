package com.github.rfsmassacre.heavenraces.tasks.demon;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.PhaseFormEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Spirit;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PossessionTask extends BukkitRunnable
{
    private record Counter(UUID targetId, int counter, long timeStamp)
    {

    }

    private final static String ENTERING_KEY = "demon.entering.";
    private final static String POSSESSION_KEY = "demon.possession.";
    private final PaperConfiguration config;
    private final RaceManager races;
    private final int maxCounter;
    private final Map<UUID, Counter> counters;

    public PossessionTask()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.maxCounter = config.getInt("demon.phase-form.counter");
        this.counters = new HashMap<>();
    }

    /**
     * Runs this operation.
     */
    @Override
    public void run()
    {
        for (Demon demon : races.getOrigins(Demon.class))
        {
            Player player = demon.getPlayer();
            if (player == null || !demon.isPhaseForm())
            {
                BossBarUtil.removeBossBar(ENTERING_KEY + "self", demon.getPlayerId());
                BossBarUtil.removeBossBar(POSSESSION_KEY + "self", demon.getPlayerId());
                continue;
            }

            if (player.getGameMode().equals(GameMode.SPECTATOR) && player.getSpectatorTarget() != null)
            {
                if (player.getSpectatorTarget() instanceof LivingEntity victim && !victim.equals(player))
                {
                    if (!victim.hasPotionEffect(PotionEffectType.WITHER))
                    {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, PotionEffect.INFINITE_DURATION,
                                0));
                    }

                    double stamina = config.getDouble("demon.spirit-form.stamina.possession");
                    demon.addStamina(-stamina);
                    if (demon.getStamina() <= 0)
                    {
                        PhaseFormEvent event = new PhaseFormEvent(demon, false);
                        Bukkit.getPluginManager().callEvent(event);
                        if (!event.isCancelled())
                        {
                            BossBarUtil.removeBossBar(ENTERING_KEY + "self", demon.getPlayerId());
                            BossBarUtil.removeBossBar(POSSESSION_KEY + "self", demon.getPlayerId());
                            BossBarUtil.removeBossBar(ENTERING_KEY + "target", victim.getUniqueId());
                            BossBarUtil.removeBossBar(POSSESSION_KEY + "target", victim.getUniqueId());
                        }
                    }
                }

                continue;
            }

            BoundingBox hitBox = demon.getPlayer().getBoundingBox().expand(2.0, 2.0, 2.0);
            for (Entity entity : demon.getPlayer().getWorld().getNearbyEntities(hitBox))
            {
                if (!(entity instanceof LivingEntity victim))
                {
                    continue;
                }

                boolean isPlayer = false;
                if (victim instanceof Player victimPlayer)
                {
                    Origin victimOrigin = races.getOrigin(victimPlayer.getUniqueId(), Origin.class);
                    if (victimOrigin == null || victimOrigin instanceof Spirit || victimOrigin.getCorruption() < 100)
                    {
                        continue;
                    }

                    isPlayer = true;
                }

                if (demon.getPossessedId() == null)
                {
                    Counter counter = counters.getOrDefault(player.getUniqueId(), new Counter(victim.getUniqueId(),
                            0, System.currentTimeMillis()));
                    if (!counter.targetId.equals(victim.getUniqueId()))
                    {
                        BossBarUtil.removeBossBar(ENTERING_KEY + "self", demon.getPlayerId());
                        BossBarUtil.removeBossBar(ENTERING_KEY + "target", player.getUniqueId());
                        counters.remove(player.getUniqueId());
                    }
                    else
                    {
                        counter = new Counter(victim.getUniqueId(), counter.counter + 1,
                                System.currentTimeMillis());
                        if (isPlayer)
                        {
                            Player victimPlayer = (Player) victim;
                            BossBarUtil.updateBossBar(demon.getPlayer(), (double) counter.counter /
                                    maxCounter, ENTERING_KEY + "self", "{player}",
                                    victimPlayer.getDisplayName());
                            BossBarUtil.updateBossBar(victimPlayer, (double) counter.counter /
                                    maxCounter, ENTERING_KEY + "target", "{player}",
                                    demon.getDisplayName());
                        }
                        else
                        {
                            BossBarUtil.updateBossBar(demon.getPlayer(), (double) counter.counter /
                                    maxCounter, ENTERING_KEY + "self", "{player}", victim.getName());
                        }

                        counters.put(player.getUniqueId(), counter);
                    }

                    if (counter.counter >= maxCounter)
                    {
                        BossBarUtil.removeBossBar(ENTERING_KEY + "self", player.getUniqueId());
                        BossBarUtil.removeBossBar(ENTERING_KEY + "target", victim.getUniqueId());
                        player.setGameMode(GameMode.SPECTATOR);
                        player.setSpectatorTarget(victim);
                        demon.setPossessedId(victim.getUniqueId());
                        victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, PotionEffect.INFINITE_DURATION,
                                0));
                        counters.remove(player.getUniqueId());
                    }

                    break;
                }
            }

            Counter counter = counters.get(player.getUniqueId());
            if (counter != null && System.currentTimeMillis() - counter.timeStamp > 250L)
            {
                BossBarUtil.removeBossBar(ENTERING_KEY + "self", demon.getPlayerId());
                BossBarUtil.removeBossBar(ENTERING_KEY + "target", counter.targetId);
                counters.remove(player.getUniqueId());
                continue;
            }

            if (player.getSpectatorTarget() instanceof Player victimPlayer)
            {
                BossBarUtil.removeBossBar(ENTERING_KEY + "self", player.getUniqueId());
                BossBarUtil.updateBossBar(demon.getPlayer(), 1.0, POSSESSION_KEY + "self",
                        "{player}", victimPlayer.getDisplayName());
                BossBarUtil.updateBossBar(victimPlayer, 1.0, POSSESSION_KEY + "target",
                        "{player}", demon.getDisplayName());
            }
            else if (player.getSpectatorTarget() != null)
            {
                BossBarUtil.removeBossBar(ENTERING_KEY + "self", player.getUniqueId());
                BossBarUtil.updateBossBar(demon.getPlayer(), 1.0, POSSESSION_KEY + "self",
                        "{player}", player.getSpectatorTarget().getName());
            }
        }
    }
}
