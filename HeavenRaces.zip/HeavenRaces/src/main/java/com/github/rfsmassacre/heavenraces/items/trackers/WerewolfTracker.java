package com.github.rfsmassacre.heavenraces.items.trackers;

import org.bukkit.Material;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;

public class WerewolfTracker extends TrackerItem
{
    public WerewolfTracker()
    {
        super("WerewolfTracker", Race.WEREWOLF);
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapedRecipe recipe = new ShapedRecipe(key, item);
        recipe.shape("RRR", "RCR", "RRR");
        recipe.setIngredient('R', Material.RABBIT_FOOT);
        recipe.setIngredient('C', Material.COMPASS);
        return recipe;
    }
}
