package com.github.rfsmassacre.heavenraces.data;

import com.github.rfsmassacre.heavenlibrary.paper.managers.PaperGsonManager;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.*;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.function.Consumer;


public class OriginGsonManager extends PaperGsonManager<Origin>
{
    public OriginGsonManager()
    {
        super(HeavenRaces.getInstance(), "players", Origin.class);

        registerTypes(Human.class, Vampire.class, Werewolf.class, Angel.class, Demon.class);
    }

    /**
     * Seek a Origin by username into a callback.
     *
     * @param username Name of player.
     * @param callback Consumer of T (Callback)
     */
    //Since T extends Origin, looking for a generic Origin should work for retrieving UUIDs.
    public void readNameAsync(String username, Consumer<Origin> callback)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
        {
            Origin player = null;
            for (Origin origin : all())
            {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(origin.getPlayerId());
                if (offlinePlayer.hasPlayedBefore() && username.equals(offlinePlayer.getName()))
                {
                    player = origin;
                    break;
                }
            }
            callback.accept(player);
        });
    }
}
