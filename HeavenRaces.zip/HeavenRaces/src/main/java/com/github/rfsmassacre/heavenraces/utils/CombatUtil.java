package com.github.rfsmassacre.heavenraces.utils;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.RaceFlag;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.metadata.MetadataValue;

public class CombatUtil
{
    public static Player getOriginalSource(Entity entity)
    {
        switch (entity)
        {
            case null ->
            {
                return null;
            }
            case Player player ->
            {
                if (player.hasMetadata("NPC"))
                {
                    return null;
                }
                else
                {
                    return player;
                }
            }
            case Projectile projectile ->
            {
                if (projectile.getShooter() instanceof Player)
                {
                    return (Player) projectile.getShooter();
                }
            }
            default ->
            {
                if (entity.hasMetadata("Player"))
                {
                    MetadataValue value = entity.getMetadata("Player").get(0);
                    for (Player player : Bukkit.getOnlinePlayers())
                    {
                        if (value.asString().contains(player.getName()))
                        {
                            return player;
                        }
                    }
                }
            }
        }

        return null;
    }

    public static boolean isSpawnProtected(Origin origin)
    {
        if (origin == null)
        {
            return false;
        }

        Player player = origin.getPlayer();
        if (player == null)
        {
            return false;
        }

        return isRaceSpawn(origin.getRace(), player.getLocation());
    }

    public static boolean isRaceSpawn(Origin.Race race, Location position)
    {
        if (position == null)
        {
            return false;
        }

        if (HeavenRaces.getInstance().getServer().getPluginManager().isPluginEnabled("WorldGuard"))
        {
            com.sk89q.worldedit.util.Location location = BukkitAdapter.adapt(position);
            RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
            RegionQuery query = container.createQuery();
            ApplicableRegionSet set = query.getApplicableRegions(location);
            RaceFlag flag = RaceFlag.getFlag(race);
            return set.testState(null, flag);
        }

        return false;
    }

    public static boolean isRaceSpawn(Location position)
    {
        for (Origin.Race race : Origin.Race.values())
        {
            if (isRaceSpawn(race, position))
            {
                return true;
            }
        }

        return false;
    }
}
