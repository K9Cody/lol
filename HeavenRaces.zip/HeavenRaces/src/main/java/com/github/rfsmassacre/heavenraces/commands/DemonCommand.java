package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.SpiritFormEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public class DemonCommand extends PaperCommand
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public DemonCommand()
    {
        super(HeavenRaces.getInstance(), "demon");

        HeavenRaces instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();

        addSubCommand(new InfoCommand());
        addSubCommand(new SpiritFormCommand("t"));
        addSubCommand(new SpiritFormCommand("transform"));
    }

    /*
     * Werewolf main command
     */
    private class InfoCommand extends PaperSubCommand
    {
        public InfoCommand()
        {
            super("info", "heavenraces.demon.info");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Demon demon = races.getOrigin(player.getUniqueId(), Demon.class);
            if (demon == null)
            {
                locale.sendLocale(player, true, "invalid.not-angel");
                return;
            }

            locale.sendMessage(player, RaceCommand.getMenu(demon));
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Spirit Form
     */
    private class SpiritFormCommand extends PaperSubCommand
    {
        public SpiritFormCommand(String name)
        {
            super(name, "heavenraces.demon.transform");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Demon demon = races.getOrigin(player.getUniqueId(), Demon.class);
            if (demon == null)
            {
                locale.sendLocale(player, true, "angel.spirit-form.not-demon");
                return;
            }

            if (demon.isSpiritForm())
            {
                SpiritFormEvent event = new SpiritFormEvent(demon, false);
                Bukkit.getPluginManager().callEvent(event);
                if (event.isCancelled())
                {
                    locale.sendLocale(player, true, "demon.spirit-form.cant-toggle");
                }
            }
            else
            {
                int level = config.getInt("level-reward.demon.spirit-form");
                if (demon.getLevel() < level)
                {
                    locale.sendLocale(player, true, "level-reward.not-level", "{level}",
                            Integer.toString(level), "{ability}", "Spirit Form");
                    return;
                }

                SpiritFormEvent event = new SpiritFormEvent(demon, true);
                Bukkit.getPluginManager().callEvent(event);
                if (event.isCancelled())
                {
                    locale.sendLocale(player, true, "demon.spirit-form.cant-toggle");
                }
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }
}
