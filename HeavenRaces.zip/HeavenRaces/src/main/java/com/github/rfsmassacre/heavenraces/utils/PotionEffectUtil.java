package com.github.rfsmassacre.heavenraces.utils;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Set;

public class PotionEffectUtil
{
    public static void addPotionEffect(Player player, PotionEffect effect)
    {
        PotionEffect first = player.getPotionEffect(effect.getType());
        if (first == null || first.getAmplifier() <= effect.getAmplifier())
        {
            player.addPotionEffect(effect);
        }
    }

    public static void addPotionEffects(Player player, Set<PotionEffect> effects)
    {
        for (PotionEffect effect : effects)
        {
            addPotionEffect(player, effect);
        }
    }

    public static void removePotionEffect(Player player, PotionEffect effect)
    {
        player.removePotionEffect(effect.getType());
    }

    public static void removePotionEffects(Player player, Set<PotionEffect> effects)
    {
        for (PotionEffect effect : effects)
        {
            removePotionEffect(player, effect);
        }
    }
}
