package com.github.rfsmassacre.heavenraces.utils;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BossBarUtil
{
    private static final Map<String, Map<UUID, BossBar>> BOSS_BARS = new HashMap<>();

    private static BossBar createBossBar(String section, String... holders)
    {
        PaperConfiguration config = HeavenRaces.getInstance().getConfiguration();
        String title = LocaleData.format(LocaleData.replaceHolders(config.getString("boss-bar." + section +
                ".title"), holders));
        String color = config.getString("boss-bar." + section + ".color");
        String style = config.getString("boss-bar." + section + ".style");

        try
        {
            BarColor barColor = BarColor.valueOf(color);
            BarStyle barStyle = BarStyle.valueOf(style);
            return Bukkit.createBossBar(title, barColor, barStyle);
        }
        catch (IllegalArgumentException exception)
        {
            return null;
        }
    }

    public static void updateBossBar(Player player, double progress, String key, String... holders)
    {
        Map<UUID, BossBar> bossBars = BOSS_BARS.getOrDefault(key, new HashMap<>());
        UUID playerId = player.getUniqueId();
        BossBar bossBar = bossBars.get(playerId);
        if (bossBar == null)
        {
            bossBar = createBossBar(key, holders);
            if (bossBar == null)
            {
                return;
            }

            bossBar.setProgress(Math.max(0.0, Math.min(progress, 1.0)));
            bossBars.put(playerId, bossBar);
        }

        bossBar.addPlayer(player);
        bossBar.setVisible(true);
        bossBar.setProgress(Math.max(0.0, Math.min(progress, 1.0)));
        BOSS_BARS.put(key, bossBars);
    }

    public static void removeBossBar(String key, UUID playerId)
    {
        Map<UUID, BossBar> bossBars = BOSS_BARS.get(key);
        if (bossBars == null)
        {
            return;
        }

        BossBar bossBar = bossBars.get(playerId);
        if (bossBar == null)
        {
            return;
        }

        bossBar.removeAll();
        bossBar.setVisible(false);
        bossBars.remove(playerId);
        if (bossBars.isEmpty())
        {
            BOSS_BARS.remove(key);
        }
        else
        {
            BOSS_BARS.put(key, bossBars);
        }
    }

    public static void clearBossBars()
    {
        for (Map<UUID, BossBar> bossBars : BOSS_BARS.values())
        {
            for (BossBar bossBar : bossBars.values())
            {
                bossBar.removeAll();
                bossBar.setVisible(false);
            }
        }

        BOSS_BARS.clear();
    }
}
