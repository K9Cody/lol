package com.github.rfsmassacre.heavenraces.tasks.vampire;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ElderTask extends BukkitRunnable
{
    private final RaceManager races;
    private final LeaderManager leaders;

    public ElderTask()
    {
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.leaders = HeavenRaces.getInstance().getLeaderManager();
    }

    @Override
    public void run()
    {
        races.getAllOrigins(Vampire.class, (vampires) ->
        {
            if (vampires.isEmpty())
            {
                return;
            }

            List<Vampire> sorted = new ArrayList<>(vampires);
            sorted.sort(Comparator.reverseOrder());
            Leader elder = leaders.getLeader(Race.VAMPIRE);
            Vampire runnerUp = sorted.getFirst();
            if (elder == null || !elder.getLeaderId().equals(runnerUp.getPlayerId()))
            {
                leaders.setLeader(new Leader(runnerUp.getPlayerId(), Race.VAMPIRE));
            }
        });
    }
}
