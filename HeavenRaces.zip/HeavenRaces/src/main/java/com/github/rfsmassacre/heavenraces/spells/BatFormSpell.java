package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenraces.events.VampireBatEvent;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class BatFormSpell extends Spell
{
    private final int cost;

    public BatFormSpell()
    {
        super("bat-form");

        this.cost = config.getInt(internalName + ".cost");
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        Vampire vampire = getOrigin(entity);
        Player player = vampire.getPlayer();
        if (vampire.inBatForm())
        {
            VampireBatEvent event = new VampireBatEvent(vampire, false);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                locale.sendLocale(player, true, "vampire.bat-form.cant-toggle");
                return false;
            }
        }
        else
        {
            if (player.getFoodLevel() <= cost)
            {
                locale.sendLocale(player, true, "vampire.bat-form.no-food");
                return false;
            }

            VampireBatEvent event = new VampireBatEvent(vampire, true);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                locale.sendLocale(player, true, "vampire.bat-form.cant-toggle");
                return false;
            }
            else if (!vampire.hasTalent("StrongWings"))
            {
                player.setFoodLevel(Math.max(0, player.getFoodLevel() - cost));
            }
        }

        return true;
    }
}
