package com.github.rfsmassacre.heavenraces.items.potions;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapelessRecipe;

public class CurePotion extends PotionItem
{
    public CurePotion()
    {
        super("CurePotion", Color.WHITE);
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapelessRecipe recipe = new ShapelessRecipe(key, item);
        recipe.addIngredient(Material.GLASS_BOTTLE);
        recipe.addIngredient(Material.POPPY);
        recipe.addIngredient(Material.MILK_BUCKET);
        return recipe;
    }
}
