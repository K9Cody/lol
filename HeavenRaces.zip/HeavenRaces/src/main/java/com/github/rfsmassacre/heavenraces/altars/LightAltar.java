/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.LightningStrike
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package com.github.rfsmassacre.heavenraces.altars;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.RaceChangeEvent;
import com.github.rfsmassacre.heavenraces.items.potions.HolyWater;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.utils.ConfigUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;

public class LightAltar extends Altar
{
    public LightAltar(HeavenRaces instance)
    {
        super(instance);

        this.name = config.getString("altars.light.name");
        this.description = config.getString("altars.light.description");
        this.core = Material.valueOf(config.getString("altars.light.core"));
        this.materials = ConfigUtil.getMaterialInteger(config, "altars.light.materials");
        this.resources = ConfigUtil.getMaterialInteger(config, "altars.light.resources");
    }

    @Override
    public void use(Origin origin)
    {
        Player player = origin.getPlayer();
        if (origin instanceof Vampire)
        {
            if (playerHasResources(player, resources))
            {
                RaceChangeEvent event = new RaceChangeEvent(origin, Origin.Race.HUMAN);
                Bukkit.getPluginManager().callEvent(event);

                Human human = new Human(origin);
                races.saveOrigin(human, true);
                races.addOrigin(human);

                player.getWorld().strikeLightningEffect(player.getLocation());
                player.sendHurtAnimation(0);

                locale.sendLocale(player, true, "infection.human");
                playerResourceUse(player, resources);
                return;
            }

            this.locale.sendLocale(player, true, "altars.missing-resources", "{list}",
                    convertToString(resources));
        }
        else if (origin instanceof Human human)
        {
            if (human.getInfectionRate(Origin.Race.VAMPIRE) <= 0.0)
            {
                ItemStack item = player.getInventory().getItemInMainHand();
                if (item.getType().equals(Material.POTION))
                {
                    if (item.getItemMeta() instanceof PotionMeta meta &&
                            PotionType.WATER.equals(meta.getBasePotionType()))
                    {
                        if (!human.getOrdainment().equals(Human.Ordainment.PRIEST))
                        {
                            locale.sendLocale(player, "human.altar.holy-water.not-priest");
                            return;
                        }

                        HolyWater holyWater = new HolyWater();
                        if (item.getAmount() <= 1)
                        {
                            player.getInventory().setItemInMainHand(holyWater.getItemStack());
                        }
                        else
                        {
                            item.setAmount(Math.max(0, item.getAmount() - 1));
                            player.getInventory().addItem(holyWater.getItemStack());
                        }

                        player.setCooldown(Material.SPLASH_POTION, 5);
                        locale.sendLocale(player, "human.altar.holy-water.success");
                    }
                }
                else
                {
                    locale.sendLocale(player, true, "human.altar.no-effect");
                }
            }
            else
            {
                human.cure();
                locale.sendLocale(player, true, "human.altar.cleanse");
            }
        }
        else
        {
            locale.sendLocale(player, true, "human.altar.no-effect");
        }

        /*
        if (origin instanceof Human)
        {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (this.isIngredient(item, this.holyWaterResources)) {
                if (LightAltar.playerHasResources(player, this.holyWaterResources)) {
                    LightAltar.playerResourceUse(player, this.holyWaterResources);
                    player.getInventory().addItem(new ItemStack[]{new HolyWater()});
                    this.locale.sendLocale((CommandSender)player, "human.crafting.holy-water", new String[0]);
                    return true;
                }
                this.locale.sendLocale((CommandSender)player, "altars.missing-holy-water", "{list}", Altar.convertToString(this.holyWaterResources), "Potion", "Water Bottle");
                return false;
            }
            if (new WoodenStake().equals(item)) {
                if (ItemUtil.getEnchant(item, "Blessing") > 0) {
                    this.locale.sendLocale((CommandSender)player, "human.crafting.already-blessed", new String[0]);
                    return false;
                }
                if (LightAltar.playerHasResources(player, this.blessingResources)) {
                    String power;
                    LightAltar.playerResourceUse(player, this.blessingResources);
                    int chance = RandomUtil.nextInt(100);
                    int tier1 = this.config.getInt("human.enchants.blessing.chance.tier-1");
                    int tier2 = this.config.getInt("human.enchants.blessing.chance.tier-2");
                    int tier3 = this.config.getInt("human.enchants.blessing.chance.tier-3");
                    int tier4 = this.config.getInt("human.enchants.blessing.chance.tier-4");
                    if (chance <= tier4) {
                        player.getInventory().setItemInMainHand(ItemUtil.applyEnchant(item, 4, "Blessing"));
                        power = ItemUtil.toNumeral(4);
                    } else if (chance <= tier3) {
                        player.getInventory().setItemInMainHand(ItemUtil.applyEnchant(item, 3, "Blessing"));
                        power = ItemUtil.toNumeral(3);
                    } else if (chance <= tier2) {
                        player.getInventory().setItemInMainHand(ItemUtil.applyEnchant(item, 2, "Blessing"));
                        power = ItemUtil.toNumeral(2);
                    } else {
                        player.getInventory().setItemInMainHand(ItemUtil.applyEnchant(item, 1, "Blessing"));
                        power = ItemUtil.toNumeral(1);
                    }
                    player.updateInventory();
                    this.locale.sendLocale((CommandSender)player, "human.crafting.blessing", "{power}", power);
                    return true;
                }
                this.locale.sendLocale((CommandSender)player, "altars.missing-blessing", "{list}", Altar.convertToString(this.blessingResources), "Splash Potion", "Holy Water");
                return false;
            }
            this.locale.sendMessage((CommandSender)player, this.locale.getMessage("prefix") + this.description, new String[0]);
            FXUtil.enderBurst(player, this.config.getInt("vampire.effects.ender-burst"));
            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 100, 0));
            return false;
        }
        this.locale.sendMessage((CommandSender)player, this.locale.getMessage("prefix") + this.description, new String[0]);
        FXUtil.enderBurst(player, this.config.getInt("vampire.effects.ender-burst"));
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 100, 0));
        return false;
         */
    }

    private boolean isIngredient(ItemStack item, ArrayList<ItemStack> ingredients)
    {
        if (item == null || item.getType().equals(Material.AIR))
        {
            return false;
        }
        for (ItemStack ingredient : ingredients)
        {
            if (!ingredient.getType().equals(item.getType()))
            {
                continue;
            }
            return true;
        }
        return false;
    }
}

