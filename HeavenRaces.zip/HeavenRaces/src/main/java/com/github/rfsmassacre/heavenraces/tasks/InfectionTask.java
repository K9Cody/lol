package com.github.rfsmassacre.heavenraces.tasks;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.ExperienceGainEvent;
import com.github.rfsmassacre.heavenraces.events.InfectGrowEvent;
import com.github.rfsmassacre.heavenraces.events.LevelUpEvent;
import com.github.rfsmassacre.heavenraces.events.RaceChangeEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class InfectionTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;

    public InfectionTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
    }

    @Override
    public void run()
    {
        double rate = config.getDouble("infection.rate");
        double max = config.getDouble("infection.max");
        for (Human human : races.getOrigins(Human.class))
        {
            Player player = human.getPlayer();
            if (player == null)
            {
                continue;
            }

            Human.Infection infection = human.getInfection();
            if (infection == null)
            {
                continue;
            }

            Origin origin = null;
            Origin.Race race = infection.getRace();
            if (infection.getProgress() >= max)
            {
                switch (race)
                {
                    case VAMPIRE -> origin = new Vampire(human);
                    case WEREWOLF -> origin = new Werewolf(human, infection.getClan());
                }

                if (origin == null)
                {
                    return;
                }

                RaceChangeEvent changeEvent = new RaceChangeEvent(origin, race);
                Bukkit.getPluginManager().callEvent(changeEvent);
                if (changeEvent.isCancelled())
                {
                    return;
                }

                races.deleteOrigin(human);
                races.saveOrigin(origin, true);
                races.addOrigin(origin);
                locale.sendLocale(origin.getPlayer(), true, "infection." +
                        origin.getRace().toString().toLowerCase() + ".end");
                Origin infector = races.getOrigin(infection.getInfectorId(), Origin.class);
                if (infection.getRace().equals(infector.getRace()))
                {
                    double xp = config.getDouble("xp." + race.toString().toLowerCase() + ".player-transform");
                    ExperienceGainEvent xpEvent = new ExperienceGainEvent(infector, xp);
                    Bukkit.getPluginManager().callEvent(xpEvent);
                    if (!xpEvent.isCancelled())
                    {
                        int oldLevel = (int) infector.getLevel();
                        infector.addLevel(xpEvent.getXp());
                        int newLevel = (int) infector.getLevel();
                        if (newLevel > oldLevel)
                        {
                            LevelUpEvent levelEvent = new LevelUpEvent(infector, newLevel);
                            Bukkit.getPluginManager().callEvent(levelEvent);
                        }
                    }
                }
            }
            else if (infection.getProgress() > 0)
            {
                InfectGrowEvent event = new InfectGrowEvent(human, race, rate);
                Bukkit.getPluginManager().callEvent(event);
                if (!event.isCancelled())
                {
                    int oldLevel = (int)human.getInfection().getProgress();
                    human.addInfectionRate(rate);
                    int newLevel = (int)human.getInfection().getProgress();
                    if (newLevel > oldLevel)
                    {
                        String notice = config.getString("infection-notice." +
                                race.toString().toLowerCase() + "." + newLevel);

                        if (notice != null && !notice.isEmpty())
                        {
                            locale.sendMessage(human.getPlayer(), notice);
                        }
                    }
                }
            }
        }
    }
}
