package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.managers.TextManager;
import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.HeavenRaces.ConfigType;
import com.github.rfsmassacre.heavenraces.events.RaceChangeEvent;
import com.github.rfsmassacre.heavenraces.events.SpiritFormEvent;
import com.github.rfsmassacre.heavenraces.events.VampireBatEvent;
import com.github.rfsmassacre.heavenraces.events.WerewolfFormEvent;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import com.github.rfsmassacre.heavenraces.managers.*;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.moons.Moon.MoonPhase;
import com.github.rfsmassacre.heavenraces.players.*;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.worldmap.WorldMapUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AdminCommand extends PaperCommand
{
    private final PaperConfiguration config;
    private final TextManager text;
    private final RaceManager races;
    private final LeaderManager leaders;
    private final TaskManager tasks;
    private final ItemManager items;
    private final SkinManager skins;
    private final MoonManager moons;

    public AdminCommand()
    {
        super(HeavenRaces.getInstance(), "raceadmin");

        HeavenRaces instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.text = instance.getTextManager();
        this.races = instance.getRaceManager();
        this.leaders = instance.getLeaderManager();
        this.tasks = instance.getTaskManager();
        this.items = instance.getItemManager();
        this.skins = instance.getSkinManager();
        this.moons = instance.getMoonManager();
    }

    /*
     * Reload command
     */
    private class ReloadCommand extends PaperSubCommand
    {
        public ReloadCommand()
        {
            super("reload", "heavenraces.admin.reload");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            locale.sendLocale(sender, true, "admin.reloading");
            Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
            {
                text.loadTexts();
                locale.reload();
                for (ConfigType type : ConfigType.values())
                {
                    HeavenRaces.getInstance().getConfiguration(type).reload();
                }

                races.updateOrigins(false);
                races.loadSpawns(false);
                tasks.cancelTasks();
                tasks.startTasks();
                Spell.loadSpells();
                Talent.reloadData();
                Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
                {
                    items.unloadRecipes();
                    items.loadItems();
                    items.loadRecipes();
                    locale.sendLocale(sender, true, "admin.reload");
                });
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Infect command
     */
    private class InfectCommand extends PaperSubCommand
    {
        public InfectCommand()
        {
            super("infect", "heavenraces.admin.infect");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //raceadmin infect <player> <race> <amount>
            if (args.length < 4)
            {
                onInvalidArgs(sender, "<player>",  "<race>", "<percent>");
                return;
            }

            String playerName = args[1];
            String raceName = args[2];
            String amountString = args[3];
            races.getOrLoadOrigin(playerName, Human.class, (human) ->
            {
                try
                {
                    Race race = Race.valueOf(raceName.toUpperCase());
                    double amount = Double.parseDouble(amountString);
                    if (human == null)
                    {
                        locale.sendLocale(sender, true, "admin.infect.requirement");
                        return;
                    }

                    if (race.equals(Race.HUMAN))
                    {
                        locale.sendLocale(sender, true, "admin.infect.human");
                        return;
                    }

                    human.setInfection(new Human.Infection(race, amount));
                    locale.sendLocale(sender, true,"admin.infect.successful", "{player}",
                            human.getDisplayName(), "{amount}", Integer.toString((int)amount), "{race}",
                            LocaleData.capitalize(race.toString()));
                }
                catch (NumberFormatException exception)
                {
                    locale.sendLocale(sender, true, "invalid.number", "{arg}", amountString);
                }
                catch (IllegalArgumentException exception)
                {
                    locale.sendLocale(sender, true, "invalid.race", "{arg}", raceName);
                }
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }
            else if (args.length == 3)
            {
                for (Race race : Race.values())
                {
                    if (!race.equals(Race.HUMAN))
                    {
                        suggestions.add(race.toString());
                    }
                }
            }
            return suggestions;
        }
    }

    /*
     * Spawn items without having to craft them.
     */
    private class ItemCommand extends PaperSubCommand
    {
        public ItemCommand()
        {
            super("item", "heavenraces.admin.item");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //raceadmin item <player> <item>
            if (args.length >= 3)
            {
                //raceadmin item <player> <item>
                String playerName = args[1];
                String itemName = args[2];

                Player player = Bukkit.getPlayer(playerName);
                if (player == null)
                {
                    locale.sendLocale(sender, true, "invalid.no-player", "{name}",
                            playerName);
                    return;
                }

                RaceItem item = items.getItem(itemName);
                if (item == null)
                {
                    locale.sendLocale(sender, true, "invalid.item", "{item}", itemName);
                    return;
                }

                player.getInventory().addItem(item.getItemStack());
                locale.sendLocale(sender, true, "admin.item.sent", "{player}",
                        player.getDisplayName(), "{item}", item.getDisplayName());
                locale.sendLocale(player, true, "admin.item.receive", "{item}",
                        item.getDisplayName());

                return;
            }
            //raceadmin item <item>
            else if (args.length == 2)
            {
                if (!(sender instanceof Player player))
                {
                    locale.sendLocale(sender, true, "invalid.console");
                    return;
                }

                String itemName = args[1];
                RaceItem item = items.getItem(itemName);
                if (item == null)
                {
                    locale.sendLocale(player, true, "invalid.item", "{item}", itemName);
                    return;
                }

                player.getInventory().addItem(item.getItemStack());
                locale.sendLocale(player, true, "admin.item.received", "{item}",
                        item.getDisplayName());

                return;
            }

            onInvalidArgs(sender, "<item>", "[player]");
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                suggestions.addAll(items.getItemNames());
            }
            return suggestions;
        }
    }

    /*
     * Change races
     */
    private class ChangeCommand extends PaperSubCommand
    {
        public ChangeCommand()
        {
            super("change", "heavenraces.admin.change");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //race change
            if (args.length == 1)
            {
               onInvalidArgs(sender, "<race>", "[player]");
            }
            //race change <race>
            else if (args.length == 2)
            {
                if (!(sender instanceof Player player))
                {
                    locale.sendLocale(sender, true, "invalid.console");
                    return;
                }

                Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
                if (origin == null)
                {
                    return;
                }

                String raceName = args[1];
                Race race = Race.fromString(raceName);
                if (race == null)
                {
                    locale.sendLocale(sender, "invalid.race", "{arg}", raceName);
                    return;
                }

                changePlayer(sender, origin, race);
            }
            else
            {
                String raceName = args[1];
                Race race = Race.fromString(raceName);
                if (race == null)
                {
                    locale.sendLocale(sender, "invalid.race", "{arg}", raceName);
                    return;
                }

                String playerName = args[2];
                races.getOrLoadOrigin(playerName, Origin.class, (origin) ->
                {
                    if (origin == null)
                    {
                        locale.sendLocale(sender, true, "invalid.no-player", "{name}",
                                playerName);
                        return;
                    }

                    changePlayer(sender, origin, race);
                });
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Race race : Race.values())
                {
                    suggestions.add(race.toString().toLowerCase());
                }
            }
            else if (args.length == 3)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }

    private void changePlayer(CommandSender sender, Origin origin, Race race)
    {
        Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
        {
            try
            {
                if (origin.getPlayer() != null)
                {
                    //Remove the players from their transformed modes too
                    switch (origin)
                    {
                        case Vampire vampire ->
                        {
                            if (vampire.inBatForm())
                            {
                                VampireBatEvent batEvent = new VampireBatEvent(vampire, false);
                                Bukkit.getPluginManager().callEvent(batEvent);
                            }
                        }
                        case Werewolf werewolf ->
                        {
                            if (werewolf.isWolfForm())
                            {
                                WerewolfFormEvent formEvent = new WerewolfFormEvent(werewolf, false);
                                Bukkit.getPluginManager().callEvent(formEvent);
                            }
                        }
                        case Spirit spirit ->
                        {
                            if (spirit.isSpiritForm())
                            {
                                SpiritFormEvent formEvent = new SpiritFormEvent(spirit, false);
                                Bukkit.getPluginManager().callEvent(formEvent);
                            }
                        }
                        default ->
                        {
                            //Do nothing
                        }
                    }
                }

                Origin newOrigin = null;
                switch (race)
                {
                    case HUMAN -> newOrigin = new Human(origin);
                    case VAMPIRE -> newOrigin = new Vampire(origin);
                    case WEREWOLF -> newOrigin = new Werewolf(origin);
                    case ANGEL -> newOrigin = new Angel(origin, Spirit.Rank.SERAPH);
                    case DEMON -> newOrigin = new Demon(origin, Spirit.Rank.SERAPH);
                }

                if (newOrigin == null)
                {
                    locale.sendLocale(sender, true, "race.change.failed");
                    return;
                }

                Origin finalNewOrigin = newOrigin;
                Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
                {
                    RaceChangeEvent event = new RaceChangeEvent(origin, race);
                    Bukkit.getPluginManager().callEvent(event);
                    if (!event.isCancelled())
                    {
                        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
                        {
                            //Offline support
                            if (origin.getPlayer() == null)
                            {
                                races.deleteOrigin(origin);
                                races.saveOrigin(finalNewOrigin, false);
                            }
                            else
                            {
                                races.addOrigin(finalNewOrigin);
                            }

                            locale.sendLocale(origin.getPlayer(), true, "race.change.other",
                                    "{player}", finalNewOrigin.getDisplayName(), "{race}",
                                    LocaleData.capitalize(finalNewOrigin.getRace().toString()));
                            if (!sender.equals(origin.getPlayer()))
                            {
                                locale.sendLocale(sender, true, "race.change.other", "{player}",
                                        finalNewOrigin.getDisplayName(), "{race}",
                                        LocaleData.capitalize(finalNewOrigin.getRace().toString()));
                            }
                        });
                    }
                    else
                    {
                        locale.sendLocale(sender, true, "race.change.failed");
                    }
                });
            }
            catch (IllegalArgumentException exception)
            {
                locale.sendLocale(sender, true, "race.change.invalid", "{race}",
                        LocaleData.capitalize(race.toString()));
            }
        });
    }

    /*
     * Change Clan Command
     */
    private class ClanCommand extends PaperSubCommand
    {
        public ClanCommand()
        {
            super("clan", "heavenraces.admin.clan");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //ra clan
            if (args.length == 1)
            {
                onInvalidArgs(sender, "<clan>", "[player]");
            }
            //race clan <clan>
            else if (args.length == 2)
            {
                if (!(sender instanceof Player player))
                {
                    locale.sendLocale(sender, true, "invalid.console");
                    return;
                }

                String clanString = args[1].toUpperCase();
                Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
                if (werewolf == null)
                {
                    locale.sendLocale(sender, true, "invalid.not-werewolf");
                    return;
                }

                clanPlayer(sender, werewolf, clanString);
            }
            else
            {
                String clanString = args[1].toUpperCase();
                String playerName = args[2];
                races.getOrLoadOrigin(playerName, Werewolf.class, (werewolf) ->
                {
                    //If player is offline
                    if (werewolf == null)
                    {
                        locale.sendLocale(sender, true, "invalid.no-player", "{name}", playerName);
                    }
                    //If player is online
                    else
                    {
                        clanPlayer(sender, werewolf, clanString);
                    }
                });
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Clan clan : Clan.values())
                {
                    suggestions.add(clan.toString().toLowerCase());
                }
            }
            else if (args.length == 3)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }

    /*
     * Change Clan Command
     */
    private class RankCommand extends PaperSubCommand
    {
        public RankCommand()
        {
            super("rank", "heavenraces.admin.rank");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //ra clan
            if (args.length == 1)
            {
                onInvalidArgs(sender, "<rank>", "[player]");
            }
            //race clan <clan>
            else if (args.length == 2)
            {
                if (!(sender instanceof Player player))
                {
                    locale.sendLocale(sender, true, "invalid.console");
                    return;
                }

                String rankString = args[1].toUpperCase();
                Spirit spirit = races.getOrigin(player.getUniqueId(), Spirit.class);
                if (spirit == null)
                {
                    locale.sendLocale(sender, true, "invalid.not-spirit");
                    return;
                }

                rankPlayer(sender, spirit, rankString);
            }
            else
            {
                String clanString = args[1].toUpperCase();
                String playerName = args[2];
                Player target = Bukkit.getPlayer(playerName);

                //If player is offline
                if (target == null)
                {
                    locale.sendLocale(sender, true, "invalid.no-player", "{name}", playerName);
                }
                //If player is online
                else
                {
                    Angel angel = races.getOrigin(target.getUniqueId(), Angel.class);
                    if (angel == null)
                    {
                        locale.sendLocale(sender, true, "invalid.not-angel");
                        return;
                    }

                    rankPlayer(sender, angel, clanString);
                }
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Spirit.Rank rank : Spirit.Rank.values())
                {
                    suggestions.add(rank.toString().toLowerCase());
                }
            }
            else if (args.length == 3)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }

    /*
     * Change Clan Command
     */
    private class OrdainmentCommand extends PaperSubCommand
    {
        public OrdainmentCommand()
        {
            super("ordainment", "heavenraces.admin.ordainment");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //ra clan
            if (args.length == 1)
            {
                onInvalidArgs(sender, "<rank>", "[player]");
            }
            //race clan <clan>
            else if (args.length == 2)
            {
                if (!(sender instanceof Player player))
                {
                    locale.sendLocale(sender, true, "invalid.console");
                    return;
                }

                String ordainmentString = args[1].toUpperCase();
                Human human = races.getOrigin(player.getUniqueId(), Human.class);
                if (human == null)
                {
                    locale.sendLocale(sender, true, "invalid.not-human");
                    return;
                }

                ordainPlayer(sender, human, ordainmentString);
            }
            else
            {
                String ordainmentString = args[1].toUpperCase();
                String playerName = args[2];
                Player target = Bukkit.getPlayer(playerName);

                //If player is offline
                if (target == null)
                {
                    locale.sendLocale(sender, true, "invalid.no-player", "{name}",
                            playerName);
                }
                //If player is online
                else
                {
                    Human human = races.getOrigin(target.getUniqueId(), Human.class);
                    if (human == null)
                    {
                        locale.sendLocale(sender, true, "invalid.not-human");
                        return;
                    }

                    ordainPlayer(sender, human, ordainmentString);
                }
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Human.Ordainment ordainment : Human.Ordainment.values())
                {
                    suggestions.add(ordainment.toString().toLowerCase());
                }
            }
            else if (args.length == 3)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }

    private void clanPlayer(CommandSender sender, Werewolf werewolf, String clanString)
    {
        Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
        {
            try
            {
                Clan clan = Clan.valueOf(clanString);
                if (werewolf.isWolfForm())
                {
                    WerewolfFormEvent event = new WerewolfFormEvent(werewolf, false);
                    Bukkit.getPluginManager().callEvent(event);
                }

                Werewolf newWerewolf = new Werewolf(werewolf, clan);
                Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
                {
                    if (werewolf.getPlayer() == null)
                    {
                        races.deleteOrigin(werewolf);
                        races.saveOrigin(newWerewolf, false);
                    }
                    else
                    {
                        races.addOrigin(newWerewolf);
                    }

                    locale.sendLocale(werewolf.getPlayer(), true, "admin.clan.success", "{player}",
                            newWerewolf.getDisplayName(), "{clan}", LocaleData.capitalize(clan.toString()));
                    if (!sender.equals(werewolf.getPlayer()))
                    {
                        locale.sendLocale(sender, true, "admin.clan.success", "{player}",
                                newWerewolf.getDisplayName(), "{clan}", LocaleData.capitalize(clan.toString()));
                    }
                });

            }
            catch (IllegalArgumentException exception)
            {
                locale.sendLocale(sender, true, "invalid.clan", "{arg}",
                        LocaleData.capitalize(clanString));
            }
        });
    }

    private void rankPlayer(CommandSender sender, Spirit spirit, String rankString)
    {
        Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
        {
            try
            {
                Spirit.Rank rank = Spirit.Rank.valueOf(rankString);
                if (spirit.isSpiritForm())
                {
                    SpiritFormEvent event = new SpiritFormEvent(spirit, false);
                    Bukkit.getPluginManager().callEvent(event);
                }

                final Spirit newSpirit;
                switch (spirit.getRace())
                {
                    case ANGEL -> newSpirit = new Angel(spirit.getPlayer(), Spirit.Rank.valueOf(rankString));
                    case DEMON -> newSpirit = new Demon(spirit.getPlayer(), Spirit.Rank.valueOf(rankString));
                    default -> newSpirit = null;
                }

                if (newSpirit != null)
                {
                    Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
                    {
                        races.addOrigin(newSpirit);
                        races.saveOrigin(newSpirit, true);
                        locale.sendLocale(sender, true, "admin.rank.success", "{player}",
                                newSpirit.getDisplayName(), "{rank}", LocaleData.capitalize(rank.toString()));
                    });
                }
            }
            catch (IllegalArgumentException exception)
            {
                locale.sendLocale(sender, true, "invalid.rank", "{arg}",
                        LocaleData.capitalize(rankString));
            }
        });
    }

    private void ordainPlayer(CommandSender sender, Human human, String ordainString)
    {
        Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
        {
            try
            {
                Human.Ordainment ordainment = Human.Ordainment.valueOf(ordainString);
                human.setOrdainment(ordainment);
                locale.sendLocale(sender, true, "admin.ordain.success", "{player}",
                        human.getDisplayName(), "{ordainment}", LocaleData.capitalize(ordainment.toString()));
            }
            catch (IllegalArgumentException exception)
            {
                locale.sendLocale(sender, true, "invalid.ordainment", "{arg}",
                        LocaleData.capitalize(ordainString));
            }
        });
    }

    private class LeaderCommand extends PaperSubCommand
    {
        public LeaderCommand()
        {
            super("leader", "heavenraces.admin.leader");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //ra leader <player>
            if (args.length < 2)
            {
                onInvalidArgs(sender, "<player>");
                return;
            }

            String playerName = args[1];
            races.getOrLoadOrigin(playerName, Origin.class, (origin) ->
            {
                if (origin == null)
                {
                    locale.sendLocale(sender, true, "invalid.no-player", "{name}", playerName);
                    return;
                }

                Race race = origin.getRace();
                String title = "Leader";
                Leader leader = leaders.getLeader(race);
                switch (race)
                {
                    case HUMAN -> title = "Human Master";
                    case VAMPIRE -> title = "Vampire Elder";
                }

                boolean inForm = false;
                if (origin instanceof Werewolf werewolf)
                {
                    Clan clan = werewolf.getClan();
                    leader = leaders.getLeader(clan);
                    title = "Werewolf " + LocaleData.capitalize(clan.toString()) + " Alpha";
                    inForm = werewolf.isWolfForm();
                }

                if (leader != null && origin.getPlayerId().equals(leader.getLeaderId()))
                {
                    locale.sendLocale(sender, true, "admin.leader.already-leader", "{player}",
                            origin.getDisplayName(), "{leader}", title);
                    return;
                }

                leaders.setLeader(origin);
                if (inForm && origin.getPlayer() != null)
                {
                    skins.applySkin(origin.getPlayer(), skins.getSkin((Werewolf) origin));
                }

                locale.sendLocale(sender, true, "admin.leader.success", "{player}",
                        origin.getDisplayName(), "{leader}", title);
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }

    private class LevelCommand extends PaperSubCommand
    {
        private enum Operation
        {
            ADD,
            SET,
            REMOVE
        }

        public LevelCommand()
        {
            super("level", "heavenraces.admin.level");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            //ra exp <ADD/SET/REMOVE> <exp> [player]
            if (args.length < 3)
            {
                onInvalidArgs(sender, "<add/set/remove>",  "<level>", "[player]");
                return;
            }

            Operation operation;
            try
            {
                operation = Operation.valueOf(args[1].toUpperCase());
            }
            catch (IllegalArgumentException exception)
            {
                locale.sendLocale(sender, true, "admin.exp.operation");
                return;
            }

            double level;
            try
            {
                level = Double.parseDouble(args[2]);
            }
            catch (NumberFormatException exception)
            {
                locale.sendLocale(sender, true, "invalid.number", "{arg}", args[2]);
                return;
            }

            if (sender instanceof Player player)
            {
                Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
                if (origin == null)
                {
                    return;
                }

                switch (operation)
                {
                    case ADD -> origin.addLevel(Math.abs(level));
                    case SET -> origin.setLevel(level);
                    case REMOVE -> origin.addLevel(-Math.abs(level));
                }

                locale.sendLocale(player, true, "admin.exp.updated", "{player}",
                        origin.getDisplayName(), "{level}", Integer.toString((int) origin.getLevel()));
                return;
            }

            if (args.length < 4)
            {
                return;
            }

            String playerName = args[3];
            races.getOrLoadOrigin(playerName, Origin.class, (origin) ->
            {
                if (origin == null)
                {
                    locale.sendLocale(sender, true, "invalid.no-player", "{name}", args[3]);
                    return;
                }

                switch (operation)
                {
                    case ADD -> origin.addLevel(Math.abs(level));
                    case SET -> origin.setLevel(level);
                    case REMOVE -> origin.addLevel(-Math.abs(level));
                }

                races.saveOrigin(origin, false);
                locale.sendLocale(sender, true, "admin.exp.updated", "{player}",
                        origin.getDisplayName(), "{level}", Integer.toString((int) origin.getLevel()));
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                suggestions.add("add");
                suggestions.add("set");
                suggestions.add("remove");
            }
            else if (args.length == 4)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }

    /*
     * Set moon phase
     */
    private class MoonPhaseCommand extends PaperSubCommand
    {
        public MoonPhaseCommand()
        {
            super("moonphase", "heavenraces.admin.moonphase");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                onConsole(sender);
                return;
            }

            //ra moonphase <phase>
            if (args.length < 2)
            {
                onInvalidArgs(player, "<phase>");
                return;
            }

            World world = player.getWorld();
            Moon moon = moons.getMoon(world);
            if (moon == null)
            {
                locale.sendLocale(player, true, "moon.invalid-world");
                return;
            }

            String phaseName = args[1];
            MoonPhase phase = MoonPhase.fromString(phaseName);
            if (phase == null)
            {
                locale.sendLocale(player, true, "moon.invalid-phase", "{arg}", phaseName);
                return;
            }

            moon.setPhase(phase);
            locale.sendLocale(player, true, "moon.set-phase", "{phase}", phase.toString());
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (MoonPhase phase : MoonPhase.values())
                {
                    suggestions.add(phase.toString());
                }
            }

            return suggestions;
        }
    }

    /*
     * Admin help command
     */
    private class HelpCommand extends PaperSubCommand
    {
        public HelpCommand()
        {
            super("help", "heavenraces.admin.help");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            List<String> lines1 = text.getText("admin-help1.txt");
            List<String> lines2 = text.getText("admin-help2.txt");
            String menu1 = String.join("\n", lines1);
            String menu2 = String.join("\n", lines2);
            if (args.length == 1)
            {
                locale.sendMessage(sender, menu1);
            }
            else
            {
                try
                {
                    int page = Integer.parseInt(args[1]);
                    if (page <= 1)
                    {
                        //Page 1
                        locale.sendMessage(sender, menu1);
                    }
                    else
                    {
                        //Page 2
                        locale.sendMessage(sender, menu2);
                    }
                }
                catch (NumberFormatException exception)
                {
                    locale.sendLocale(sender, true, "invalid.number", "{arg}", args[1]);
                }
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            suggestions.add("1");
            suggestions.add("2");
            return suggestions;
        }
    }

    private class PurgeCommand extends PaperSubCommand
    {
        public PurgeCommand()
        {
            super("purge");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            races.getOfflineOrigins(Origin.class, (origins) ->
            {
                for (Origin origin : origins)
                {
                    if (origin == null || origin.getPlayerId() == null || origin.getDisplayName() == null)
                    {
                        races.deleteOrigin(origin);
                    }
                }

                locale.sendLocale(sender, "admin.purged");
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    private class SetSpawnCommand extends PaperSubCommand
    {
        public SetSpawnCommand()
        {
            super("setspawn");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                onConsole(sender);
                return;
            }

            //ra moonphase <phase>
            if (args.length < 2)
            {
                onInvalidArgs(player, "{race}");
                return;
            }

            String raceName = args[1];
            Race race = Race.fromString(raceName);
            if (race == null)
            {
                locale.sendLocale(player, true, "invalid.race", "{arg}", raceName);
                return;
            }

            Location location = player.getLocation();
            races.setSpawn(race, location);
            if (Bukkit.getPluginManager().isPluginEnabled("Squaremap"))
            {
                WorldMapUtil.registerSpawn(race, location);
            }

            locale.sendLocale(player, true, "admin.set-spawn", "{race}",
                    LocaleData.capitalize(race.toString()), "{x}", Integer.toString(location.getBlockX()), "{y}",
                    Integer.toString(location.getBlockY()), "{z}", Integer.toString(location.getBlockX()), "{world}",
                    location.getWorld().getName());
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 1)
            {
                for (Race race : Race.values())
                {
                    suggestions.add(race.toString());
                }
            }

            return suggestions;
        }
    }
}
