package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class KeyBindListener implements Listener
{
    private static final long DOUBLE_SNEAK_THRESHOLD = 500L;
    private static final Map<UUID, Long> DROPPED = new HashMap<>();
    private static final Map<UUID, Long> SNEAKED = new HashMap<>();
    private final PaperLocale locale;
    private final RaceManager races;

    public KeyBindListener()
    {
        this.locale = HeavenRaces.getInstance().getLocale();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAnimation(PlayerDropItemEvent event)
    {
        DROPPED.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrop(PlayerDropItemEvent event)
    {
        Player player = event.getPlayer();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null || !origin.isAbilityActive())
        {
            return;
        }

        Spell spell = origin.getSpell(Origin.KeyBind.DROP);
        if (spell != null)
        {
            event.setCancelled(true);
            spell.cast(player);
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent event)
    {
        Player player = event.getPlayer();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null || !origin.isAbilityActive())
        {
            return;
        }

        Spell spell = origin.getSpell(Origin.KeyBind.SWAP);
        if (spell != null)
        {
            event.setCancelled(true);
            spell.cast(player);
        }
    }

    @EventHandler
    public void onClick(PlayerInteractEvent event)
    {
        Player player = event.getPlayer();
        long dropTime = DROPPED.getOrDefault(player.getUniqueId(), 0L);
        if (System.currentTimeMillis() - dropTime < 500L)
        {
            return;
        }
        else
        {
            DROPPED.remove(player.getUniqueId());
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null || !origin.isAbilityActive())
        {
            return;
        }

        if (event.getAction().isLeftClick())
        {
            Spell spell = origin.getSpell(Origin.KeyBind.LEFT_CLICK);
            if (spell != null)
            {
                event.setCancelled(true);
                spell.cast(player);
            }
        }
        else if (event.getAction().isRightClick())
        {
            Spell spell = origin.getSpell(Origin.KeyBind.RIGHT_CLICK);
            if (spell != null)
            {
                event.setCancelled(true);
                spell.cast(player);
            }
        }
    }

    @EventHandler
    public void onDoubleSneak(PlayerToggleSneakEvent event)
    {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        if (!event.isSneaking())
        {
            return;
        }

        long currentTime = System.currentTimeMillis();
        long lastSneakTime = SNEAKED.getOrDefault(playerId, 0L);
        if (currentTime - lastSneakTime <= DOUBLE_SNEAK_THRESHOLD)
        {
            SNEAKED.remove(playerId);
            Origin origin = races.getOrigin(playerId, Origin.class);
            if (origin == null || origin instanceof Human)
            {
                return;
            }

            // Toggle the current ability
            boolean active = !origin.isAbilityActive();
            origin.setAbilityActive(active);

            // Provide feedback to the player
            locale.sendActionLocale(player, false, "race.ability-toggle", "{status}", active ?
                    "&a&lENABLED" : "&c&lDISABLED");
            player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0F, 0.5F);
        }
        else
        {
            // Update the last sneak time
            SNEAKED.put(playerId, currentTime);
        }
    }
}
