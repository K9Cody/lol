package com.github.rfsmassacre.heavenraces.items.weapons;

import com.github.rfsmassacre.heavenraces.items.RaceItem;
import lombok.Getter;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

@Getter
public class SilverSword extends RaceItem
{
    public static SilverSword of(ItemStack item)
    {
        SilverSword silverSword = new SilverSword(item.getItemMeta());
        if (silverSword.equals(item))
        {
            return silverSword;
        }

        return null;
    }

    private final ItemMeta itemMeta;

    public SilverSword(ItemMeta itemMeta)
    {
        super("SilverSword", Material.IRON_SWORD);

        this.itemMeta = itemMeta;
    }

    public SilverSword()
    {
        this(null);
    }

    @Override
    public ItemStack getItemStack()
    {
        if (itemMeta == null)
        {
            return item;
        }

        ItemMeta meta = item.getItemMeta();
        if (item.getItemMeta() == null)
        {
            return item;
        }

        itemMeta.setCustomModelData(meta.getCustomModelData());
        itemMeta.displayName(meta.displayName());
        List<Component> newLore = meta.lore();
        if (newLore != null)
        {
            List<Component> oldLore = itemMeta.lore();
            if (oldLore == null)
            {
                oldLore = new ArrayList<>();
            }

            newLore.addAll(oldLore);
        }

        itemMeta.lore(newLore);
        item.setItemMeta(itemMeta);
        this.setNBT(key, name);
        return item;
    }

    @Override
    protected Recipe createRecipe()
    {
        return new FurnaceRecipe(this.key, item, this.material, 0.0F, 1600);
    }
}
