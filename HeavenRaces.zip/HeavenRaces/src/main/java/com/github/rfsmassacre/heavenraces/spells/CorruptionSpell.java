package com.github.rfsmassacre.heavenraces.spells;

import org.bukkit.entity.LivingEntity;

public class CorruptionSpell extends Spell
{
    public CorruptionSpell()
    {
        super("corruption");
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        return false;
    }
}
