package com.github.rfsmassacre.heavenraces.tasks;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import org.bukkit.scheduler.BukkitRunnable;

public class CorruptionTrackTask extends BukkitRunnable
{
    private static final String KEY = "corruption";
    private static final int MAX_CORRUPTION = 100;

    private final RaceManager races;

    public CorruptionTrackTask()
    {
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    /**
     * Runs this operation.
     */
    @Override
    public void run()
    {
        for (Origin origin : races.getOrigins(Origin.class))
        {
            if (!origin.isOnline() ||  origin instanceof Demon)
            {
                BossBarUtil.removeBossBar("c", origin.getPlayerId());
                continue;
            }

            int corruption = origin.getCorruption();
            if (corruption == 0)
            {
                BossBarUtil.removeBossBar(KEY, origin.getPlayerId());
                continue;
            }

            BossBarUtil.updateBossBar(origin.getPlayer(), (double) corruption / MAX_CORRUPTION, KEY);
        }
    }
}
