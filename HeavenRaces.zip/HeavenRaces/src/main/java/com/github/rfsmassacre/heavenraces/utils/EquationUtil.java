package com.github.rfsmassacre.heavenraces.utils;

public class EquationUtil
{
    public static int getTransformTime(int slope, int minimum, int maximum)
    {
        double time = slope;
        if (time < (double)minimum)
        {
            time = minimum;
        }
        else if (time > (double)maximum)
        {
            time = maximum;
        }
        return (int) time;
    }
}
