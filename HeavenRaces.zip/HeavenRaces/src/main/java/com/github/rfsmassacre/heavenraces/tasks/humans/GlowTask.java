package com.github.rfsmassacre.heavenraces.tasks.humans;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Angel;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class GlowTask extends BukkitRunnable
{
    private final RaceManager races;
    public static final Set<UUID> GLOWS = new HashSet<>();

    public GlowTask()
    {
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @Override
    public void run()
    {
        for (Origin origin : races.getOrigins(Origin.class))
        {
            if (origin instanceof Human human)
            {
                Talent executioner = human.getTalent("Executioner");
                if (executioner == null)
                {
                    continue;
                }

                double percent = executioner.getDouble("health-ratio");
                int range = executioner.getInt("range");
                int duration = executioner.getInt("duration");
                if (human.hasTalent(executioner))
                {
                    for (Entity entity : human.getPlayer().getNearbyEntities(range, range, range))
                    {
                        if (entity instanceof Player nearbyPlayer)
                        {
                            double maxHealth = nearbyPlayer.getAttribute(Attribute.MAX_HEALTH).getValue();
                            if (nearbyPlayer.getHealth() / maxHealth <= percent)
                            {
                                Origin victim = races.getOrigin((nearbyPlayer.getUniqueId()), Origin.class);
                                if (!(victim instanceof Human) && !(victim instanceof Angel))
                                {
                                    nearbyPlayer.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, duration,
                                            0));
                                    GLOWS.add(nearbyPlayer.getUniqueId());
                                }
                            }
                            else
                            {
                                GLOWS.remove(nearbyPlayer.getUniqueId());
                            }
                        }
                    }
                }
            }
        }
    }
}
