package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import lombok.Getter;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class LeaderEvent extends Event implements Cancellable
{
    private static final HandlerList HANDLERS = new HandlerList();

    @Override
    public HandlerList getHandlers()
    {
        return HANDLERS;
    }
    public static HandlerList getHandlerList()
    {
        return HANDLERS;
    }

    @Getter
    private final Leader leader;
    @Getter
    private final boolean added;
    private boolean cancel;

    public LeaderEvent(Leader leader, boolean added)
    {
        this.leader = leader;
        this.added = added;
        this.cancel = false;
    }

    public Origin getOrigin()
    {
        return HeavenRaces.getInstance().getRaceManager().getOrigin(leader.getLeaderId(), Origin.class);
    }

    public Race getRace()
    {
        Origin origin = getOrigin();
        if (origin == null)
        {
            return null;
        }

        return origin.getRace();
    }
    public Clan getClan()
    {
        Origin origin = getOrigin();
        if (origin == null)
        {
            return null;
        }

        if (!(origin instanceof Werewolf werewolf))
        {
            return null;
        }

        return werewolf.getClan();
    }

    @Override
    public boolean isCancelled()
    {
        return cancel;
    }
    @Override
    public void setCancelled(boolean cancel)
    {
        this.cancel = cancel;
    }
}
