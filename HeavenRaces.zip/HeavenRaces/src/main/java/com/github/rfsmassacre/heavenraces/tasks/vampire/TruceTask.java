package com.github.rfsmassacre.heavenraces.tasks.vampire;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.List;

public class TruceTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final RaceManager races;

    public TruceTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
    }

    public void run()
    {
        List<String> mobNames = this.config.getStringList("vampire.truce.mobs");
        for (Vampire vampire : races.getOrigins(Vampire.class))
        {
            Player player = vampire.getPlayer();
            if (player == null)
            {
                continue;
            }

            int ticks = vampire.getTruceTicks();
            int interval = this.config.getInt("vampire.truce.interval");
            if (ticks <= 0)
            {
                continue;
            }

            vampire.subtractTruceTicks(interval);
            if (vampire.getTruceTicks() > 0)
            {
                continue;
            }

            locale.sendLocale(vampire.getPlayer(), true, "vampire.truce.fixed");
            for (Entity entity : player.getNearbyEntities(64.0, 16.0, 64.0))
            {
                if (!(entity instanceof Mob mob))
                {
                    continue;
                }

                String mobType = entity.getType().toString();
                if (mobNames.contains(mobType) && mob.getTarget() != null &&
                        mob.getTarget().equals(vampire.getPlayer()))
                {
                    mob.setTarget(null);
                }
            }
        }
    }
}