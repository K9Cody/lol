package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.players.Origin;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class ExperienceGainEvent extends Event implements Cancellable
{
    private static final HandlerList HANDLERS = new HandlerList();

    @Override
    public HandlerList getHandlers()
    {
        return HANDLERS;
    }
    public static HandlerList getHandlerList()
    {
        return HANDLERS;
    }

    @Getter
    private final Origin origin;
    @Getter
    @Setter
    private double xp;
    private boolean cancel;

    public ExperienceGainEvent(Origin origin, double xp)
    {
        this.origin = origin;
        this.xp = xp;
        this.cancel = false;
    }

    @Override
    public boolean isCancelled()
    {
        return cancel;
    }
    @Override
    public void setCancelled(boolean cancel)
    {
        this.cancel = cancel;
    }
}
