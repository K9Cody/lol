package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.CooldownEvent;
import com.github.rfsmassacre.heavenraces.events.SpellCastEvent;
import com.github.rfsmassacre.heavenraces.players.*;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitTask;
import org.reflections.Reflections;
import org.reflections.scanners.Scanners;

import java.lang.reflect.Modifier;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Getter
public abstract class Spell implements Listener
{
    private static final Map<Class<? extends Spell>, Spell> SPELLS = new HashMap<>();

    public static void loadSpells()
    {
        for (Spell spell : SPELLS.values())
        {
            if (spell instanceof BuffSpell buff)
            {
                buff.deactivateTimers();
            }

            HandlerList.unregisterAll(spell);
        }

        SPELLS.clear();
        Reflections reflections = new Reflections("com.github.rfsmassacre.heavenraces.spells", Scanners.SubTypes);
        Set<Class<? extends Spell>> spellClasses = reflections.getSubTypesOf(Spell.class);
        for (Class<? extends Spell> spellClass : spellClasses)
        {
            if (!Modifier.isAbstract(spellClass.getModifiers()))
            {
                try
                {
                    Spell spell = spellClass.getDeclaredConstructor().newInstance();
                    addSpell(spell);
                }
                catch (Exception ignored)
                {
                    //Do nothing
                }
            }
        }
    }

    public static <T extends Spell> T getSpell(Class<T> clazz)
    {
        Spell spell = SPELLS.get(clazz);
        if (clazz.isInstance(spell))
        {
            return clazz.cast(spell);
        }

        return null;
    }

    public static Spell getSpell(String internalName)
    {
        for (Spell spell : SPELLS.values())
        {
            if (spell.internalName.equals(internalName))
            {
                return spell;
            }
        }

        return null;
    }

    public static Set<Spell> getSpells()
    {
        return new HashSet<>(SPELLS.values());
    }

    public static void addSpell(Spell spell)
    {
        SPELLS.put(spell.getClass(), spell);
        Bukkit.getPluginManager().registerEvents(spell, HeavenRaces.getInstance());
    }

    protected final PaperConfiguration config;
    protected final PaperLocale locale;
    private final Set<BukkitTask> tasks;
    protected final Map<UUID, Long> cooldowns;

    @Getter
    protected final String internalName;
    @Getter
    protected final String displayName;
    @Getter
    protected final long cooldown;
    @Getter
    protected final Origin.Race race;
    @Getter
    protected final int level;
    @Getter
    protected final boolean beneficial;
    @Getter
    protected final int customModelId;
    @Getter
    protected String cooldownMessage;
    @Getter
    protected String itemMessage;
    @Getter
    protected String levelMessage;
    @Getter
    protected String raceMessage;

    protected final List<String> description;

    public Spell(String internalName)
    {
        this.config = HeavenRaces.getInstance().getConfiguration(HeavenRaces.ConfigType.SPELLS);
        this.locale = HeavenRaces.getInstance().getLocale();
        this.tasks = new HashSet<>();
        this.cooldowns = new HashMap<>();
        this.internalName = internalName;
        this.displayName = config.getString(internalName + ".display-name");
        this.cooldown = config.getInt(internalName + ".cooldown");
        this.race = Origin.Race.fromString(config.getString(internalName + ".race"));
        this.level = config.getInt(internalName + ".level");
        this.beneficial = config.getBoolean(internalName + ".beneficial");
        this.customModelId = config.getInt(internalName + ".custom-model-data");
        this.description = config.getStringList(internalName + ".description");
        this.cooldownMessage = config.getString(internalName + ".cooldown-message");
        if (cooldownMessage == null)
        {
            this.cooldownMessage = displayName + "&r &cis on cooldown!";
        }
        this.itemMessage = config.getString(internalName + ".no-item-message");
        if (itemMessage == null)
        {
            this.itemMessage = displayName + "&r &cis missing an item!";
        }
        this.levelMessage = config.getString(internalName  + ".level-message");
        if (levelMessage == null)
        {
            this.levelMessage = displayName + "&r &crequires you to be &eLVL " + level + "&c!";
        }
        this.raceMessage = config.getString(internalName + ".race-message");
        if (raceMessage == null)
        {
            this.raceMessage = displayName + "&r &cis a &e" + LocaleData.capitalize(race.toString()) + "&c ability!";
        }
    }

    protected <T extends Origin> T getOrigin(LivingEntity entity)
    {
        Class<? extends Origin> clazz = null;
        switch (race)
        {
            case HUMAN -> clazz = Human.class;
            case VAMPIRE -> clazz = Vampire.class;
            case WEREWOLF -> clazz = Werewolf.class;
            case ANGEL -> clazz = Angel.class;
            case DEMON -> clazz = Demon.class;
        }

        return HeavenRaces.getInstance().getRaceManager().getOrigin(entity.getUniqueId(), (Class<T>) clazz);
    }

    private String replaceValues(String input)
    {
        // Regular expression pattern for placeholder format {key}
        Pattern pattern = Pattern.compile("\\{([^}]+)}");
        Matcher matcher = pattern.matcher(input);
        StringBuilder result = new StringBuilder();
        while (matcher.find())
        {
            String key = matcher.group(1);
            if (key.equals("cooldown"))
            {
                matcher.appendReplacement(result, Integer.toString(config.getSection(internalName).getInt(key)
                        / 1000));
                continue;
            }
            else if (key.equals("duration") || key.equals("delay") || key.equals("animation"))
            {
                matcher.appendReplacement(result, String.format("%.1f", (double) config.getSection(internalName)
                        .getInt(key) / 20.0));
                continue;
            }

            Object value = config.getSection(internalName).get(key);
            String replacement = (value != null) ? value.toString() : matcher.group(0);
            matcher.appendReplacement(result, replacement);
        }

        matcher.appendTail(result);
        return result.toString();
    }

    public List<String> getDescription()
    {
        return description.stream()
                .map(LocaleData::format)
                .toList();
    }

    public abstract boolean activate(LivingEntity entity);

    public boolean canCast(LivingEntity entity)
    {
        Origin origin = getOrigin(entity);
        if (origin == null)
        {
            return false;
        }

        if (!origin.getRace().equals(race))
        {
            locale.sendActionMessage(origin.getPlayer(), raceMessage);
            return false;
        }

        if (origin.getLevel() < level)
        {
            locale.sendActionMessage(origin.getPlayer(), levelMessage);
            return false;
        }

        return true;
    }

    public void cast(LivingEntity entity)
    {
        if (!canCast(entity))
        {
            return;
        }

        long cooldown = cooldowns.getOrDefault(entity.getUniqueId(), 0L);
        if (System.currentTimeMillis() - cooldown > this.cooldown)
        {
            SpellCastEvent event = new SpellCastEvent(entity, this);
            Bukkit.getPluginManager().callEvent(event);
            if (!event.isCancelled())
            {
                if (activate(entity))
                {
                    cooldowns.put(entity.getUniqueId(), System.currentTimeMillis());
                    CooldownEvent cooldownEvent = new CooldownEvent(entity, this);
                    Bukkit.getPluginManager().callEvent(cooldownEvent);
                }
            }
        }
        else if (entity instanceof Player player)
        {
            locale.sendActionLocale(player, false, "spells.cooldown", "{spell}", displayName,
                    "{cooldown}", LocaleData.formatTime((double) getCooldown(player) / 1000.0));
        }
    }

    public long getCooldown(LivingEntity entity)
    {
        return Math.max(0L, this.cooldown - (System.currentTimeMillis() - cooldowns.getOrDefault(entity.getUniqueId(),
                0L)));
    }
}
