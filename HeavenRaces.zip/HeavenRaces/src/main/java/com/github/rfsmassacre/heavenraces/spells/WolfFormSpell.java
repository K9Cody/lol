package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenraces.events.CooldownEvent;
import com.github.rfsmassacre.heavenraces.events.SpellCastEvent;
import com.github.rfsmassacre.heavenraces.events.WerewolfFormEvent;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.utils.StringUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class WolfFormSpell extends Spell
{
    public WolfFormSpell()
    {
        super("wolf-form");
    }

    public void cast(LivingEntity entity)
    {
        if (!canCast(entity))
        {
            return;
        }

        long cooldown = cooldowns.getOrDefault(entity.getUniqueId(), 0L);
        if (System.currentTimeMillis() - cooldown > this.cooldown)
        {
            SpellCastEvent event = new SpellCastEvent(entity, this);
            Bukkit.getPluginManager().callEvent(event);
            if (!event.isCancelled())
            {
                Werewolf werewolf = getOrigin(entity);
                if (!werewolf.isWolfForm() && werewolf.getFatigueTime() > 0)
                {
                    locale.sendActionLocale(werewolf.getPlayer(), false, "spells.cooldown", "{spell}",
                            displayName, "{cooldown}", LocaleData.formatTime((double) werewolf.getFatigueTime() /
                                    20.0));
                    return;
                }

                if (activate(entity))
                {
                    cooldowns.put(entity.getUniqueId(), System.currentTimeMillis());
                    CooldownEvent cooldownEvent = new CooldownEvent(entity, this);
                    Bukkit.getPluginManager().callEvent(cooldownEvent);
                }
            }
        }
        else if (entity instanceof Player player)
        {
            locale.sendActionLocale(player, false, "spells.cooldown", "{spell}", displayName,
                    "{cooldown}", LocaleData.formatTime((double) getCooldown(player) / 1000.0));
        }
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        Werewolf werewolf = getOrigin(entity);
        Player player = werewolf.getPlayer();
        if (werewolf.isWolfForm())
        {
            WerewolfFormEvent event = new WerewolfFormEvent(werewolf, false);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                locale.sendLocale(player, true, "werewolf.wolf-form.cant-toggle");
                return false;
            }
        }
        else
        {
            if (werewolf.getLevel() < level)
            {
                locale.sendLocale(player, true, "level-reward.not-level", "{level}",
                        Integer.toString(level), "{ability}", "Wolf Form");
                return false;
            }

            if (werewolf.getFatigueTime() > 0 && !player.hasPermission("heavenraces.override.transform"))
            {
                locale.sendLocale(player, true, "werewolf.wolf-form.fatigue", "{time}",
                        StringUtil.formatTime(werewolf.getFatigueTime() / 20));
                return false;
            }

            WerewolfFormEvent event = new WerewolfFormEvent(werewolf, true);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                locale.sendLocale(player, true, "werewolf.wolf-form.cant-toggle");
                return false;
            }
        }

        return true;
    }
}
