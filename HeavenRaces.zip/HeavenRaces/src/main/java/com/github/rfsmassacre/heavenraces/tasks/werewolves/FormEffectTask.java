package com.github.rfsmassacre.heavenraces.tasks.werewolves;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.utils.ConfigUtil;
import com.github.rfsmassacre.heavenraces.utils.PotionEffectUtil;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Set;

public class FormEffectTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final RaceManager races;

    private final Set<PotionEffect> witherfangForm;
    private final Set<PotionEffect> silvermaneForm;
    private final Set<PotionEffect> bloodmoonForm;

    private final Set<PotionEffect> witherfangHuman;
    private final Set<PotionEffect> silvermaneHuman;
    private final Set<PotionEffect> bloodmoonHuman;

    public FormEffectTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();

        this.witherfangForm = ConfigUtil.getPotionEffects(config, "werewolf.wolf-effects.witherfang");
        this.silvermaneForm = ConfigUtil.getPotionEffects(config, "werewolf.wolf-effects.silvermane");
        this.bloodmoonForm = ConfigUtil.getPotionEffects(config, "werewolf.wolf-effects.bloodmoon");

        this.witherfangHuman = ConfigUtil.getPotionEffects(config, "werewolf.human-effects.witherfang");
        this.silvermaneHuman = ConfigUtil.getPotionEffects(config, "werewolf.human-effects.silvermane");
        this.bloodmoonHuman = ConfigUtil.getPotionEffects(config, "werewolf.human-effects.bloodmoon");
    }

    @Override
    public void run()
    {
        for (Werewolf werewolf : races.getOrigins(Werewolf.class))
        {
            Player player = werewolf.getPlayer();
            if (player == null)
            {
                continue;
            }

            Clan clan = werewolf.getClan();
            int level = config.getInt("level-reward.werewolf.human-passives");
            Talent amplify = werewolf.getTalent("Amplify");
            int power = 0;
            if (amplify != null)
            {
                power = amplify.getInt("amplify");
            }

            if (werewolf.isWolfForm())
            {
                switch (clan)
                {
                    case WITHERFANG ->
                    {
                        for (PotionEffect effect : witherfangForm)
                        {
                            int amount = effect.getAmplifier() + power;
                            player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(),
                                    amount));
                        }
                    }
                    case SILVERMANE ->
                    {
                        for (PotionEffect effect : silvermaneForm)
                        {
                            int amount = effect.getAmplifier() + power;
                            player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(),
                                    amount));
                        }
                    }
                    case BLOODMOON ->
                    {
                        PotionEffectUtil.addPotionEffects(player, bloodmoonForm);
                        for (PotionEffect effect : bloodmoonForm)
                        {
                            int amount = effect.getAmplifier() + power;
                            player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(),
                                    amount));
                        }
                    }
                }
            }
            else if (werewolf.getLevel() >= level)
            {
                switch (clan)
                {
                    case WITHERFANG ->
                    {
                        for (PotionEffect effect : witherfangHuman)
                        {
                            int amount = effect.getAmplifier() + power;
                            player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(),
                                    amount));
                        }
                    }
                    case SILVERMANE ->
                    {
                        for (PotionEffect effect : silvermaneHuman)
                        {
                            int amount = effect.getAmplifier() + power;
                            player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(),
                                    amount));
                        }
                    }
                    case BLOODMOON ->
                    {
                        for (PotionEffect effect : bloodmoonHuman)
                        {
                            int amount = effect.getAmplifier() + power;
                            player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(),
                                    amount));
                        }
                    }
                }
            }
        }
    }
}
