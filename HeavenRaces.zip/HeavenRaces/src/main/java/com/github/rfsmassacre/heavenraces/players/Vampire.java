package com.github.rfsmassacre.heavenraces.players;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

@Getter
@Setter
public class Vampire extends Origin
{
    private boolean bloodLust;
    private boolean batForm;
    private int truceTicks;
    private double temperature;
    private int fatigue;
    private int negatedTicks;
    private boolean nightVision;
    private boolean jumpBoost;
    private long satiatedTime;

    public Vampire()
    {
        super();

        this.race = Race.VAMPIRE;
        this.bloodLust = false;
        this.batForm = false;
        this.truceTicks = 0;
        this.temperature = 0;
        this.fatigue = 0;
        this.negatedTicks = 0;
        this.satiatedTime = 0;
        this.nightVision = true;
        this.jumpBoost = true;
    }

    public Vampire(Player player)
    {
        super(player, Race.VAMPIRE);

        this.bloodLust = false;
        this.batForm = false;
        this.truceTicks = 0;
        this.temperature = 0;
        this.fatigue = 0;
        this.negatedTicks = 0;
        this.satiatedTime = 0;
        this.nightVision = true;
        this.jumpBoost = true;
        updateStats();
    }
    public Vampire(Origin origin)
    {
        super(origin);

        this.race = Race.VAMPIRE;
        this.bloodLust = false;
        this.batForm = false;
        this.truceTicks = 0;
        this.temperature = 0;
        this.fatigue = 0;
        this.negatedTicks = 0;
        this.satiatedTime = 0;
        this.nightVision = true;
        this.jumpBoost = true;
        updateStats();
    }

    public void updateStats()
    {
        String key = "passives";
        if (bloodLust)
        {
            key = "blood-lust";
        }
        else if (batForm)
        {
            key = "bat-form";
        }

        updateStats(key);
    }

    /*
     * GETTERS/SETTERS
     */
    public boolean inBloodLust()
    {
        return bloodLust;
    }

    public boolean inBatForm()
    {
        return batForm;
    }

    public void setTruceTicks(int truceTicks)
    {
        this.truceTicks = Math.max(0, truceTicks);
    }
    public void subtractTruceTicks(int truceTicks)
    {
        setTruceTicks(this.truceTicks - truceTicks);
    }

    public void setTemperature(double temperature)
    {
        this.temperature = Math.max(0.0, Math.min(temperature, 1.0));
    }

    public void addTemperature(double temperature)
    {
        setTemperature(this.temperature + temperature);
    }

    public void setFatigue(int fatigue)
    {
        this.fatigue = Math.max(0, fatigue);
    }

    public void addFatigue(int fatigue)
    {
        setFatigue(this.fatigue + fatigue);
    }

    /*
     * To String
     */
    @Override
    public String toString()
    {
        String info = " ";
        info += "\n\n&7" + playerId.toString();
        info += "\n&d" + getRace().toString();
        info += "\n&f" + displayName;
        info += "\n&d" + "TEMP: " + temperature;
        info += "\n&d" + "TRUCE " + truceTicks;
        info += "\n&d" + "NEGATED " + negatedTicks;
        info += "\n&d" + "BAT: " + batForm;
        info += "\n&d" + "LUST: " + bloodLust + "\n ";
        return info;
    }
}
