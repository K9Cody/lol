package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.managers.TextManager;
import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.ExperienceGainEvent;
import com.github.rfsmassacre.heavenraces.events.LevelUpEvent;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.MoonManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import com.github.rfsmassacre.heavenraces.spells.WolfFormSpell;
import com.github.rfsmassacre.heavenraces.utils.FXUtil;
import com.google.common.collect.Lists;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.*;

public class WerewolfCommand extends PaperCommand
{
    private final HeavenRaces instance;
    private final PaperConfiguration config;
    private final TextManager text;
    private final RaceManager races;
    private final LeaderManager leaders;
    private final MoonManager moons;

    private final Map<UUID, Long> howlers;
    private final Map<UUID, Long> growlers;

    public WerewolfCommand()
    {
        super(HeavenRaces.getInstance(), "werewolf");

        this.instance = HeavenRaces.getInstance();
        this.config = instance.getConfiguration();
        this.text = instance.getTextManager();
        this.races = instance.getRaceManager();
        this.leaders = instance.getLeaderManager();
        this.moons = instance.getMoonManager();

        this.howlers = new HashMap<>();
        this.growlers = new HashMap<>();
    }

    /*
     * Werewolf main command
     */
    private class InfoCommand extends PaperSubCommand
    {
        public InfoCommand()
        {
            super("info", "heavenraces.werewolf.info");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
            if (werewolf == null)
            {
                locale.sendLocale(player, true, "invalid.not-werewolf");
                return;
            }

            locale.sendMessage(player, RaceCommand.getMenu(werewolf));
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Wolf Form
     */
    private class WolfFormCommand extends PaperSubCommand
    {
        public WolfFormCommand()
        {
            super("transform", "heavenraces.werewolf.transform");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
            if (werewolf == null)
            {
                locale.sendLocale(player, true, "werewolf.wolf-form.not-werewolf");
                return;
            }

            WolfFormSpell spell = (WolfFormSpell) Spell.getSpell("wolf-form");
            if (spell != null)
            {
                spell.cast(player);
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Scent tracking
     */
    private class ScentCommand extends PaperSubCommand
    {
        public ScentCommand()
        {
            super("scent", "heavenraces.werewolf.scent");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
            if (werewolf == null)
            {
                locale.sendLocale(player, true, "werewolf.wolf-form.not-werewolf");
                return;
            }

            if (werewolf.isTracking())
            {
                werewolf.setTracking(false);
                locale.sendLocale(player, true, "werewolf.scent.disabled");
            }
            else
            {
                int level = config.getInt("level-reward.werewolf.scent");
                if (werewolf.getLevel() < level)
                {
                    locale.sendLocale(player, true, "level-reward.not-level", "{level}",
                            Integer.toString(level), "{ability}", "Scent Tracking");
                    return;
                }

                werewolf.setTracking(true);
                locale.sendLocale(player, true, "werewolf.scent.enabled");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Werewolves can howl and growl
     */
    private class HowlCommand extends PaperSubCommand
    {
        public HowlCommand()
        {
            super("howl", "heavenraces.werewolf.howl");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
            if (werewolf != null)
            {
                if (!werewolf.isWolfForm())
                {
                    locale.sendLocale(player, true, "werewolf.not-in-form");
                    return;
                }

                Moon moon = moons.getMoon(player.getWorld());
                long cooldown = config.getInt("werewolf.cooldown.howl");
                double power = 0.0;
                if (moon != null)
                {
                    Moon.MoonPhase phase = moon.getCurrentPhase();
                    if (phase != null)
                    {
                        cooldown = config.getInt("werewolf.cooldown.moon");
                        power = phase.getPower();
                    }
                }

                long lastHowl = howlers.getOrDefault(player.getUniqueId(), 0L);
                long timeElapsed = System.currentTimeMillis() - lastHowl;
                long remaining = Math.max(0L, cooldown - timeElapsed);
                if (remaining == 0L)
                {
                    FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_HOWL);
                    howlers.put(player.getUniqueId(), System.currentTimeMillis());
                    double xp = config.getDouble("xp.werewolf.howl") * power;
                    ExperienceGainEvent xpEvent = new ExperienceGainEvent(werewolf, xp);
                    Bukkit.getPluginManager().callEvent(xpEvent);
                    if (!xpEvent.isCancelled())
                    {
                        if (xp > 0)
                        {
                            int oldLevel = (int) werewolf.getLevel();
                            werewolf.addLevel(xpEvent.getXp());
                            int newLevel = (int) werewolf.getLevel();
                            if (newLevel > oldLevel)
                            {
                                LevelUpEvent levelEvent = new LevelUpEvent(werewolf, newLevel);
                                Bukkit.getPluginManager().callEvent(levelEvent);
                            }

                            locale.sendLocale(player, "werewolf.howl.xp", "{xp}",
                                    String.format("%.2f", xp), "{total}", String.format("%.2f", werewolf.getLevel()));
                        }
                        else
                        {
                            locale.sendLocale(player, true, "werewolf.howl.activate");
                        }
                    }
                }
                else
                {
                    locale.sendLocale(player, "werewolf.howl.cooldown", "{time}",
                            LocaleData.formatTime(remaining / 1000.0));
                }
            }
            else
            {
                locale.sendLocale(player, true, "invalid.not-werewolf");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] strings)
        {
            return Collections.emptyList();
        }
    }

    private class GrowlCommand extends PaperSubCommand
    {
        public GrowlCommand()
        {
            super("growl", "heavenraces.werewolf.growl");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
            if (werewolf != null)
            {
                if (!werewolf.isWolfForm())
                {
                    locale.sendLocale(player, true, "werewolf.not-in-form");
                    return;
                }

                long cooldown = config.getInt("werewolf.cooldown.growl");
                long lastGrowl = growlers.getOrDefault(player.getUniqueId(), 0L);
                long timeElapsed = System.currentTimeMillis() - lastGrowl;
                long remaining = Math.max(0L, cooldown - timeElapsed);
                if (remaining == 0L)
                {
                    FXUtil.playSound(player.getLocation(), Sound.ENTITY_WOLF_GROWL);
                    locale.sendLocale(player, true, "werewolf.growl.activate");
                    growlers.put(player.getUniqueId(), System.currentTimeMillis());
                }
                else
                {
                    locale.sendLocale(player, "werewolf.growl.cooldown", "{time}",
                            LocaleData.formatTime(remaining / 1000.0));
                }
            }
            else
            {
                locale.sendLocale(player, true, "invalid.not-werewolf");
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] strings)
        {
            return Collections.emptyList();
        }
    }

    private class ListCommand extends PaperSubCommand
    {
        public ListCommand()
        {
            super("list", "heavenraces.werewolf.list");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            int pageNumber = 1;
            if (args.length > 1)
            {
                try
                {
                    pageNumber = Integer.parseInt(args[1]);
                }
                catch (NumberFormatException exception)
                {
                    //Do nothing
                }
            }

            final int finalPageNumber = pageNumber;
            Werewolf werewolf = races.getOrigin(player.getUniqueId(), Werewolf.class);
            if (werewolf == null)
            {
                locale.sendLocale(player, true, "invalid.not-werewolf");
                return;
            }

            locale.sendLocale(player, true, "admin.request");
            races.getAllOrigins(Werewolf.class, (werewolfSet) ->
            {
                Set<Werewolf> clanWerewolves = new HashSet<>();
                for (Werewolf other : werewolfSet)
                {
                    if (other.getClan().equals(werewolf.getClan()))
                    {
                        clanWerewolves.add(other);
                    }
                }

                List<Werewolf> werewolves = new ArrayList<>(clanWerewolves);
                werewolves.sort(Comparator.reverseOrder());
                List<List<Werewolf>> pages = Lists.partition(werewolves, 6);
                int pageMax = pages.size();
                int page = finalPageNumber;
                if (page < 1)
                {
                    page = 1;
                }
                if (page > pageMax)
                {
                    page = pageMax;
                }

                String leaderName = "&7N/A";
                Leader leader = leaders.getLeader(werewolf.getClan());
                if (leader != null)
                {
                    Werewolf alpha = races.getOrigin(leader.getLeaderId(), Werewolf.class);
                    if (alpha == null)
                    {
                        alpha = races.loadOrigin(leader.getLeaderId(), Werewolf.class);
                    }
                    if (alpha != null)
                    {
                        leaderName = alpha.getDisplayName();
                    }
                }

                if (leaderName == null)
                {
                    leaderName = "&7N/A";
                }

                List<String> lines = text.getText("list.txt");
                String menu = String.join("\n", lines);
                menu = menu.replace("{race}", "&6&lWerewolves&r");
                menu = menu.replace("{page}", Integer.toString(page));
                menu = menu.replace("{pageMax}", Integer.toString(pageMax));

                String clan = LocaleData.capitalize(werewolf.getClan().toString());

                menu = menu.replace("{leaderTitle}", "&6&l" + clan + " Alpha");
                menu = menu.replace("{leader}", leaderName);

                List<Werewolf> topWerewolves = pages.get(page - 1);
                List<String> infoList = new ArrayList<>();
                for (Werewolf top : topWerewolves)
                {
                    String line = " &b#";
                    for (int place = 0; place < werewolves.size(); place++)
                    {
                        Werewolf runner = werewolves.get(place);
                        if (runner.getPlayerId().equals(top.getPlayerId()))
                        {
                            line += place + 1;
                            break;
                        }
                    }

                    line += " &f" + top.getDisplayName() + " &6(&eLVL " + String.format("%.2f", top.getLevel()) + "&6)";
                    infoList.add(line);
                }

                if (infoList.size() < 6)
                {
                    for (int remaining = 6 - infoList.size(); remaining > 0; remaining--)
                    {
                        infoList.add("&f");
                    }
                }

                String info = String.join("\n", infoList);
                menu = menu.replace("{players}", info);
                locale.sendMessage(player, menu);
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Werewolf help command
     */
    private class HelpCommand extends PaperSubCommand
    {
        public HelpCommand()
        {
            super("help", "heavenraces.werewolf.help");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            List<String> lines = text.getText("werewolf-help1.txt");
            String menu = String.join("\n", lines);
            locale.sendMessage(sender, menu);
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }
}
