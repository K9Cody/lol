package com.github.rfsmassacre.heavenraces.listeners;

import com.destroystokyo.paper.event.player.PlayerStopSpectatingEntityEvent;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.PhaseFormEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Demon;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DemonListener implements Listener
{
    private final PaperConfiguration config;
    private final RaceManager races;
    private final Map<UUID, Long> lastTransform;

    public DemonListener()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.lastTransform = new HashMap<>();
    }

    @EventHandler(ignoreCancelled = true)
    public void onDemonFly(PlayerToggleFlightEvent event)
    {
        Player player = event.getPlayer();
        Demon demon = races.getOrigin(player.getUniqueId(), Demon.class);
        if (demon == null)
        {
            return;
        }

        if (demon.isSpiritForm())
        {
            if (event.isFlying())
            {
                event.setCancelled(true);
            }

            PhaseFormEvent formEvent;
            if (!demon.isPhaseForm())
            {
                formEvent = new PhaseFormEvent(demon, true);
            }
            else
            {
                formEvent = new PhaseFormEvent(demon, false);
            }

            Bukkit.getPluginManager().callEvent(formEvent);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPhaseTransform(PhaseFormEvent event)
    {
        Demon demon = event.getDemon();
        if (!demon.isSpiritForm())
        {
            return;
        }

        Player player = demon.getPlayer();
        long lastToggle = lastTransform.getOrDefault(player.getUniqueId(), 0L);
        if (event.isToggled())
        {
            long cooldown = config.getInt("demon.phase-form.cooldown");
            if (System.currentTimeMillis() - lastToggle <= cooldown)
            {
                event.setCancelled(true);
                return;
            }

            demon.setPhaseForm(true);
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, PotionEffect.INFINITE_DURATION,
                    0));
        }
        else
        {
            if (demon.getPossessedId() != null && player.getSpectatorTarget() instanceof LivingEntity victim &&
                    victim.getUniqueId().equals(demon.getPossessedId()))
            {
                victim.removePotionEffect(PotionEffectType.WITHER);
                BossBarUtil.removeBossBar("demon.possession.target", victim.getUniqueId());
            }

            lastTransform.put(player.getUniqueId(), System.currentTimeMillis());
            demon.setPossessedId(null);
            demon.setPhaseForm(false);
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
            if (player.getGameMode().equals(GameMode.SPECTATOR))
            {
                player.setGameMode(GameMode.SURVIVAL);
                player.setAllowFlight(true);
            }
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onPhaseDamage(EntityDamageEvent event)
    {
        if (!(event.getEntity() instanceof Player player))
        {
            return;
        }

        Demon demon = races.getOrigin(player.getUniqueId(), Demon.class);
        if (demon == null)
        {
            return;
        }

        if (demon.isPhaseForm())
        {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPhasePossession(PlayerStopSpectatingEntityEvent event)
    {
        Player player = event.getPlayer();
        Demon demon = races.getOrigin(player.getUniqueId(), Demon.class);
        if (demon == null)
        {
            return;
        }

        if (demon.isPhaseForm())
        {
            if (demon.getPossessedId() != null && event.getSpectatorTarget() instanceof LivingEntity victim &&
                    victim.getUniqueId().equals(demon.getPossessedId()))
            {
                victim.removePotionEffect(PotionEffectType.WITHER);
                BossBarUtil.removeBossBar("demon.possession.target", victim.getUniqueId());
            }

            PhaseFormEvent formEvent = new PhaseFormEvent(demon, false);
            Bukkit.getPluginManager().callEvent(formEvent);
            if (formEvent.isCancelled())
            {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onPowerPossess(EntityDamageByEntityEvent event)
    {
        if (!(event.getDamager() instanceof LivingEntity damager))
        {
            return;
        }

        double multiplier = config.getDouble("demon.power-multiplier");
        for (Demon demon : races.getOrigins(Demon.class))
        {
            if (!demon.isOnline() && demon.isPhaseForm() && demon.getPossessedId().equals(damager.getUniqueId()))
            {
                event.setDamage(event.getDamage() * multiplier);
                return;
            }
        }

    }

    @EventHandler
    public void onPossessedDeath(EntityDeathEvent event)
    {
        LivingEntity entity = event.getEntity();
        BossBarUtil.removeBossBar("demon.entering.self", entity.getUniqueId());
        BossBarUtil.removeBossBar("demon.possession.self", entity.getUniqueId());
        BossBarUtil.removeBossBar("demon.entering.target", entity.getUniqueId());
        BossBarUtil.removeBossBar("demon.possession.target", entity.getUniqueId());
    }
}
