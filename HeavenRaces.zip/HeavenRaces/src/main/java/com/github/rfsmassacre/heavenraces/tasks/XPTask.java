package com.github.rfsmassacre.heavenraces.tasks;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.ExperienceGainEvent;
import com.github.rfsmassacre.heavenraces.events.LevelUpEvent;
import com.github.rfsmassacre.heavenraces.managers.MoonManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.moons.Moon;
import com.github.rfsmassacre.heavenraces.moons.Moon.MoonPhase;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.utils.SunUtil;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class XPTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final RaceManager races;
    private final MoonManager moons;

    public XPTask()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
        this.moons = HeavenRaces.getInstance().getMoonManager();
    }

    @Override
    public void run()
    {
        for (Origin origin : races.getOrigins(Origin.class))
        {
            Player player = origin.getPlayer();
            if (player == null)
            {
                continue;
            }

            double passive = config.getDouble("xp." + origin.getRace().toString().toLowerCase() + ".passive");
            if (origin instanceof Vampire vampire)
            {
                ExperienceGainEvent event = new ExperienceGainEvent(vampire, passive);
                Bukkit.getPluginManager().callEvent(event);
                if (!event.isCancelled())
                {
                    int oldLevel = (int) vampire.getLevel();
                    vampire.addLevel(event.getXp());
                    int newLevel = (int) vampire.getLevel();
                    if (newLevel > oldLevel)
                    {
                        LevelUpEvent levelEvent = new LevelUpEvent(vampire, newLevel);
                        Bukkit.getPluginManager().callEvent(levelEvent);
                    }
                }
            }
            else if (origin instanceof Werewolf werewolf)
            {
                Moon moon = moons.getMoon(player.getWorld());
                if (moon == null || !MoonPhase.FULL_MOON.equals(moon.getCurrentPhase()))
                {
                    continue;
                }

                Block block = player.getLocation().getBlock().getRelative(BlockFace.UP);
                double terrain = SunUtil.getTerrainOpacity(block);
                if (terrain < 1.0 && werewolf.isWolfForm())
                {
                    ExperienceGainEvent event = new ExperienceGainEvent(werewolf, passive);
                    Bukkit.getPluginManager().callEvent(event);
                    if (!event.isCancelled())
                    {
                        int oldLevel = (int) werewolf.getLevel();
                        werewolf.addLevel(event.getXp());
                        int newLevel = (int) werewolf.getLevel();
                        if (newLevel > oldLevel)
                        {
                            LevelUpEvent levelEvent = new LevelUpEvent(werewolf, newLevel);
                            Bukkit.getPluginManager().callEvent(levelEvent);
                        }
                    }
                }
            }
        }
    }
}
