package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.paper.commands.SimplePaperCommand;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Menu;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.gui.menus.TalentMenu;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TalentCommand extends SimplePaperCommand
{
    private final RaceManager races;

    public TalentCommand()
    {
        super(HeavenRaces.getInstance(), "talent");

        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @Override
    protected void onRun(CommandSender sender, String[] args)
    {
        if (!(sender instanceof Player player))
        {
            locale.sendLocale(sender, true, "invalid.console");
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        Menu menu = new TalentMenu(origin, 1);
        player.openInventory(menu.createInventory(player));
        Menu.addView(player.getUniqueId(), menu);
    }
}
