package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.commands.SimplePaperCommand;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnCommand extends SimplePaperCommand
{
    private final RaceManager races;

    public SpawnCommand()
    {
        super(HeavenRaces.getInstance(), "spawn");

        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @Override
    protected void onRun(CommandSender sender, String... args)
    {
        if (!(sender instanceof Player player))
        {
            onConsole(sender);
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        Origin.Race race = origin.getRace();
        Location spawn = races.getSpawn(race);
        if (spawn == null)
        {
            locale.sendLocale(player, "race-spawn.not-set", "{race}",
                    LocaleData.capitalize(race.toString()));
            playSound(player, SoundKey.INCOMPLETE);
            return;
        }

        player.teleport(spawn);
    }
}
