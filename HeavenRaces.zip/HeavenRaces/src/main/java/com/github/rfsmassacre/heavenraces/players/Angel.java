package com.github.rfsmassacre.heavenraces.players;

import org.bukkit.entity.Player;

public class Angel extends Spirit
{
    public Angel()
    {
        super();

        this.race = Race.ANGEL;
    }

    @Override
    public void updateStats()
    {
        clearStats();
    }

    public Angel(Player player, Rank rank)
    {
        super(player, Race.ANGEL, rank);
    }

    public Angel(Origin origin, Rank rank)
    {
        super(origin, Race.ANGEL, rank);
    }
}
