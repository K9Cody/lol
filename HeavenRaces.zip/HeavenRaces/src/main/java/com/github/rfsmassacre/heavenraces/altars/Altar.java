/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 */
package com.github.rfsmassacre.heavenraces.altars;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.*;

public abstract class Altar
{
    protected PaperConfiguration config;
    protected PaperLocale locale;
    protected RaceManager races;
    protected String name;
    protected String description;
    @Getter
    protected Material core;
    protected HashMap<Material, Integer> materials;
    @Getter
    protected HashMap<Material, Integer> resources;

    public Altar(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.locale = instance.getLocale();
        this.races = instance.getRaceManager();
        this.materials = new HashMap<>();
        this.resources = new HashMap<>();
    }

    public HashMap<Material, Integer> getMissingMaterialsCount(HashMap<Material, Integer> givenMaterials)
    {
        HashMap<Material, Integer> missingMaterials = new HashMap<>();
        for (Map.Entry<Material, Integer> entry : this.materials.entrySet())
        {
            int missing;
            Integer found = givenMaterials.get(entry.getKey());
            if (found == null)
            {
                found = 0;
            }
            if ((missing = entry.getValue() - found) < 0)
            {
                missing = 0;
            }
            missingMaterials.put(entry.getKey(), missing);
        }
        return missingMaterials;
    }

    public static HashMap<Material, Integer> getMaterialCount(Collection<Block> blocks, Set<Material> materialsToCount)
    {
        HashMap<Material, Integer> materials = new HashMap<>();
        for (Block block : blocks)
        {
            Material material = block.getType();
            if (!materialsToCount.contains(material))
            {
                continue;
            }
            if (!materials.containsKey(material))
            {
                materials.put(material, 1);
                continue;
            }
            materials.put(material, materials.get(material) + 1);
        }
        return materials;
    }

    public static ArrayList<Block> getCubedBlocks(Block center, int radius)
    {
        ArrayList<Block> blocks = new ArrayList<>();
        for (int y = -radius; y <= radius; ++y)
        {
            for (int z = -radius; z <= radius; ++z)
            {
                for (int x = -radius; x <= radius; ++x)
                {
                    blocks.add(center.getRelative(x, y, z));
                }
            }
        }
        return blocks;
    }

    public static boolean playerHasResources(Player player, Map<Material, Integer> items)
    {
        PlayerInventory inventory = player.getInventory();
        for (Material material : items.keySet())
        {
            int count = 0;
            for (ItemStack item : inventory.all(material).values())
            {
                count += item.getAmount();
            }
            if (count >= items.get(material))
            {
                continue;
            }
            return false;
        }
        return true;
    }

    public static boolean playerHasResources(Player player, Collection<ItemStack> items)
    {
        PlayerInventory inventory = player.getInventory();
        for (ItemStack item : items)
        {
            int count = 0;
            for (ItemStack invItem : inventory.all(item.getType()).values())
            {
                count += invItem.getAmount();
            }
            if (count >= item.getAmount())
            {
                continue;
            }
            return false;
        }
        return true;
    }

    public static void playerResourceUse(Player player, Map<Material, Integer> items)
    {
        PlayerInventory inventory = player.getInventory();
        for (Map.Entry<Material, Integer> entry : items.entrySet())
        {
            inventory.removeItem(new ItemStack(entry.getKey(), entry.getValue()));
        }
        player.updateInventory();
    }

    public static void playerResourceUse(Player player, Collection<ItemStack> items)
    {
        PlayerInventory inventory = player.getInventory();
        for (ItemStack item : items)
        {
            inventory.removeItem(item);
        }
        player.updateInventory();
    }

    public abstract void use(Origin origin);

    public static String convertToString(Map<Material, Integer> map)
    {
        ArrayList<String> strings = new ArrayList<>();
        for (Map.Entry<Material, Integer> entry : map.entrySet())
        {
            strings.add(entry.getValue() + " " + LocaleData.capitalize(entry.getKey().toString()));
        }
        return String.join(", ", strings);
    }

    public static String convertToString(Collection<ItemStack> items)
    {
        ArrayList<String> strings = new ArrayList<>();
        for (ItemStack item : items)
        {
            strings.add(item.getAmount() + " " + LocaleData.capitalize(item.getType().toString()));
        }
        return String.join(", ", strings);
    }
}

