package com.github.rfsmassacre.heavenraces.listeners;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Menu;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.SpiritFormEvent;
import com.github.rfsmassacre.heavenraces.events.VampireBatEvent;
import com.github.rfsmassacre.heavenraces.events.WerewolfFormEvent;
import com.github.rfsmassacre.heavenraces.gui.menus.RaceMenu;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.*;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.time.Instant;
import java.util.UUID;

public class PlayerListener implements Listener
{
    private final PaperConfiguration config;
    private final RaceManager races;

    public PlayerListener()
    {
        this.config = HeavenRaces.getInstance().getConfiguration();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    /*
     * LOAD/SAVE
     */
    @EventHandler(ignoreCancelled = true, priority = EventPriority.LOWEST)
    public void onPlayerJoin(PlayerJoinEvent event)
    {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        races.loadOrigin(playerId, (origin) ->
        {
            if (origin == null)
            {
                if (config.getBoolean("enable-race-menu"))
                {
                    Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
                    {
                        Menu menu = new RaceMenu();
                        Menu.addView(playerId, menu);
                        player.openInventory(menu.createInventory(player));
                    });

                    return;
                }
                else
                {
                    origin = new Human(player);
                    races.saveOrigin(origin, false);
                }
            }

            races.addOrigin(origin);
            final Origin finalOrigin = origin;
            Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
            {
                finalOrigin.updateStats();
                Vampire vampire = races.getOrigin(playerId, Vampire.class);
                if (vampire != null && vampire.inBatForm())
                {
                    VampireBatEvent batEvent = new VampireBatEvent(vampire, false);
                    Bukkit.getPluginManager().callEvent(batEvent);
                }

                Werewolf werewolf = races.getOrigin(playerId, Werewolf.class);
                if (werewolf != null && werewolf.isWolfForm())
                {
                    WerewolfFormEvent formEvent = new WerewolfFormEvent(werewolf, false);
                    Bukkit.getPluginManager().callEvent(formEvent);
                }

                Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), () ->
                {
                    Spirit spirit = races.getOrigin(playerId, Spirit.class);
                    if (spirit != null && spirit.isSpiritForm())
                    {
                        if (player.getWorld().getName().toLowerCase().contains("heaven"))
                        {
                            SpiritFormEvent formEvent = new SpiritFormEvent(spirit, true);
                            Bukkit.getPluginManager().callEvent(formEvent);
                        }
                        else
                        {
                            SpiritFormEvent formEvent = new SpiritFormEvent(spirit, false);
                            Bukkit.getPluginManager().callEvent(formEvent);
                        }
                    }

                    AttributeInstance maxHealth = player.getAttribute(Attribute.MAX_HEALTH);
                    if (maxHealth == null)
                    {
                        return;
                    }

                    double lastHealth = finalOrigin.getLastHealth() == 0.0 ? maxHealth.getValue() :
                            finalOrigin.getLastHealth();
                    player.setHealth(Math.min(lastHealth, maxHealth.getValue()));
                    player.setMaximumNoDamageTicks(10);
                }, 20L);
            });
        });
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event)
    {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        Origin origin = races.getOrigin(playerId, Origin.class);
        origin.setLastHealth(player.getHealth());
        origin.setLastLogin(Instant.now().toEpochMilli());
        races.saveOrigin(origin, true);
        races.removeOrigin(playerId);
    }

    @EventHandler
    public void onRaceMenuClose(InventoryCloseEvent event)
    {
        Player player = (Player) event.getPlayer();
        if (races.getOrigin(player.getUniqueId(), Origin.class) != null)
        {
            return;
        }

        if (player.getName().startsWith("."))
        {
            return;
        }

        RaceMenu raceMenu = new RaceMenu();
        RaceMenu.ClanMenu clanMenu = raceMenu.getClanMenu();
        RaceMenu.RankMenu angelRankMenu = raceMenu.getRankMenu(Race.ANGEL);
        RaceMenu.RankMenu demonRankMenu = raceMenu.getRankMenu(Race.DEMON);
        Component title = event.getView().title();
        if (!isMenu(clanMenu, title) && !isMenu(angelRankMenu, title) && !isMenu(demonRankMenu, title))
        {
            return;
        }

        Bukkit.getScheduler().runTaskLater(HeavenRaces.getInstance(), () ->
        {
            Menu.addView(player.getUniqueId(), raceMenu);
            player.openInventory(raceMenu.createInventory(player));
        }, 1L);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onMobSpawn(CreatureSpawnEvent event)
    {
        event.getEntity().setMaximumNoDamageTicks(10);
    }

    private boolean isMenu(Menu menu, Component title)
    {
        return menu.getTitle().equals(LegacyComponentSerializer.legacySection().serialize(title));
    }
}
