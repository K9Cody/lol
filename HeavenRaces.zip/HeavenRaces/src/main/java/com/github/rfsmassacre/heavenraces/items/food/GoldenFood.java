package com.github.rfsmassacre.heavenraces.items.food;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import com.github.rfsmassacre.heavenraces.utils.FoodUtil;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.FoodComponent;

@Getter
@Setter
public class GoldenFood extends RaceItem
{
    public static GoldenFood of(ItemStack item)
    {
        try
        {
            GoldenFood goldenFood = new GoldenFood(item.getType(), item.getAmount());
            if (goldenFood.equals(item))
            {
                return goldenFood;
            }
        }
        catch (Exception exception)
        {
            //Do nothing;
        }

        return null;
    }

    private int amount;

    public GoldenFood(Material material)
    {
        this(material, 1);
    }

    public GoldenFood(Material material, int amount)
    {
        super("Golden" + LocaleData.capitalize(material.toString()).replaceAll(" ",
                ""), material);

        this.amount = amount;
    }

    @Override
    public ItemStack getItemStack()
    {
        ItemMeta meta = item.getItemMeta();
        if (meta == null)
        {
            return item;
        }

        FoodComponent food = meta.getFood();
        meta.setCustomModelData(getCustomModelData());
        food.setCanAlwaysEat(true);
        food.setNutrition(FoodUtil.getFoodLevel(material));
        food.setSaturation(FoodUtil.getSaturationLevel(material) * 1.5F);
        meta.setFood(food);
        item.setItemMeta(meta);
        return item;
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapedRecipe recipe = new ShapedRecipe(key, getItemStack());
        recipe.shape("GGG", "GMG", "GGG");
        recipe.setIngredient('G', Material.GOLD_INGOT);
        recipe.setIngredient('M', getType());
        return recipe;
    }
}
