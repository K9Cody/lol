package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.managers.TextManager;
import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Human.Infection;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 * RACE COMMAND
 */
public class RaceCommand extends PaperCommand
{
    private static TextManager text;
    private final RaceManager races;

    public RaceCommand()
    {
        super(HeavenRaces.getInstance(), "race");

        HeavenRaces instance = HeavenRaces.getInstance();
        text = instance.getTextManager();
        this.races = instance.getRaceManager();
    }

    /*
     * Show proper race menu
     */
    private class MenuCommand extends PaperSubCommand
    {
        public MenuCommand()
        {
            super("menu");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
            if (origin == null)
            {
                return;
            }

            locale.sendMessage(player, getMenu(origin));
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    public static String getMenu(Origin origin)
    {
        Race race = origin.getRace();
        List<String> lines = text.getText(race.toString().toLowerCase() + ".txt");
        String menu = lines != null ? String.join("\n", lines) : "";
        menu = menu.replace("{level}", Integer.toString((int) origin.getLevel()));
        menu = menu.replace("{exp}", Integer.toString(origin.getLevelProgress()));
        switch (race)
        {
            case VAMPIRE ->
            {
                Vampire vampire = (Vampire) origin;
                double truce = vampire.getTruceTicks();
                String truceActive = "&aACTIVE";
                if (truce > 0)
                {
                    truceActive = "&7" + LocaleData.formatTime(truce / 20);
                }

                menu = menu.replace("{temperature}", Integer.toString((int)(vampire.getTemperature() * 100.0)));
                menu = menu.replace("{truce}", truceActive);
            }
            case WEREWOLF ->
            {
                Werewolf werewolf = (Werewolf) origin;
                menu = menu.replace("{clan}", LocaleData.capitalize(werewolf.getClan().toString()));
                menu = menu.replace("{transform}", LocaleData.capitalize(Boolean.toString(werewolf.isWolfForm())));

                String transformString = LocaleData.formatTime((double)werewolf.getTransformTime() / 20);
                String fatigueString = LocaleData.formatTime((double)werewolf.getFatigueTime() / 20);
                if (transformString.isEmpty())
                {
                    transformString = "&fN/A";
                }
                if (fatigueString.isEmpty())
                {
                    fatigueString = "&fN/A";
                }

                menu = menu.replace("{transform-time}", transformString);
                menu = menu.replace("{fatigue-time}", fatigueString);
            }
            case HUMAN ->
            {
                Human human = (Human) origin;
                Infection infection = human.getInfection();
                menu = menu.replace("{progress}", infection == null ? "&aHEALTHY" :
                        (int)infection.getProgress() + "%");
            }
        }

        return menu;
    }

    /*
     * Show current race
     */
    private class InfoCommand extends PaperSubCommand
    {
        public InfoCommand()
        {
            super("info");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (args.length <= 1)
            {
                if (sender instanceof Player player)
                {
                    Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
                    locale.sendMessage(player, getMenu(origin));
                }

                onConsole(sender);
            }
            else
            {
                //race info <player>
                String playerName = args[1];
                races.getOrLoadOrigin(playerName, Origin.class, (origin) ->
                {
                    if (origin == null)
                    {
                        locale.sendLocale(sender, true, "invalid.no-player", "{name}", playerName);
                        return;
                    }

                    locale.sendMessage(sender, getMenu(origin));
                });
            }
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 2)
            {
                for (Player player : Bukkit.getOnlinePlayers())
                {
                    suggestions.add(player.getName());
                }
            }

            return suggestions;
        }
    }
}
