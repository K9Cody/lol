package com.github.rfsmassacre.heavenraces.utils;

import java.util.Random;

public class RandomUtil
{
    public static boolean check(int chance)
    {
        Random random = new Random(System.currentTimeMillis());
        return random.nextInt(1, 100) <= chance;
    }

    public static boolean check(double chance)
    {
        Random random = new Random(System.currentTimeMillis());
        return random.nextDouble(0.0, 1.0) <= chance;
    }

    public static int nextInt(int max)
    {
        Random random = new Random(System.currentTimeMillis());
        return random.nextInt(1, max);
    }

    public static double nextDouble()
    {
        Random random = new Random(System.currentTimeMillis());
        return random.nextDouble();
    }

    public static boolean nextBoolean()
    {
        Random random = new Random(System.currentTimeMillis());
        return random.nextBoolean();
    }
}
