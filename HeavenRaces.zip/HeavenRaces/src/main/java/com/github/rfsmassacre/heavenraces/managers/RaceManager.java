package com.github.rfsmassacre.heavenraces.managers;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.data.OriginGsonManager;
import com.github.rfsmassacre.heavenraces.data.SpawnYamlStorage;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class RaceManager
{
    private final HeavenRaces instance;
    private final ConcurrentHashMap<UUID, Origin> origins;
    private final OriginGsonManager data;
    private final Map<Race, Location> spawns;
    private final SpawnYamlStorage storage;

    public RaceManager()
    {
        this.instance = HeavenRaces.getInstance();
        this.origins = new ConcurrentHashMap<>();
        this.data = new OriginGsonManager();
        this.spawns = new HashMap<>();
        this.storage = new SpawnYamlStorage();
    }

    /*
     * RACE GETTERS & SETTERS
     */
    public void addOrigin(Origin origin)
    {
        origins.put(origin.getPlayerId(), origin);
    }

    public void saveOrigin(Origin origin, boolean async)
    {
        if (async)
        {
            Bukkit.getScheduler().runTaskAsynchronously(instance, () -> saveOrigin(origin));
        }
        else
        {
            saveOrigin(origin);
        }
    }

    private void saveOrigin(Origin origin)
    {
        data.write(origin.getPlayerId().toString(), origin);
    }

    public Origin loadOrigin(UUID playerId)
    {
        return data.read(playerId.toString());
    }

    public <T extends Origin> T loadOrigin(UUID playerId, Class<T> clazz)
    {
        Origin origin = loadOrigin(playerId);
        if (clazz.isInstance(origin))
        {
            return clazz.cast(origin);
        }

        return null;
    }

    public void loadOrigin(UUID playerId, Consumer<Origin> callback)
    {
        Bukkit.getScheduler().runTaskAsynchronously(instance, () ->
        {
            callback.accept(loadOrigin(playerId));
        });
    }

    public <T extends Origin> void loadOrigin(UUID playerId, Class<T> clazz, Consumer<T> callback)
    {
        Bukkit.getScheduler().runTaskAsynchronously(instance, () ->
        {
            callback.accept(loadOrigin(playerId, clazz));
        });
    }

    public void deleteOrigin(Origin origin)
    {
        Bukkit.getScheduler().runTaskAsynchronously(instance, () ->
        {
            data.delete(origin.getPlayerId().toString());
        });
    }

    public void removeOrigin(UUID playerId)
    {
        origins.remove(playerId);
    }

    public <T extends Origin> T getOrigin(UUID playerId, Class<T> clazz)
    {
        Origin origin = origins.get(playerId);
        if (clazz.isInstance(origin))
        {
            return clazz.cast(origin);
        }

        return null;
    }

    public <T extends Origin> void getOrigin(UUID playerId, Class<T> clazz, Consumer<T> callback)
    {
        T origin = getOrigin(playerId, clazz);
        if (origin != null)
        {
            callback.accept(origin);
        }
        else
        {
            loadOrigin(playerId, clazz, callback);
        }
    }

    public <T extends Origin> Set<T> getOrigins(Class<T> clazz)
    {
        Set<T> origins = new HashSet<>();
        for (Origin origin : this.origins.values())
        {
            if (clazz.isInstance(origin))
            {
                origins.add(clazz.cast(origin));
            }
        }

        return origins;
    }

    public <T extends Origin> void getOfflineOrigins(Class<T> clazz, Consumer<Set<T>> callback)
    {
        Set<T> origins = new HashSet<>();
        for (Origin origin : this.data.all())
        {
            if (clazz.isInstance(origin) && getOrigin(origin.getPlayerId(), clazz) == null)
            {
                origins.add(clazz.cast(origin));
            }
        }

        callback.accept(origins);
    }

    public <T extends Origin> void getAllOrigins(Class<T> clazz, Consumer<Set<T>> callback)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
        {
            Set<T> origins = new HashSet<>(getOrigins(clazz));
            for (Origin origin : data.all())
            {
                if (clazz.isInstance(origin) && origin.getPlayer() == null)
                {
                    origins.add(clazz.cast(origin));
                }
            }

            callback.accept(origins);
        });
    }

    public <T extends Origin> void getOrLoadOrigin(UUID playerId, Class<T> clazz, Consumer<T> callback)
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
        {
            T origin = getOrigin(playerId, clazz);
            if (origin == null)
            {
                for (Origin offline : data.all())
                {
                    if (clazz.isInstance(offline) && offline.getPlayer() == null)
                    {
                        origin = clazz.cast(offline);
                    }
                }
            }

            callback.accept(origin);
        });
    }

    public <T extends Origin> void getOrLoadOrigin(String playerName, Class<T> clazz, Consumer<T> callback)
    {
        getAllOrigins(clazz, (all) ->
        {
            for (Origin offline : all)
            {
                if (playerName.equals(offline.getName()) && clazz.isInstance(offline))
                {
                    callback.accept(clazz.cast(offline));
                    return;
                }
            }
        });
    }

    /*
     * Group functions
     */
    public void updateOrigins(boolean async)
    {
        if (async)
        {
            Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
            {
                for (Origin origin : getOrigins(Origin.class))
                {
                    saveOrigin(origin, false);
                }
            });
        }
        else
        {
            for (Origin origin : getOrigins(Origin.class))
            {
                saveOrigin(origin, false);
            }
        }
    }

    public void clearOrigins()
    {
        origins.clear();
    }

    public void setSpawn(Race race, Location location)
    {
        spawns.put(race, location);
        storage.writeAsync(race, location);
    }
    
    public Location getSpawn(Race race)
    {
        return spawns.get(race);
    }

    public void loadSpawns(boolean async)
    {
       if (async)
       {
           Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
           {
               for (Race race : Race.values())
               {
                   Location spawn = storage.read(race);
                   if (spawn != null)
                   {
                       spawns.put(race, spawn);
                   }
               }
           });
       }
       else
       {
           for (Race race : Race.values())
           {
               Location spawn = storage.read(race);
               if (spawn != null)
               {
                   spawns.put(race, spawn);
               }
           }
       }
    }

    public void saveSpawn(Race race)
    {
        Location location = spawns.get(race);
        if (location != null)
        {
            storage.writeAsync(race, location);
        }
    }

    public void saveSpawns(boolean async)
    {
        if (async)
        {
            Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), () ->
            {
                for (Race race : Race.values())
                {
                    Location spawn = spawns.get(race);
                    if (spawn != null)
                    {
                        storage.write(race, spawn);
                    }
                }
            });
        }
        else
        {
            for (Race race : Race.values())
            {
                Location spawn = spawns.get(race);
                if (spawn != null)
                {
                    storage.write(race, spawn);
                }
            }
        }
    }
}
