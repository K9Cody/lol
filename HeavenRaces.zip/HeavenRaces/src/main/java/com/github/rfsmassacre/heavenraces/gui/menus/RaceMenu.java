package com.github.rfsmassacre.heavenraces.gui.menus;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Icon;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Menu;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.events.RaceChangeEvent;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.*;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;

public class RaceMenu extends Menu
{
    private final PaperLocale locale;
    private final RaceManager races;

    public RaceMenu()
    {
        super("&0Choose Your Race", 3, 1);

        this.locale = HeavenRaces.getInstance().getLocale();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    public ClanMenu getClanMenu()
    {
        return new ClanMenu();
    }

    public RankMenu getRankMenu(Origin.Race race)
    {
        return new RankMenu(race);
    }

    @Override
    public void updateIcons(Player player)
    {
        addIcon(new RaceIcon(3, 2, Origin.Race.HUMAN, "&bHuman", Material.IRON_SWORD));
        addIcon(new RaceIcon(4, 2, Origin.Race.VAMPIRE, "&cVampire", Material.GHAST_TEAR));
        addIcon(new RaceIcon(5, 2, Origin.Race.WEREWOLF, "&6Werewolf", Material.RABBIT_FOOT));
        addIcon(new RaceIcon(6, 2, Origin.Race.ANGEL, "&fAngel" ,Material.FEATHER));
        addIcon(new RaceIcon(7, 2, Origin.Race.DEMON, "&7Demon" ,Material.WITHER_SKELETON_SKULL));
    }

    private class RaceIcon extends Icon
    {
        private final Origin.Race race;

        public RaceIcon(int x, int y, Origin.Race race, String displayName, Material material)
        {
            super(x, y, 1, false, material, displayName, new ArrayList<>());

            this.race = race;
        }

        @Override
        public void onClick(Player player)
        {
            Origin origin = null;
            RaceChangeEvent event = new RaceChangeEvent(origin, race);
            switch (race)
            {
                case HUMAN -> origin = new Human(player);
                case VAMPIRE -> origin = new Vampire(player);
                case WEREWOLF ->
                {
                    ClanMenu clanMenu = getClanMenu();
                    Menu.addView(player.getUniqueId(), clanMenu);
                    player.openInventory(clanMenu.createInventory(player));
                    return;
                }
                case ANGEL, DEMON ->
                {
                    RankMenu rankMenu = getRankMenu(race);
                    Menu.addView(player.getUniqueId(), rankMenu);
                    player.openInventory(rankMenu.createInventory(player));
                    return;
                }
            }

            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                return;
            }

            races.addOrigin(origin);
            races.saveOrigin(origin, true);
            locale.sendLocale(player, "race.change.self", "{race}",
                    LocaleData.capitalize(race.toString()));
            player.closeInventory();
        }
    }

    public class ClanMenu extends Menu
    {
        public ClanMenu()
        {
            super("&0Choose Your Clan", 3, 1);
        }

        @Override
        public void updateIcons(Player player)
        {
            addIcon(new ClanIcon(3, 2, Material.LEATHER_BOOTS, "&6Witherfang",
                    Werewolf.Clan.WITHERFANG));
            addIcon(new ClanIcon(5, 2, Material.DIAMOND_CHESTPLATE, "&dSilvermane",
                    Werewolf.Clan.SILVERMANE));
            addIcon(new ClanIcon(7, 2, Material.NETHERITE_AXE, "&cBloodmoon",
                    Werewolf.Clan.BLOODMOON));
        }

        private class ClanIcon extends Icon
        {
            private final Werewolf.Clan clan;

            public ClanIcon(int x, int y, Material material, String displayName, Werewolf.Clan clan)
            {
                super(x, y, 1, false, material, displayName, new ArrayList<>());

                this.clan = clan;
            }

            @Override
            public void onClick(Player player)
            {
                Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
                if (origin == null)
                {
                    return;
                }

                RaceChangeEvent event = new RaceChangeEvent(origin, Origin.Race.WEREWOLF);
                Bukkit.getPluginManager().callEvent(event);
                if (event.isCancelled())
                {
                    return;
                }

                Werewolf werewolf = new Werewolf(player, clan);
                races.addOrigin(werewolf);
                races.saveOrigin(werewolf, true);
                locale.sendLocale(player, "race.change.self", "{race}",
                        LocaleData.capitalize(Origin.Race.WEREWOLF.toString()));
                player.closeInventory();
            }
        }
    }

    public class RankMenu extends Menu
    {
        private final Origin.Race race;

        public RankMenu(Origin.Race race)
        {
            super("&0Choose Your Rank", 3, 1);

            this.race = race;
        }

        @Override
        public void updateIcons(Player player)
        {
            addIcon(new RankIcon(3, 2, Material.POTION, "&dSeraph", Spirit.Rank.SERAPH));
            addIcon(new RankIcon(4, 2, Material.DIAMOND_SWORD, "&6Cherub", Spirit.Rank.CHERUB));
            addIcon(new RankIcon(5, 2, Material.SPYGLASS, "&cPower", Spirit.Rank.POWER));
            addIcon(new RankIcon(6, 2, Material.GRASS_BLOCK, "&aVirtue", Spirit.Rank.VIRTUE));
            addIcon(new RankIcon(7, 2, Material.BELL, "&eDominion", Spirit.Rank.DOMINION));
        }

        private class RankIcon extends Icon
        {
            private final Spirit.Rank rank;

            public RankIcon(int x, int y, Material material, String displayName, Spirit.Rank rank)
            {
                super(x, y, 1, false, material, displayName, new ArrayList<>());

                this.rank = rank;
            }

            @Override
            public void onClick(Player player)
            {
                Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
                if (origin == null)
                {
                    return;
                }

                RaceChangeEvent event = new RaceChangeEvent(origin, race);
                Bukkit.getPluginManager().callEvent(event);
                if (event.isCancelled())
                {
                    return;
                }

                Spirit spirit = null;
                switch (race)
                {
                    case ANGEL -> spirit = new Angel(player, rank);
                    case DEMON -> spirit = new Demon(player, rank);
                }

                if (spirit == null)
                {
                    player.closeInventory();
                    return;
                }

                races.addOrigin(spirit);
                races.saveOrigin(spirit, true);
                locale.sendLocale(player, "race.change.self", "{race}",
                        LocaleData.capitalize(race.toString()));
                player.closeInventory();
            }
        }
    }
}
