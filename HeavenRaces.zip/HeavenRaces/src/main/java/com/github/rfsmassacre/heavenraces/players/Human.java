package com.github.rfsmassacre.heavenraces.players;

import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Getter
@Setter
public class Human extends Origin
{
    public enum Ordainment
    {
        PRIEST,
        HUNTER,
        CIVILIAN
    }

    @Getter
    public static class Infection
    {
        private final Race race;
        private final UUID infectorId;
        private Clan clan;

        @Setter
        private double progress;

        public Infection(Race race, double progress)
        {
            this(race, null, progress);
        }

        public Infection(Race race, UUID infectorId, double progress)
        {
            this.race = race;
            this.infectorId = infectorId;
            if (race.equals(Race.WEREWOLF))
            {
                this.clan = Clan.WITHERFANG;
            }

            this.progress = progress;
        }

        public Infection(Clan clan, double progress)
        {
            this(clan, null, progress);
        }

        public Infection(Clan clan, UUID infectorId, double progress)
        {
            this.race = Race.WEREWOLF;
            this.infectorId = infectorId;
            this.clan = clan;
            this.progress = progress;
        }

        public void addProgress(double progress)
        {
            this.progress += progress;
        }
        public void removeProgress(double progress)
        {
            this.progress -= progress;
        }
    }

    private static final Map<UUID, UUID> TARGETS = new HashMap<>();

    public static Map<UUID, UUID> getTargets()
    {
        return TARGETS;
    }

    public static void setTarget(UUID hunterId, UUID victimId)
    {
        TARGETS.put(hunterId, victimId);
    }

    public static UUID getTarget(UUID hunterId)
    {
        return TARGETS.get(hunterId);
    }

    public static void removeTarget(UUID hunterId)
    {
        TARGETS.remove(hunterId);
    }

    public void clearTargets()
    {
        TARGETS.clear();
    }

    private Infection infection;
    private Ordainment ordainment;

    public Human()
    {
        super();

        this.race = Race.HUMAN;
        this.ordainment = Ordainment.CIVILIAN;
    }

    public Human(Player player)
    {
        super(player, Race.HUMAN);

    }
    public Human(Origin origin)
    {
        super(origin);

        this.race = Race.HUMAN;
        this.ordainment = Ordainment.CIVILIAN;
    }

    @Override
    public void updateStats()
    {
        clearStats();
    }

    @Override
    public boolean isAbilityActive()
    {
        return false;
    }

    /*
     * GETTERS/SETTERS
     */
    public boolean isInfected()
    {
        if (infection != null && infection.getProgress() <= 0.0)
        {
            infection = null;
        }

        return infection != null;
    }
    public void cure()
    {
        this.infection = null;
    }

    public void addInfectionRate(double rate)
    {
        infection.addProgress(rate);
    }

    public void removeInfectionRate(double rate)
    {
        infection.removeProgress(rate);
    }

    public void setInfectionRate(double rate)
    {
        infection.setProgress(rate);
    }

    public double getInfectionRate(Race race)
    {
        if (infection != null && infection.getRace().equals(race))
        {
            return infection.getProgress();
        }

        return 0.0;
    }

    public double getInfectionRate()
    {
        if (infection != null)
        {
            return infection.getProgress();
        }

        return 0.0;
    }

    /*
     * To String
     */
    @Override
    public String toString()
    {
        String info = " ";
        info += "\n\n&7" + playerId.toString();
        info += "\n&f" + displayName + "\n ";
        info += "\n&cInfection: " + infection.getRace().toString() + " | %" + (int)infection.getProgress();
        info += "\n&eOrdainment: " + ordainment.toString();
        return info;
    }
}
