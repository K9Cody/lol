package com.github.rfsmassacre.heavenraces;

import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.UUID;

public class HeavenRacesAPI
{
    public static void teleportToSpawn(Player player)
    {
        HeavenRaces instance = HeavenRaces.getInstance();
        if (instance == null)
        {
            return;
        }

        RaceManager races = instance.getRaceManager();
        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        Location spawn = races.getSpawn(origin.getRace());
        if (spawn != null)
        {
            player.teleport(spawn);
        }
    }

    public static String getRace(UUID playerId)
    {
        HeavenRaces instance = HeavenRaces.getInstance();
        if (instance == null)
        {
            return null;
        }

        RaceManager races = instance.getRaceManager();
        Origin origin = races.getOrigin(playerId, Origin.class);
        if (origin == null)
        {
            return null;
        }

        return origin.getRace().toString();
    }
}
