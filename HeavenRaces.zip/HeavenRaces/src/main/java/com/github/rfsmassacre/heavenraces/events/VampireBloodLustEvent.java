package com.github.rfsmassacre.heavenraces.events;

import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import com.github.rfsmassacre.heavenraces.players.Vampire;

public class VampireBloodLustEvent extends Event implements Cancellable
{
    private static final HandlerList HANDLERS = new HandlerList();

    @Override
    public @NotNull HandlerList getHandlers()
    {
        return HANDLERS;
    }
    public static HandlerList getHandlerList()
    {
        return HANDLERS;
    }

    /*
     * Event Info
     */
    private final Vampire vampire;
    private final boolean toggle;
    private boolean cancel;

    public VampireBloodLustEvent(Vampire vampire, boolean toggle)
    {
        this.vampire = vampire;
        this.toggle = toggle;
        this.cancel = false;
    }

    public Vampire getVampire()
    {
        return vampire;
    }
    public boolean isToggled()
    {
        return toggle;
    }

    @Override
    public boolean isCancelled()
    {
        return cancel;
    }
    @Override
    public void setCancelled(boolean cancel)
    {
        this.cancel = cancel;
    }
}
