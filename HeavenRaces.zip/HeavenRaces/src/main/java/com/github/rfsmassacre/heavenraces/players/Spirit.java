package com.github.rfsmassacre.heavenraces.players;

import lombok.Getter;
import lombok.Setter;
import org.bukkit.entity.Player;

@Getter
@Setter
public abstract class Spirit extends Origin
{
    public enum Rank
    {
        CHERUB,
        SERAPH,
        VIRTUE,
        DOMINION,
        POWER;

        public static Rank fromString(String name)
        {
            try
            {
                return Rank.valueOf(name.toUpperCase());
            }
            catch (IllegalArgumentException exception)
            {
                return null;
            }
        }
    }

    protected Rank rank;
    protected boolean spiritForm;
    protected double stamina;

    public Spirit()
    {
        super();
    }

    public Spirit(Player player, Race race, Rank rank)
    {
        super(player, race);

        this.rank = rank;
    }

    public Spirit(Origin origin, Race race, Rank rank)
    {
        super(origin);

        this.race = race;
        this.rank = rank;
    }

    public void setStamina(double stamina)
    {
        this.stamina = Math.max(0.0, Math.min(stamina, 1.0));
    }

    public void addStamina(double stamina)
    {
        setStamina(this.stamina + stamina);
    }
}
