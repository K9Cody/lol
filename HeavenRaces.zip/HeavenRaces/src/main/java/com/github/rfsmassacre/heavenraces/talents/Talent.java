package com.github.rfsmassacre.heavenraces.talents;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.HeavenRaces.ConfigType;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import lombok.AccessLevel;
import lombok.Getter;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

@Getter
public class Talent implements Listener
{
    private static final LinkedHashMap<String, Talent> TALENTS = new LinkedHashMap<>();

    public static void reloadData()
    {
        TALENTS.clear();
        PaperConfiguration config = HeavenRaces.getInstance().getConfiguration(ConfigType.TALENTS);
        for (String internalName : config.getKeys(false))
        {
            add(new Talent(internalName));
        }
    }

    public static Talent get(String internalName)
    {
        return TALENTS.get(internalName);
    }

    public static Set<Talent> get(Race race)
    {
        Set<Talent> talents = new HashSet<>();
        for (Talent talent : all())
        {
            if (talent.race.equals(race))
            {
                talents.add(talent);
            }
        }

        return talents;
    }

    public static Set<Talent> get(Race race, int tier)
    {
        Set<Talent> talents = new HashSet<>();
        for (Talent talent : all())
        {
            if (talent.race.equals(race) && talent.tier == tier)
            {
                talents.add(talent);
            }
        }

        return talents;
    }

    public static void add(Talent talent)
    {
        TALENTS.put(talent.internalName, talent);
    }

    public static void remove(Talent talent)
    {
        TALENTS.remove(talent.internalName);
    }

    public static Set<Talent> all()
    {
        return new HashSet<>(TALENTS.values());
    }

    @Getter(AccessLevel.NONE)
    protected final PaperConfiguration config;
    private final String internalName;
    private final String name;
    private final Race race;
    private final int level;
    private final int tier;
    private final Material material;
    private final List<String> lore;

    public Talent(String internalName)
    {
        this.config = HeavenRaces.getInstance().getConfiguration(ConfigType.TALENTS);
        this.internalName = internalName;
        this.name = config.getString(getKey("name"));
        this.race = Race.fromString(config.getString(getKey("race")));
        this.level = config.getInt(getKey("level"));
        this.tier = config.getInt(getKey("tier"));
        this.material = Material.valueOf(config.getString(getKey("material")));
        this.lore = config.getStringList(getKey("lore"));
    }

    public boolean isRace(Origin origin)
    {
        return origin.getRace().equals(race);
    }

    public boolean isLeveled(Origin origin)
    {
        return origin.getLevel() >= level;
    }

    public String getString(String key)
    {
        return config.getString(getKey(key));
    }

    public int getInt(String key)
    {
        return config.getInt(getKey(key));
    }

    public double getDouble(String key)
    {
        return config.getDouble(getKey(key));
    }

    protected String getKey(String key)
    {
        return internalName + "." + key;
    }

    public ItemStack getItem()
    {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(LocaleData.format(name)));
        List<Component> loreComponents = new ArrayList<>();
        for (String line : lore)
        {
            loreComponents.add(Component.text(LocaleData.format(line)));
        }

        meta.lore(loreComponents);
        item.setItemMeta(meta);
        return item;
    }
}
