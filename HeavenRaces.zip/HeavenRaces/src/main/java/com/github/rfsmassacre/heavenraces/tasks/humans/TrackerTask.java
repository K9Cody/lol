package com.github.rfsmassacre.heavenraces.tasks.humans;

import com.github.rfsmassacre.heavenclans.HeavenClansAPI;
import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.items.trackers.TrackerItem;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.utils.SunUtil;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

public class TrackerTask extends BukkitRunnable
{
    private final PaperLocale locale;
    private final RaceManager races;

    public TrackerTask()
    {
        this.locale = HeavenRaces.getInstance().getLocale();
        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @Override
    public void run()
    {
        Map<UUID, UUID> targets = Human.getTargets();
        Iterator<Entry<UUID, UUID>> iterator = targets.entrySet().iterator();
        while (iterator.hasNext())
        {
            Entry<UUID, UUID> entry = iterator.next();
            Origin raceHunter = races.getOrigin(entry.getKey(), Origin.class);
            Origin raceVictim = races.getOrigin(entry.getValue(), Origin.class);
            if (raceHunter == null || raceVictim == null)
            {
                iterator.remove();
                continue;
            }

            if (!(raceHunter instanceof Human human) || raceVictim instanceof Human)
            {
                iterator.remove();
                continue;
            }

            if (HeavenClansAPI.isPeaceful(entry.getValue()))
            {
                iterator.remove();
                continue;
            }

            Player hunter = human.getPlayer();
            Player victim = raceVictim.getPlayer();
            double range = HeavenRaces.getInstance().getConfiguration().getDouble("human.trackers.range");
            double distance = hunter.getLocation().distance(victim.getLocation());
            ItemStack item = hunter.getInventory().getItemInMainHand();
            TrackerItem tracker = TrackerItem.getFromItem(item);
            if (tracker == null)
            {
                continue;
            }

            World hunterWorld = hunter.getLocation().getWorld();
            if (hunterWorld == null)
            {
                continue;
            }

            switch (tracker.getRace())
            {
                case Race.VAMPIRE ->
                {
                    Talent vampirePursuit = human.getTalent("VampirePursuit");
                    if (vampirePursuit != null)
                    {
                        double percent = vampirePursuit.getDouble("percent");
                        range *= percent;
                    }
                }
                case Race.WEREWOLF ->
                {
                    Talent werewolfPursuit = human.getTalent("WerewolfPursuit");
                    if (werewolfPursuit != null)
                    {
                        double percent = werewolfPursuit.getDouble("percent");
                        range *= percent;
                    }
                }
                case Race.DEMON ->
                {
                    Talent demonPursuit = human.getTalent("DemonPursuit");
                    if (demonPursuit != null)
                    {
                        double percent = demonPursuit.getDouble("percent");
                        range *= percent;
                    }
                }
            }

            if (!hunter.getWorld().equals(victim.getWorld()))
            {
                locale.sendLocale(hunter, true, "human.trackers.lost");
                iterator.remove();
                continue;
            }

            if (hunterWorld.equals(victim.getWorld()) && range <= distance)
            {
                if (SunUtil.inGodModeRegion(victim))
                {
                    locale.sendLocale(hunter, true, "human.trackers.lost");
                    iterator.remove();
                    continue;
                }
            }
            else
            {
                locale.sendLocale(hunter, true, "human.trackers.lost");
                iterator.remove();
                continue;
            }

            //If no coal, skip
            PlayerInventory inventory = hunter.getInventory();
            if (!inventory.contains(Material.COAL) && !inventory.contains(Material.CHARCOAL))
            {
                locale.sendLocale(hunter, true, "human.trackers.lost");
                iterator.remove();
                continue;
            }

            for (ItemStack fuel : inventory.getContents())
            {
                if (fuel == null)
                {
                    continue;
                }

                if (!fuel.getType().equals(Material.COAL) && !fuel.getType().equals(Material.CHARCOAL))
                {
                    continue;
                }

                fuel.setAmount(Math.max(0, fuel.getAmount() - 1));
                break;
            }

            //If all passes, update tracker position
            hunter.setCompassTarget(victim.getLocation());
            locale.sendActionLocale(hunter, false, "human.trackers.action", "{race}",
                    LocaleData.capitalize(raceVictim.getRace().toString()), "{player}", victim.getDisplayName(),
                    "{distance}", Integer.toString((int) distance));
        }
    }
}
