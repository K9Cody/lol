package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.managers.TextManager;
import com.github.rfsmassacre.heavenlibrary.paper.commands.PaperCommand;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.google.common.collect.Lists;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HumanCommand extends PaperCommand
{
    private final TextManager text;
    private final RaceManager races;
    private final LeaderManager leaders;

    public HumanCommand()
    {
        super(HeavenRaces.getInstance(), "human");

        HeavenRaces instance = HeavenRaces.getInstance();
        this.text = instance.getTextManager();
        this.races = instance.getRaceManager();
        this.leaders = instance.getLeaderManager();
    }

    /*
     * Human main command
     */
    private class InfoCommand extends PaperSubCommand
    {
        public InfoCommand()
        {
            super("info", "heavenraces.human.info");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            Human human = races.getOrigin(player.getUniqueId(), Human.class);
            if (human == null)
            {
                locale.sendLocale(player, true, "invalid.not-human");
                return;
            }

            locale.sendMessage(player, RaceCommand.getMenu(human));
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    private class ListCommand extends PaperSubCommand
    {
        public ListCommand()
        {
            super("list", "heavenraces.human.list");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            if (!(sender instanceof Player player))
            {
                locale.sendLocale(sender, true, "invalid.console");
                return;
            }

            int pageNumber = 1;
            if (args.length > 1)
            {
                try
                {
                    pageNumber = Integer.parseInt(args[1]);
                }
                catch (NumberFormatException exception)
                {
                    //Do nothing
                }
            }

            final int finalPageNumber = pageNumber;
            Human human = races.getOrigin(player.getUniqueId(), Human.class);
            if (human == null)
            {
                locale.sendLocale(player, true, "invalid.not-human");
                return;
            }

            locale.sendLocale(player, true, "admin.request");

            races.getAllOrigins(Human.class, (humanSet) ->
            {
                List<Human> humans = new ArrayList<>(humanSet);
                humans.sort(Comparator.reverseOrder());
                List<List<Human>> pages = Lists.partition(humans, 6);
                int pageMax = pages.size();
                int page = finalPageNumber;
                if (page < 1)
                {
                    page = 1;
                }
                if (page > pageMax)
                {
                    page = pageMax;
                }

                String leaderName = "&7N/A";
                Leader leader = leaders.getLeader(Race.HUMAN);
                if (leader != null)
                {
                    Human master = races.getOrigin(leader.getLeaderId(), Human.class);
                    if (master == null)
                    {
                        master = races.loadOrigin(leader.getLeaderId(), Human.class);
                    }

                    if (master != null)
                    {
                        leaderName = master.getDisplayName();
                    }
                }

                if (leaderName == null)
                {
                    leaderName = "&7N/A";
                }


                List<String> lines = text.getText("list.txt");
                String menu = String.join("\n", lines);
                menu = menu.replace("{race}", "&f&lHuman&r");
                menu = menu.replace("{page}", Integer.toString(page));
                menu = menu.replace("{pageMax}", Integer.toString(pageMax));
                menu = menu.replace("{leaderTitle}", "&e&lMaster&f");
                menu = menu.replace("{leader}", leaderName);

                List<Human> topHumans = pages.get(page - 1);
                List<String> infoList = new ArrayList<>();
                for (Human top : topHumans)
                {
                    String line = " &b#";
                    for (int place = 0; place < humans.size(); place++)
                    {
                        Human runner = humans.get(place);
                        if (runner.getPlayerId().equals(top.getPlayerId()))
                        {
                            line += place + 1;
                            break;
                        }
                    }

                    line += " &f" + top.getDisplayName() + " &7(&eLVL " + String.format("%.2f", top.getLevel()) + "&7)";
                    infoList.add(line);
                }

                if (infoList.size() < 6)
                {
                    for (int remaining = 6 - infoList.size(); remaining > 0; remaining--)
                    {
                        infoList.add("&f");
                    }
                }

                String info = String.join("\n", infoList);
                menu = menu.replace("{players}", info);
                locale.sendMessage(player, menu);
            });
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }

    /*
     * Human help command
     */
    private class HelpCommand extends PaperSubCommand
    {
        public HelpCommand()
        {
            super("help", "heavenraces.human.help");
        }

        @Override
        protected void onRun(CommandSender sender, String[] args)
        {
            List<String> lines = text.getText("human-help1.txt");
            String menu = String.join("\n", lines);
            locale.sendMessage(sender, menu);
        }

        @Override
        public List<String> onTabComplete(CommandSender sender, String[] args)
        {
            return Collections.emptyList();
        }
    }
}
