package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.players.Vampire;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public class VampireFoodEvent extends Event implements Cancellable
{
    public enum VampireAction
    {
        ATTACK,
        ANIMAL_BOTTLE,
        VAMPIRE_BOTTLE,
        HUMAN_BOTTLE
    }

    private static final HandlerList HANDLERS = new HandlerList();

    @Override
    @NotNull
    public HandlerList getHandlers()
    {
        return HANDLERS;
    }
    public static HandlerList getHandlerList()
    {
        return HANDLERS;
    }

    @Getter
    private final Vampire vampire;
    @Getter
    @Setter
    private double food;
    @Getter
    private final VampireAction action;
    private boolean cancel;

    public VampireFoodEvent(Vampire vampire, double food, VampireAction action)
    {
        this.vampire = vampire;
        this.food = food;
        this.action = action;
        this.cancel = false;
    }

    @Override
    public boolean isCancelled()
    {
        return cancel;
    }

    @Override
    public void setCancelled(boolean cancel)
    {
        this.cancel = cancel;
    }
}
