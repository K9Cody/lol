package com.github.rfsmassacre.heavenraces.tasks.werewolves;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import org.bukkit.*;
import org.bukkit.Particle.DustOptions;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BlockIterator;
import org.bukkit.util.Vector;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Werewolf;

import java.util.UUID;

public class ScentTask extends BukkitRunnable
{
    private final PaperConfiguration config;
    private final RaceManager races;
    private final int range;
    private final double yOffset;
    private final Particle particle;
    private final int amount;
    private final double far;
    private final double medium;
    private final double close;

    public ScentTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
        this.range = config.getInt("werewolf.tracking.range");
        this.yOffset = config.getDouble("werewolf.tracking.y-offset");
        this.particle = Particle.valueOf(config.getString("werewolf.tracking.particle"));
        this.amount = config.getInt("werewolf.tracking.particle-amount");
        this.far = config.getDouble("werewolf.tracking.distances.far");
        this.medium = config.getDouble("werewolf.tracking.distances.medium");
        this.close = config.getDouble("werewolf.tracking.distances.close");
    }

    public void run()
    {
        for (Werewolf werewolf : races.getOrigins(Werewolf.class))
        {
            Player player = werewolf.getPlayer();
            if (player == null)
            {
                continue;
            }

            if (!werewolf.isTracking())
            {
                continue;
            }
            else
            {
                int level = config.getInt("level-reward.werewolf.scent");
                if (werewolf.getLevel() < level)
                {
                    werewolf.setTracking(false);
                    werewolf.setTrackerId(null);
                    return;
                }
            }

            UUID targetId = werewolf.getTrackerId();
            if (targetId == null)
            {
                continue;
            }
            Player target = Bukkit.getPlayer(targetId);
            if (target == null)
            {
                continue;
            }
            if (!player.getWorld().equals(target.getWorld()))
            {
                continue;
            }

            World world = player.getWorld();
            Vector start = player.getLocation().toVector();
            double distance = player.getLocation().distance(target.getLocation());
            Color color;
            if (distance >= far)
            {
                color = Color.fromRGB(128, 128, 128);
            }
            else if (distance >= medium)
            {
                color = Color.fromRGB(0, 128, 0);
            }
            else if (distance >= close)
            {
                color = Color.fromRGB(128, 128, 0);
            }
            else
            {
                color = Color.fromRGB(128, 0, 0);
            }

            int line = (int) player.getLocation().distance(target.getLocation());
            Vector direction = target.getLocation().toVector().subtract(start);
            direction = direction.setY(0);
            if (direction.length() < 2)
            {
                continue;
            }

            BlockIterator iterator = new BlockIterator(world, start, direction, yOffset, Math.min(line, range));
            while (iterator.hasNext())
            {
                Block block = iterator.next();
                Location location = block.getLocation();
                DustOptions options = new DustOptions(color, 1.0F);
                player.spawnParticle(particle, location, amount, 0.25, 0, 0.25, options);
            }
        }
    }
}