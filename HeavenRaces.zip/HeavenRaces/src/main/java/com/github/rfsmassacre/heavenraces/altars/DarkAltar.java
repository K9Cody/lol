/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.LightningStrike
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package com.github.rfsmassacre.heavenraces.altars;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Human;
import com.github.rfsmassacre.heavenraces.players.Human.Infection;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.utils.ConfigUtil;
import com.github.rfsmassacre.heavenraces.utils.FXUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class DarkAltar extends Altar
{
    public DarkAltar(HeavenRaces instance)
    {
        super(instance);
        this.name = config.getString("altars.dark.name");
        this.description = config.getString("altars.dark.description");
        this.core = Material.valueOf(config.getString("altars.dark.core"));
        this.materials = ConfigUtil.getMaterialInteger(config, "altars.dark.materials");
        this.resources = ConfigUtil.getMaterialInteger(config, "altars.dark.resources");
    }

    @Override
    public void use(Origin origin)
    {
        Player player = origin.getPlayer();
        if (origin instanceof Human human)
        {
            if (playerHasResources(player, resources))
            {
                if (human.isInfected())
                {
                    locale.sendLocale(player, true, "infection.not-healthy");
                    return;
                }

                double amount = config.getDouble("infection.altar");
                Infection infection = new Infection(Race.VAMPIRE, amount);
                human.setInfection(infection);
                locale.sendLocale(player, true, "infection.vampire.start.altar");

                player.getWorld().strikeLightningEffect(player.getLocation());
                player.sendHurtAnimation(0);

                playerResourceUse(player, resources);
                return;
            }

            locale.sendLocale(player, true, "altars.missing-resources", "{list}",
                    convertToString(resources));
            return;
        }

        locale.sendMessage(player, true, this.description);
        FXUtil.smokeBurst(player, this.config.getInt("vampire.effects.smoke-burst"));
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
    }
}

