package com.github.rfsmassacre.heavenraces.events;


import com.github.rfsmassacre.heavenraces.spells.Spell;
import lombok.Getter;
import org.bukkit.entity.LivingEntity;

@Getter
public class SpellTargetEvent extends SpellEvent
{
    private final LivingEntity target;

    public SpellTargetEvent(LivingEntity caster, Spell spell, LivingEntity target)
    {
        super(caster, spell);

        this.target = target;
    }
}
