package com.github.rfsmassacre.heavenraces.utils;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class ConfigUtil
{
    public static HashMap<Material, Integer> getMaterialInteger(PaperConfiguration config, String key)
    {
        HashMap<Material, Integer> materials = new HashMap<Material, Integer>();
        List<String> strings = config.getStringList(key);
        for (String string : strings)
        {
            String[] parts = string.split(":");
            Material material = Material.valueOf(parts[0]);
            int amount = Integer.parseInt(parts[1]);
            materials.put(material, amount);
        }
        return materials;
    }

    public static HashMap<Material, Double> getMaterialDouble(PaperConfiguration config, String key)
    {
        HashMap<Material, Double> materials = new HashMap<Material, Double>();
        List<String> strings = config.getStringList(key);
        for (String string : strings)
        {
            String[] parts = string.split(":");
            Material material = Material.valueOf(parts[0]);
            double amount = Double.parseDouble(parts[1]);
            materials.put(material, amount);
        }

        return materials;
    }

    public static ArrayList<ItemStack> getItemStackList(PaperConfiguration config, String key)
    {
        ArrayList<ItemStack> items = new ArrayList<ItemStack>();
        List<String> strings = config.getStringList(key);
        for (String string : strings)
        {
            String[] parts = string.split(":");
            int amount = Integer.parseInt(parts[1]);
            if (parts[0].equalsIgnoreCase("WATER_BOTTLE"))
            {
                ItemStack waterBottle = new ItemStack(Material.POTION);
                PotionMeta meta = (PotionMeta)waterBottle.getItemMeta();
                meta.clearCustomEffects();
                meta.setBasePotionType(PotionType.WATER);
                waterBottle.setItemMeta(meta);
                items.add(waterBottle);
                continue;
            }

            Material material = Material.valueOf(parts[0]);
            items.add(new ItemStack(material, amount));
        }
        return items;
    }

    public static HashSet<Material> getMaterialSet(PaperConfiguration config, String key)
    {
        HashSet<Material> materials = new HashSet<Material>();
        List<String> strings = config.getStringList(key);
        for (String string : strings)
        {
            String[] parts = string.split(":");
            Material material = Material.valueOf(parts[0]);
            materials.add(material);
        }

        return materials;
    }

    public static HashSet<PotionEffect> getPotionEffects(PaperConfiguration config, String key)
    {
        HashSet<PotionEffect> potionEffects = new HashSet<PotionEffect>();
        ConfigurationSection section = config.getSection(key);
        for (String innerKey : section.getKeys(false))
        {
            NamespacedKey namespace = NamespacedKey.fromString(innerKey);
            if (namespace == null)
            {
                continue;
            }

            PotionEffectType effectType = Registry.POTION_EFFECT_TYPE.get(namespace);
            int duration = config.getInt(key + "." + innerKey + ".duration");
            int strength = config.getInt(key + "." + innerKey + ".strength");
            if (effectType == null || duration < -1)
            {
                continue;
            }

            PotionEffect potionEffect = new PotionEffect(effectType, duration, strength);
            potionEffects.add(potionEffect);
        }

        return potionEffects;
    }
}
