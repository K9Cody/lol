package com.github.rfsmassacre.heavenraces.managers;

import com.github.rfsmassacre.heavenraces.moons.Moon;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.World.Environment;

import java.util.Collection;
import java.util.HashMap;

public class MoonManager
{
    private final HashMap<World, Moon> moons;

    public MoonManager()
    {
        this.moons = new HashMap<>();

        reloadMoons();
    }

    public void reloadMoons()
    {
        moons.clear();
        for (World world : Bukkit.getWorlds())
        {
            if (world.getEnvironment().equals(Environment.NORMAL))
            {
                moons.put(world, new Moon(world));
            }
        }
    }

    public Moon getMoon(World world)
    {
        return moons.get(world);
    }

    public Collection<Moon> getMoons()
    {
        return moons.values();
    }
}
