package com.github.rfsmassacre.heavenraces.items.potions;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import org.bukkit.Color;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class AnimalBloodBottle extends PotionItem
{
    private final NamespacedKey key;

    public AnimalBloodBottle(ItemStack item)
    {
        super("AnimalBloodBottle", Color.RED);

        this.item = item;
        this.key = new NamespacedKey(HeavenRaces.getInstance(), "BID");
    }
    public AnimalBloodBottle(EntityType type, int food)
    {
        super("AnimalBloodBottle", Color.RED);

        this.key = new NamespacedKey(HeavenRaces.getInstance(), "BID");

        //Set food level and blood type in name.
        setNBT(key, Integer.toString(food));


        //Set blood type in lore.
        ItemMeta meta = item.getItemMeta();
        if (meta == null)
        {
            return;
        }

        meta.setMaxStackSize(8);
        item.setItemMeta(meta);
        String displayName = meta.getDisplayName();
        List<String> lore = meta.getLore();
        setDisplayName(displayName.replace("{mob}", LocaleData.capitalize(type.toString())));

        if (lore != null)
        {
            for (int index = 0; index < lore.size(); index++)
            {
                lore.set(index, lore.get(index).replace("{mob}", LocaleData.capitalize(type.toString())));
            }
        }

        setItemLore(lore);
    }
    public AnimalBloodBottle()
    {
        this(EntityType.VILLAGER, 20);
    }

    @Override
    protected Recipe createRecipe()
    {
        return null;
    }

    public int getFoodPoints()
    {
        return Integer.parseInt(getNBT(key));
    }
}
