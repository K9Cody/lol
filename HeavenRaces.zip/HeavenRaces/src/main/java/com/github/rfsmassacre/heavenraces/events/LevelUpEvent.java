package com.github.rfsmassacre.heavenraces.events;

import com.github.rfsmassacre.heavenraces.players.Origin;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

@Getter
@Setter
public class LevelUpEvent extends Event
{
    private static final HandlerList HANDLERS = new HandlerList();

    @Override
    public @NotNull HandlerList getHandlers()
    {
        return HANDLERS;
    }
    public static HandlerList getHandlerList()
    {
        return HANDLERS;
    }

    private final Origin origin;
    private int newLevel;

    public LevelUpEvent(Origin origin, int newLevel)
    {
        this.origin = origin;
        this.newLevel = newLevel;
    }
}
