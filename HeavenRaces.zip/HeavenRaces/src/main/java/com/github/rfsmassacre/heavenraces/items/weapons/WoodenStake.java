package com.github.rfsmassacre.heavenraces.items.weapons;

import com.github.rfsmassacre.heavenraces.items.RaceItem;
import lombok.Getter;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

@Getter
public class WoodenStake extends RaceItem
{
    public static WoodenStake of(ItemStack item)
    {
        WoodenStake woodenStake = new WoodenStake(item.getItemMeta());
        if (woodenStake.equals(item))
        {
            return woodenStake;
        }

        return null;
    }

    private final ItemMeta itemMeta;

    public WoodenStake()
    {
        this(null);
    }

    public WoodenStake(ItemMeta itemMeta)
    {
        super("WoodenStake", Material.WOODEN_SWORD);

        this.itemMeta = itemMeta;
    }

    @Override
    public ItemStack getItemStack()
    {
        if (itemMeta == null)
        {
            return item;
        }

        ItemMeta meta = item.getItemMeta();
        if (item.getItemMeta() == null)
        {
            return item;
        }

        itemMeta.setCustomModelData(meta.getCustomModelData());
        itemMeta.displayName(meta.displayName());
        List<Component> newLore = meta.lore();
        if (newLore != null)
        {
            List<Component> oldLore = itemMeta.lore();
            if (oldLore == null)
            {
                oldLore = new ArrayList<>();
            }

            newLore.addAll(oldLore);
        }

        itemMeta.lore(newLore);
        item.setItemMeta(itemMeta);
        this.setNBT(key, name);
        return item;
    }

    @Override
    protected Recipe createRecipe()
    {
        ShapedRecipe recipe = new ShapedRecipe(this.key, this.getItemStack());
        recipe.shape("ABA", "BWB", "ABA");
        recipe.setIngredient('B', Material.BLAZE_POWDER);
        recipe.setIngredient('W', Material.WOODEN_SWORD);
        return recipe;
    }
}
