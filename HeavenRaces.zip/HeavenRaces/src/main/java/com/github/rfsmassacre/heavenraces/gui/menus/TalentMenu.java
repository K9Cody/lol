package com.github.rfsmassacre.heavenraces.gui.menus;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Menu;
import com.github.rfsmassacre.heavenlibrary.paper.menu.PageIcon;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;

public class TalentMenu extends Menu
{
    @Getter
    private static class Cooldown
    {
        private final String internalName;
        @Setter
        private long time;

        public Cooldown(String internalName)
        {
            this.internalName = internalName;
            this.time = System.currentTimeMillis();
        }
    }

    private final PaperLocale locale;
    private final Origin origin;

    public TalentMenu(Origin origin, int page)
    {
        super("", 6, page);

        this.locale = HeavenRaces.getInstance().getLocale();
        String raceName = LocaleData.capitalize(origin.getRace().toString());
        this.title = LocaleData.format(raceName + " Talents");
        this.origin = origin;
    }

    @Override
    public void updateIcons(Player player)
    {
        if (origin.getRace().equals(Race.VAMPIRE))
        {
            addIcon(new TalentIcon("Siphon", 2, 2));
            addIcon(new TalentIcon("GluttonousDiet", 5, 2));
            addIcon(new TalentIcon("HealthyDiet", 8, 2));

            addIcon(new TalentIcon("Apathy", 2, 3));
            addIcon(new TalentIcon("LastWill", 5, 3));
            addIcon(new TalentIcon("NoFear", 8, 3));

            addIcon(new TalentIcon("ShadowsCall", 2, 4));
            addIcon(new TalentIcon("Insatiable", 5, 4));
            addIcon(new TalentIcon("Composure", 8, 4));

            addIcon(new TalentIcon("Daywalker", 2, 5));
            addIcon(new TalentIcon("StrongWings", 5, 5));
            addIcon(new TalentIcon("EvilPresence", 8, 5));
        }
        else if (origin.getRace().equals(Race.WEREWOLF))
        {
            addIcon(new TalentIcon("Satisfied", 2, 2));
            addIcon(new TalentIcon("Omnivore", 5, 2));
            addIcon(new TalentIcon("Nourishment", 8, 2));

            addIcon(new TalentIcon("IronWill", 2, 3));
            addIcon(new TalentIcon("ThickSkin", 5, 3));
            addIcon(new TalentIcon("SwiftFeet", 8, 3));

            addIcon(new TalentIcon("Beastmaster", 2, 4));
            addIcon(new TalentIcon("Shredder", 5, 4));
            addIcon(new TalentIcon("Relentless", 8, 4));

            addIcon(new TalentIcon("Rabies", 2, 5));
            addIcon(new TalentIcon("Amplify", 5, 5));
            addIcon(new TalentIcon("Disable", 8, 5));
        }
        else
        {
            addIcon(new TalentIcon("VampirePursuit", 2, 2));
            addIcon(new TalentIcon("WerewolfPursuit", 5, 2));
            addIcon(new TalentIcon("DemonPursuit", 8, 2));

            addIcon(new TalentIcon("VampireSlayer", 2, 3));
            addIcon(new TalentIcon("WerewolfSlayer", 5, 3));
            addIcon(new TalentIcon("DemonSlayer", 8, 3));

            addIcon(new TalentIcon("HolyArmor", 2, 4));
            addIcon(new TalentIcon("RazorResistance", 5, 4));
            addIcon(new TalentIcon("Radiance", 8, 4));

            addIcon(new TalentIcon("Executioner", 2, 5));
            addIcon(new TalentIcon("GuardianAngel", 5, 5));
            addIcon(new TalentIcon("Fortify", 8, 5));
        }

        addIcon(new ResetIcon(5, 6));
    }

    private class TalentIcon extends PageIcon
    {
        private final Talent talent;

        public TalentIcon(String internalName, int x, int y)
        {
            super(x, y, internalName, new ConfirmMenu(origin, internalName));

            this.talent = Talent.get(internalName);
            this.displayName = LocaleData.format(talent.getName());
            this.material = talent.getMaterial();
            this.glowing = origin.hasTalent(talent);
            setLore(talent.getLore());
        }

        @Override
        public void onClick(Player clicker)
        {
            if (origin.hasTalent(talent))
            {
                locale.sendLocale(clicker, "talent.already-have");
            }
            else if (!talent.isLeveled(origin))
            {
                locale.sendLocale(clicker, "talent.confirm.not-leveled", "{level}",
                        Integer.toString(talent.getLevel()));
            }
            else if (sameTier(origin, talent))
            {
                locale.sendLocale(clicker, "talent.confirm.same-tier", "{tier}",
                        Integer.toString(talent.getTier()));
            }
            else
            {
                Menu.addView(clicker.getUniqueId(), menu);
                clicker.openInventory(menu.createInventory(clicker));
            }
        }
    }

    private boolean sameTier(Origin origin, Talent talent)
    {
        for (Talent other : Talent.all())
        {
            if (origin.hasTalent(other) && talent.getTier() == other.getTier())
            {
                return true;
            }
        }

        return false;
    }

    private class ResetIcon extends PageIcon
    {
        public ResetIcon(int x, int y)
        {
            super(x, y, "&fReset Talents", Material.WIND_CHARGE, new ConfirmResetMenu(origin));

            setLore(List.of(
                    "",
                    " &7Resetting your talents will cost you ",
                    " &710% of your current levels... Choose ",
                    " &7wisely...",
                    ""));
        }
    }
}
