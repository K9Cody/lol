package com.github.rfsmassacre.heavenraces.items.trackers;

import lombok.Getter;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;

@Getter
public abstract class TrackerItem extends RaceItem
{
    private final Race race;

    public TrackerItem(String name, Race race)
    {
        super(name, Material.COMPASS);

        this.race = race;
    }

    public static TrackerItem getFromItem(ItemStack item)
    {
        VampireTracker vampireTracker = new VampireTracker();
        if (vampireTracker.equals(item))
        {
            return vampireTracker;
        }

        WerewolfTracker werewolfTracker = new WerewolfTracker();
        if (werewolfTracker.equals(item))
        {
            return werewolfTracker;
        }



        return null;
    }
}
