package com.github.rfsmassacre.heavenraces.managers;

import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.data.LeaderGsonManager;
import com.github.rfsmassacre.heavenraces.events.LeaderEvent;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Werewolf;
import com.github.rfsmassacre.heavenraces.players.Werewolf.Clan;
import lombok.Getter;
import org.bukkit.Bukkit;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class LeaderManager
{
    @Getter
    private final Set<Leader> leaders;
    private final LeaderGsonManager gson;

    public LeaderManager()
    {
        this.leaders = new HashSet<>();
        this.gson = new LeaderGsonManager();
    }

    public void loadLeaders()
    {
        this.leaders.clear();
        this.leaders.addAll(gson.all());
    }
    public void loadLeadersAsync()
    {
        gson.allAsync((leaders) ->
        {
            this.leaders.clear();
            this.leaders.addAll(leaders);
        });
    }
    public void saveLeaders()
    {
        for (Leader leader : leaders)
        {
            gson.write(leader);
        }
    }
    public void saveLeadersAsync()
    {
        Bukkit.getScheduler().runTaskAsynchronously(HeavenRaces.getInstance(), this::saveLeaders);
    }

    public void saveLeader(Leader leader)
    {
        gson.write(leader);
    }
    public void saveLeaderAsync(Leader leader)
    {
        gson.writeAsync(leader);
    }
    public Leader getLeader(Race race)
    {
        for (Leader leader : leaders)
        {
            if (race.equals(leader.getRace()))
            {
                return leader;
            }
        }

        return null;
    }
    public Leader getLeader(Clan clan)
    {
        for (Leader leader : leaders)
        {
            if (leader != null && leader.getRace().equals(Race.WEREWOLF) && clan.equals(leader.getClan()))
            {
                return leader;
            }
        }

        return null;
    }

    public void setLeader(Leader leader)
    {
        for (Leader oldLeader : new HashSet<>(leaders))
        {
            if (oldLeader == null || !oldLeader.getRace().equals(leader.getRace()))
            {
                continue;
            }

            if (leader.getRace().equals(Race.WEREWOLF))
            {
                if (oldLeader.getClan().equals(leader.getClan()))
                {
                    Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
                    {
                        LeaderEvent event = new LeaderEvent(oldLeader, true);
                        Bukkit.getPluginManager().callEvent(event);
                        if (!event.isCancelled())
                        {
                            leaders.remove(oldLeader);
                            deleteLeader(oldLeader);
                        }
                    });

                    break;
                }
            }

            Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
            {
                LeaderEvent event = new LeaderEvent(oldLeader, true);
                Bukkit.getPluginManager().callEvent(event);
                if (!event.isCancelled())
                {
                    leaders.remove(oldLeader);
                }
            });
        }

        leaders.add(leader);
        saveLeaderAsync(leader);
    }

    public void setLeader(Origin origin)
    {
        UUID playerId = origin.getPlayerId();
        Race race = origin.getRace();
        Leader oldLeader = null;
        Leader leader = new Leader(playerId, race);
        switch (race)
        {
            case HUMAN, VAMPIRE -> oldLeader = getLeader(race);
            case WEREWOLF ->
            {
                Werewolf werewolf = (Werewolf) origin;
                Clan clan = werewolf.getClan();
                oldLeader = getLeader(clan);
                leader = new Leader(playerId, clan);
            }
        }

        if (oldLeader != null)
        {
            leaders.remove(oldLeader);
            deleteLeader(oldLeader);
        }

        Leader finalOldLeader = oldLeader;
        Leader finalLeader = leader;
        Bukkit.getScheduler().scheduleSyncDelayedTask(HeavenRaces.getInstance(), () ->
        {
            LeaderEvent event = new LeaderEvent(finalOldLeader, true);
            Bukkit.getPluginManager().callEvent(event);
            if (!event.isCancelled())
            {
                leaders.add(finalLeader);
                saveLeaderAsync(finalLeader);
            }
        });
    }

    public void removeLeader(Leader leader)
    {
        this.leaders.remove(leader);
    }

    public void deleteLeader(Leader leader)
    {
        gson.delete(leader);
    }
    public void deleteLeaderAsync(Leader leader)
    {
        gson.deleteAsync(leader);
    }
}
