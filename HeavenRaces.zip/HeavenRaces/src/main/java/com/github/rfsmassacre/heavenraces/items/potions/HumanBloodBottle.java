package com.github.rfsmassacre.heavenraces.items.potions;

import lombok.Getter;
import org.bukkit.Color;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

@Getter
public class HumanBloodBottle extends PotionItem
{
    private static final NamespacedKey KEY = new NamespacedKey("heavenraces", "human");
    private UUID humanId;

    public HumanBloodBottle()
    {
        this((UUID) null);
    }

    public HumanBloodBottle(UUID humanId)
    {
        super("HumanBloodBottle", Color.RED);

        this.humanId = humanId;
        if (humanId != null)
        {
            setNBT(KEY, humanId.toString());
        }

        ItemMeta meta = item.getItemMeta();
        if (meta != null)
        {
            meta.setMaxStackSize(8);
            item.setItemMeta(meta);
        }
    }

    public HumanBloodBottle(ItemStack bottle)
    {
        this((UUID) null);

       String stringId = bottle.getPersistentDataContainer().get(KEY, PersistentDataType.STRING);
       if (stringId != null)
       {
           this.humanId = UUID.fromString(stringId);
           setNBT(KEY, stringId);
       }
    }

    @Override
    protected Recipe createRecipe()
    {
        return null;
    }
}
