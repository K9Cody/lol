package com.github.rfsmassacre.heavenraces.utils;

import org.bukkit.Material;

import java.util.HashMap;

public class FoodUtil
{
    public static final int MAX_FOOD = 20;
    private final static HashMap<Material, Integer> FOOD_LEVELS = new HashMap<>();
    private final static HashMap<Material, Float> SATURATION_LEVELS = new HashMap<>();

    static
    {
        FOOD_LEVELS.put(Material.APPLE, 4);
        FOOD_LEVELS.put(Material.BAKED_POTATO, 5);
        FOOD_LEVELS.put(Material.BEETROOT, 1);
        FOOD_LEVELS.put(Material.BEETROOT_SOUP, 6);
        FOOD_LEVELS.put(Material.BREAD, 5);
        FOOD_LEVELS.put(Material.CARROT, 3);
        FOOD_LEVELS.put(Material.CHORUS_FRUIT, 4);
        FOOD_LEVELS.put(Material.COOKED_BEEF, 8);
        FOOD_LEVELS.put(Material.COOKED_CHICKEN, 6);
        FOOD_LEVELS.put(Material.COOKED_COD, 5);
        FOOD_LEVELS.put(Material.COOKED_MUTTON, 6);
        FOOD_LEVELS.put(Material.COOKED_PORKCHOP, 8);
        FOOD_LEVELS.put(Material.COOKED_RABBIT, 5);
        FOOD_LEVELS.put(Material.COOKED_SALMON, 6);
        FOOD_LEVELS.put(Material.COOKIE, 4);
        FOOD_LEVELS.put(Material.DRIED_KELP, 1);
        FOOD_LEVELS.put(Material.GOLDEN_APPLE, 4);
        FOOD_LEVELS.put(Material.ENCHANTED_GOLDEN_APPLE, 4);
        FOOD_LEVELS.put(Material.GOLDEN_CARROT, 6);
        FOOD_LEVELS.put(Material.MELON_SLICE, 2);
        FOOD_LEVELS.put(Material.MUSHROOM_STEW, 6);
        FOOD_LEVELS.put(Material.POISONOUS_POTATO, 2);
        FOOD_LEVELS.put(Material.POTATO, 1);
        FOOD_LEVELS.put(Material.PUFFERFISH, 1);
        FOOD_LEVELS.put(Material.PUMPKIN_PIE, 8);
        FOOD_LEVELS.put(Material.RABBIT_STEW, 10);
        FOOD_LEVELS.put(Material.BEEF, 3);
        FOOD_LEVELS.put(Material.CHICKEN, 2);
        FOOD_LEVELS.put(Material.COD, 2);
        FOOD_LEVELS.put(Material.MUTTON, 2);
        FOOD_LEVELS.put(Material.PORKCHOP, 3);
        FOOD_LEVELS.put(Material.RABBIT, 3);
        FOOD_LEVELS.put(Material.SALMON, 2);
        FOOD_LEVELS.put(Material.ROTTEN_FLESH, 4);
        FOOD_LEVELS.put(Material.SPIDER_EYE, 2);
        FOOD_LEVELS.put(Material.SUSPICIOUS_STEW, 6);
        FOOD_LEVELS.put(Material.SWEET_BERRIES, 2);
        FOOD_LEVELS.put(Material.TROPICAL_FISH, 1);
        FOOD_LEVELS.put(Material.GLOW_BERRIES, 2);
        FOOD_LEVELS.put(Material.HONEY_BOTTLE, 6);

        SATURATION_LEVELS.put(Material.APPLE, 2.4F);
        SATURATION_LEVELS.put(Material.BAKED_POTATO, 6.0F);
        SATURATION_LEVELS.put(Material.BEETROOT, 1.2F);
        SATURATION_LEVELS.put(Material.BEETROOT_SOUP, 7.2F);
        SATURATION_LEVELS.put(Material.BREAD, 6.0F);
        SATURATION_LEVELS.put(Material.CARROT, 3.6F);
        SATURATION_LEVELS.put(Material.CHORUS_FRUIT, 2.4F);
        SATURATION_LEVELS.put(Material.COOKED_BEEF, 12.8F);
        SATURATION_LEVELS.put(Material.COOKED_CHICKEN, 7.2F);
        SATURATION_LEVELS.put(Material.COOKED_COD, 6.0F);
        SATURATION_LEVELS.put(Material.COOKED_MUTTON, 9.6F);
        SATURATION_LEVELS.put(Material.COOKED_PORKCHOP, 12.8F);
        SATURATION_LEVELS.put(Material.COOKED_RABBIT, 6.0F);
        SATURATION_LEVELS.put(Material.COOKED_SALMON, 9.6F);
        SATURATION_LEVELS.put(Material.COOKIE, 0.4F);
        SATURATION_LEVELS.put(Material.DRIED_KELP, 0.6F);
        SATURATION_LEVELS.put(Material.GOLDEN_APPLE, 9.6F);
        SATURATION_LEVELS.put(Material.ENCHANTED_GOLDEN_APPLE, 9.6F);
        SATURATION_LEVELS.put(Material.GOLDEN_CARROT, 14.4F);
        SATURATION_LEVELS.put(Material.MELON_SLICE, 1.2F);
        SATURATION_LEVELS.put(Material.MUSHROOM_STEW, 7.2F);
        SATURATION_LEVELS.put(Material.POISONOUS_POTATO, 1.2F);
        SATURATION_LEVELS.put(Material.POTATO, 0.6F);
        SATURATION_LEVELS.put(Material.PUFFERFISH, 0.2F);
        SATURATION_LEVELS.put(Material.PUMPKIN_PIE, 4.8F);
        SATURATION_LEVELS.put(Material.RABBIT_STEW, 12.0F);
        SATURATION_LEVELS.put(Material.BEEF, 1.8F);
        SATURATION_LEVELS.put(Material.CHICKEN, 1.2F);
        SATURATION_LEVELS.put(Material.COD, 0.4F);
        SATURATION_LEVELS.put(Material.MUTTON, 1.2F);
        SATURATION_LEVELS.put(Material.PORKCHOP, 1.8F);
        SATURATION_LEVELS.put(Material.RABBIT, 1.8F);
        SATURATION_LEVELS.put(Material.SALMON, 0.4F);
        SATURATION_LEVELS.put(Material.ROTTEN_FLESH, 0.8F);
        SATURATION_LEVELS.put(Material.SPIDER_EYE, 3.2F);
        SATURATION_LEVELS.put(Material.SUSPICIOUS_STEW, 7.2F);
        SATURATION_LEVELS.put(Material.SWEET_BERRIES, 0.4F);
        SATURATION_LEVELS.put(Material.TROPICAL_FISH, 0.2F);
        SATURATION_LEVELS.put(Material.GLOW_BERRIES, 0.4F);
    }

    public static int getFoodLevel(Material material)
    {
        if (FOOD_LEVELS.containsKey(material))
        {
            return FOOD_LEVELS.get(material);
        }
        return 0;
    }
    public static float getSaturationLevel(Material material)
    {
        if (SATURATION_LEVELS.containsKey(material))
        {
            return SATURATION_LEVELS.get(material);
        }
        return 0.0F;
    }
}
