package com.github.rfsmassacre.heavenraces.gui.menus;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Icon;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Menu;
import com.github.rfsmassacre.heavenlibrary.paper.menu.PageIcon;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;

public class ConfirmResetMenu extends Menu
{
    private final PaperConfiguration config;
    private final PaperLocale locale;
    private final Origin origin;

    public ConfirmResetMenu(Origin origin)
    {
        super("&0Reset Talents?", 3, 1);

        this.config = HeavenRaces.getInstance().getConfiguration();
        this.locale = HeavenRaces.getInstance().getLocale();
        this.origin = origin;
    }

    @Override
    public void updateIcons(Player player)
    {
        addIcon(new YesIcon(2, 2));
        addIcon(new PageIcon(8, 2, "&cCancel", Material.RED_STAINED_GLASS_PANE,
                new TalentMenu(origin, 1)));
    }

    private class YesIcon extends Icon
    {
        public YesIcon(int x, int y)
        {
            super(x, y, 1, false, Material.GREEN_STAINED_GLASS_PANE, "&aConfirm",
                    new ArrayList<>());
        }

        @Override
        public void onClick(Player player)
        {
            origin.getTalentNames().clear();
            origin.setLevel(origin.getLevel() * config.getDouble("talent-reset-retain"));
            locale.sendLocale(player, "talent.clear.self", "{level}",
                    Integer.toString((int) origin.getLevel()));
            player.closeInventory();
        }
    }
}
