package com.github.rfsmassacre.heavenraces.worldmap;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import xyz.jpenilla.squaremap.api.*;
import xyz.jpenilla.squaremap.api.marker.Marker;
import xyz.jpenilla.squaremap.api.marker.MarkerOptions;

public class WorldMapUtil
{
    public static void registerSpawns()
    {
        if (!Bukkit.getPluginManager().isPluginEnabled("Squaremap"))
        {
            return;
        }

        for (Origin.Race race : Origin.Race.values())
        {
            Location spawn = HeavenRaces.getInstance().getRaceManager().getSpawn(race);
            if (spawn != null)
            {
                registerSpawn(race, spawn);
            }
        }
    }

    public static void registerSpawn(Origin.Race race, Location spawn)
    {
        if (!Bukkit.getPluginManager().isPluginEnabled("Squaremap"))
        {
            return;
        }

        Squaremap squaremap = SquaremapProvider.get();
        squaremap.getWorldIfEnabled(BukkitAdapter.worldIdentifier(spawn.getWorld())).ifPresent((mapWorld) ->
        {
            SimpleLayerProvider layer = SimpleLayerProvider.builder("Spawns")
                    .showControls(true)
                    .defaultHidden(false)
                    .build();
            World world = spawn.getWorld();
            if (world == null)
            {
                return;
            }

            Key layerKey = Key.of("heavenraces");
            if (mapWorld.layerRegistry().hasEntry(layerKey))
            {
                layer = (SimpleLayerProvider) mapWorld.layerRegistry().get(layerKey);
            }
            else
            {
                mapWorld.layerRegistry().register(layerKey, layer);
            }

            Key key = Key.of(race.toString().toLowerCase() + "_spawn");
            Marker marker = Marker.icon(Point.of(spawn.getBlockX(), spawn.getBlockZ()), Key.of("spawn"), 16);
            MarkerOptions.Builder options = MarkerOptions.builder()
                    .hoverTooltip(LocaleData.capitalize(race.toString()) + " Spawn");
            marker.markerOptions(options);
            layer.addMarker(key, marker);
        });
    }
}
