package com.github.rfsmassacre.heavenraces.commands;

import com.github.rfsmassacre.heavenlibrary.paper.commands.SimplePaperCommand;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.spells.Spell;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class KeybindCommand extends SimplePaperCommand
{
    private final RaceManager races;

    public KeybindCommand()
    {
        super(HeavenRaces.getInstance(), "keybind");

        this.races = HeavenRaces.getInstance().getRaceManager();
    }

    @Override
    protected void onRun(CommandSender sender, String... args)
    {
        //kit control <mode>
        if (!(sender instanceof Player player))
        {
            locale.sendLocale(sender, "commands.player-only");
            return;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return;
        }

        //kit spell <spell>
        if (args.length < 2)
        {
            onInvalidArgs(player, "<keybind>", "<ability>");
            return;
        }

        String keyName = args[0];
        String spellName = args[1];
        Origin.KeyBind keyBind = Origin.KeyBind.fromString(keyName.toUpperCase());
        if (keyBind == null)
        {
            locale.sendLocale(player, true, "spells.no-keybind", "{keybind}", keyName);
            return;
        }

        if (spellName.equalsIgnoreCase("none"))
        {
            origin.getSpells().remove(keyBind);
            locale.sendLocale(player, true, "spells.removed-keybind", "{keybind}",
                    keyBind.toString());
            races.saveOrigin(origin, true);
            return;
        }

        Spell spell = Spell.getSpell(spellName);
        if (spell == null)
        {
            locale.sendLocale(player, true, "spell.no-spell", "{spell}", spellName);
            return;
        }

        if (!spell.getRace().equals(origin.getRace()))
        {
            locale.sendLocale(player, "spell.wrong-race", "{spell}", spell.getDisplayName());
        }

        origin.getSpells().put(keyBind, spellName);
        races.saveOrigin(origin, true);
        locale.sendLocale(player, true, "spells.keybind", "{keybind}", keyBind.toString(),
                "{spell}", spell.getDisplayName());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, String... args)
    {
        List<String> suggestions = new ArrayList<>();
        if (!(sender instanceof Player player))
        {
            return suggestions;
        }

        Origin origin = races.getOrigin(player.getUniqueId(), Origin.class);
        if (origin == null)
        {
            return suggestions;
        }

        if (args.length == 1)
        {
            for (Origin.KeyBind keyBind : Origin.KeyBind.values())
            {
                suggestions.add(keyBind.toString());
            }
        }
        else if (args.length == 2)
        {
            suggestions.add("none");
            for (Spell spell : Spell.getSpells())
            {
                if (spell.getRace().equals(origin.getRace()))
                {
                    suggestions.add(spell.getInternalName());
                }
            }
        }

        return suggestions;
    }
}