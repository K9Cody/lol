package com.github.rfsmassacre.heavenraces.items;

import com.github.rfsmassacre.heavenlibrary.interfaces.LocaleData;
import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenlibrary.paper.items.HeavenItem;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.HeavenRaces.ConfigType;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;

public abstract class RaceItem extends HeavenItem
{
    public RaceItem(String name, Material material)
    {
        super(HeavenRaces.getInstance(), material, 1, name, name, new ArrayList<>());

        PaperConfiguration config = HeavenRaces.getInstance().getConfiguration(ConfigType.ITEMS);
        String displayName = config.getString(name.toUpperCase() + ".name");
        List<String> lore = config.getStringList(name.toUpperCase() + ".lore");
        int customModelData = config.getInt(name.toUpperCase() + ".custom-model-data");
        setCustomModelData(Math.max(customModelData, 0));
        this.setDisplayName(LocaleData.format(displayName));
        lore.replaceAll(LocaleData::format);
        this.defaultLore = lore;
        this.setItemLore(lore);
        this.recipe = this.createRecipe();
    }
}
