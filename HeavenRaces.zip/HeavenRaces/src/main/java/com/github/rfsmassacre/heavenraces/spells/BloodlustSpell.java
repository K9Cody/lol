package com.github.rfsmassacre.heavenraces.spells;

import com.github.rfsmassacre.heavenraces.events.VampireBloodLustEvent;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class BloodlustSpell extends Spell
{
    private final int cost;

    public BloodlustSpell()
    {
        super("blood-lust");

        this.cost = config.getInt(internalName + ".cost");
    }

    @Override
    public boolean activate(LivingEntity entity)
    {
        Vampire vampire = getOrigin(entity);
        Player player = vampire.getPlayer();
        if (vampire.inBloodLust())
        {
            VampireBloodLustEvent event = new VampireBloodLustEvent(vampire, false);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                locale.sendLocale(player, true, "vampire.blood-lust.cant-toggle");
                return false;
            }
        }
        else
        {
            if (player.getFoodLevel() <= cost)
            {
                locale.sendLocale(player, true, "vampire.blood-lust.no-food");
                return false;
            }

            VampireBloodLustEvent event = new VampireBloodLustEvent(vampire, true);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled())
            {
                locale.sendLocale(player, true, "vampire.blood-lust.cant-toggle");
                return false;
            }
            else if (!vampire.hasTalent("StrongWings"))
            {
                player.setFoodLevel(Math.max(0, player.getFoodLevel() - cost));
            }
        }

        return true;
    }
}
