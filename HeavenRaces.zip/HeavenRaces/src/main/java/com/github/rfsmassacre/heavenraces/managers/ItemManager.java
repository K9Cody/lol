package com.github.rfsmassacre.heavenraces.managers;

import com.github.rfsmassacre.heavenraces.items.Ash;
import com.github.rfsmassacre.heavenraces.items.RaceItem;
import com.github.rfsmassacre.heavenraces.items.armor.PurifiedArmor;
import com.github.rfsmassacre.heavenraces.items.armor.WashedArmor;
import com.github.rfsmassacre.heavenraces.items.food.GoldenFood;
import com.github.rfsmassacre.heavenraces.items.potions.*;
import com.github.rfsmassacre.heavenraces.items.trackers.VampireTracker;
import com.github.rfsmassacre.heavenraces.items.trackers.WerewolfTracker;
import com.github.rfsmassacre.heavenraces.items.weapons.SilverSword;
import com.github.rfsmassacre.heavenraces.items.weapons.WoodenStake;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class ItemManager
{
    private final Server server;
    private final HashMap<String, RaceItem> items;

    public ItemManager()
    {
        this.server = Bukkit.getServer();
        this.items = new HashMap<>();

        loadItems();
        loadRecipes();
    }

    public RaceItem getItem(String name)
    {
        return this.items.get(name);
    }
    public RaceItem getItem(ItemStack item)
    {
        if (item != null)
        {
            for (RaceItem raceItem : items.values())
            {
                if (raceItem.equals(item))
                {
                    return raceItem;
                }
            }
        }

        return null;
    }

    public Collection<String> getItemNames()
    {
        return items.keySet();
    }

    public void loadItems()
    {
        items.clear();
        addItem(new CurePotion());
        addItem(new InfectionPotion());
        addItem(new HumanBloodBottle());
        addItem(new AnimalBloodBottle());
        addItem(new VampireBloodBottle());
        addItem(new WerewolfTracker());
        addItem(new VampireTracker());
        addItem(new WolfsbanePotion());
        addItem(new SilverSword());
        addItem(new WoodenStake());
        addItem(new HolyWater());

        addItem(new WashedArmor(Material.LEATHER_HELMET));
        addItem(new WashedArmor(Material.LEATHER_CHESTPLATE));
        addItem(new WashedArmor(Material.LEATHER_LEGGINGS));
        addItem(new WashedArmor(Material.LEATHER_BOOTS));
        addItem(new WashedArmor(Material.GOLDEN_HELMET));
        addItem(new WashedArmor(Material.GOLDEN_CHESTPLATE));
        addItem(new WashedArmor(Material.GOLDEN_LEGGINGS));
        addItem(new WashedArmor(Material.GOLDEN_BOOTS));
        addItem(new WashedArmor(Material.CHAINMAIL_HELMET));
        addItem(new WashedArmor(Material.CHAINMAIL_CHESTPLATE));
        addItem(new WashedArmor(Material.CHAINMAIL_LEGGINGS));
        addItem(new WashedArmor(Material.CHAINMAIL_BOOTS));
        addItem(new WashedArmor(Material.IRON_HELMET));
        addItem(new WashedArmor(Material.IRON_CHESTPLATE));
        addItem(new WashedArmor(Material.IRON_LEGGINGS));
        addItem(new WashedArmor(Material.IRON_BOOTS));
        addItem(new WashedArmor(Material.DIAMOND_HELMET));
        addItem(new WashedArmor(Material.DIAMOND_CHESTPLATE));
        addItem(new WashedArmor(Material.DIAMOND_LEGGINGS));
        addItem(new WashedArmor(Material.DIAMOND_BOOTS));
        addItem(new WashedArmor(Material.NETHERITE_HELMET));
        addItem(new WashedArmor(Material.NETHERITE_CHESTPLATE));
        addItem(new WashedArmor(Material.NETHERITE_LEGGINGS));
        addItem(new WashedArmor(Material.NETHERITE_BOOTS));

        addItem(new PurifiedArmor(Material.LEATHER_HELMET));
        addItem(new PurifiedArmor(Material.LEATHER_CHESTPLATE));
        addItem(new PurifiedArmor(Material.LEATHER_LEGGINGS));
        addItem(new PurifiedArmor(Material.LEATHER_BOOTS));
        addItem(new PurifiedArmor(Material.GOLDEN_HELMET));
        addItem(new PurifiedArmor(Material.GOLDEN_CHESTPLATE));
        addItem(new PurifiedArmor(Material.GOLDEN_LEGGINGS));
        addItem(new PurifiedArmor(Material.GOLDEN_BOOTS));
        addItem(new PurifiedArmor(Material.CHAINMAIL_HELMET));
        addItem(new PurifiedArmor(Material.CHAINMAIL_CHESTPLATE));
        addItem(new PurifiedArmor(Material.CHAINMAIL_LEGGINGS));
        addItem(new PurifiedArmor(Material.CHAINMAIL_BOOTS));
        addItem(new PurifiedArmor(Material.IRON_HELMET));
        addItem(new PurifiedArmor(Material.IRON_CHESTPLATE));
        addItem(new PurifiedArmor(Material.IRON_LEGGINGS));
        addItem(new PurifiedArmor(Material.IRON_BOOTS));
        addItem(new PurifiedArmor(Material.DIAMOND_HELMET));
        addItem(new PurifiedArmor(Material.DIAMOND_CHESTPLATE));
        addItem(new PurifiedArmor(Material.DIAMOND_LEGGINGS));
        addItem(new PurifiedArmor(Material.DIAMOND_BOOTS));
        addItem(new PurifiedArmor(Material.NETHERITE_HELMET));
        addItem(new PurifiedArmor(Material.NETHERITE_CHESTPLATE));
        addItem(new PurifiedArmor(Material.NETHERITE_LEGGINGS));
        addItem(new PurifiedArmor(Material.NETHERITE_BOOTS));
        addItem(new GoldenFood(Material.COOKED_BEEF));
        addItem(new GoldenFood(Material.COOKED_CHICKEN));
        addItem(new GoldenFood(Material.COOKED_COD));
        addItem(new GoldenFood(Material.COOKED_MUTTON));
        addItem(new GoldenFood(Material.COOKED_PORKCHOP));
        addItem(new GoldenFood(Material.COOKED_RABBIT));
        addItem(new GoldenFood(Material.COOKED_SALMON));
        addItem(new Ash());
    }

    public void loadRecipes()
    {
        for (RaceItem item : items.values())
        {
            if (item.getRecipe() == null)
            {
                continue;
            }

            server.addRecipe(item.getRecipe());
        }
    }
    public void unloadRecipes()
    {
        Iterator<Recipe> iterator = server.recipeIterator();
        while (iterator.hasNext())
        {
            Recipe recipe = iterator.next();
            for (RaceItem item : items.values())
            {
                if (recipe != null && item.getRecipe() != null && item.equals(recipe.getResult()))
                {
                    iterator.remove();
                }
            }
        }
    }

    private void addItem(RaceItem item)
    {
        items.put(item.getName(), item);
    }
}
