package com.github.rfsmassacre.heavenraces.tasks.vampire;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperConfiguration;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.managers.LeaderManager;
import com.github.rfsmassacre.heavenraces.managers.RaceManager;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.players.Origin.Leader;
import com.github.rfsmassacre.heavenraces.players.Origin.Race;
import com.github.rfsmassacre.heavenraces.players.Vampire;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import com.github.rfsmassacre.heavenraces.utils.BossBarUtil;
import com.github.rfsmassacre.heavenraces.utils.ConfigUtil;
import com.github.rfsmassacre.heavenraces.utils.SunUtil;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.UUID;

public class TemperatureTask extends BukkitRunnable
{
    private static final String KEY = "vampire.temperature";

    private final PaperConfiguration config;
    private final RaceManager races;
    private final LeaderManager leaders;

    private final double armorPiece;
    private final double base;
    private final double up;
    private final double down;

    private final double burnStart;
    private final int burnDuration;
    private final HashSet<PotionEffect> radiationEffects;

    public TemperatureTask(HeavenRaces instance)
    {
        this.config = instance.getConfiguration();
        this.races = instance.getRaceManager();
        this.leaders = instance.getLeaderManager();

        this.armorPiece = config.getDouble("vampire.radiation.armor-piece");
        this.base = config.getDouble("vampire.radiation.base-temperature");
        this.up = config.getDouble("vampire.radiation.multiplier.up");
        this.down = config.getDouble("vampire.radiation.multiplier.down");

        this.burnStart = config.getDouble("vampire.radiation.burn.start");
        this.burnDuration = config.getInt("vampire.radiation.burn.duration");
        this.radiationEffects = ConfigUtil.getPotionEffects(config, "vampire.radiation.effects");
    }

    @Override
    public void run()
    {
        for (Origin origin : races.getOrigins(Origin.class))
        {
            if (!(origin instanceof Vampire vampire))
            {
                BossBarUtil.removeBossBar(KEY, origin.getPlayerId());
                continue;
            }

            Player player = vampire.getPlayer();
            if (player == null)
            {
                continue;
            }

            UUID playerId = player.getUniqueId();
            if (player.getGameMode().equals(GameMode.CREATIVE) || player.getGameMode().equals(GameMode.SPECTATOR))
            {
                vampire.setTemperature(0.0);
                BossBarUtil.removeBossBar(KEY, playerId);
                continue;
            }

            Leader elder = leaders.getLeader(Race.VAMPIRE);
            if (elder != null && elder.getLeaderId().equals(vampire.getPlayerId()))
            {
                vampire.setTemperature(0.0);
                BossBarUtil.removeBossBar(KEY, playerId);
                continue;
            }

            double radiation = SunUtil.getPlayerIrradiation(player, armorPiece, true) + base;
            Talent dayWalker = vampire.getTalent("Daywalker");
            double percent = 1.0;
            if (dayWalker != null)
            {
                percent = dayWalker.getDouble("percent");
            }

            //Radiation calculation
            if (radiation < 0.0)
            {
                vampire.addTemperature(radiation * down);
            }
            else
            {
                vampire.addTemperature(radiation * (up * percent));
            }

            //Radiation sickness
            for (PotionEffect effect : radiationEffects)
            {
                double start = config.getDouble("vampire.radiation.effects." +
                        effect.getType().getKey().getKey().toLowerCase() + ".start");

                if (vampire.getTemperature() >= start)
                {
                    player.addPotionEffect(effect);
                }
            }
            if (vampire.getTemperature() >= burnStart)
            {
                player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
                player.setFireTicks(burnDuration);
            }

            if (vampire.getTemperature() > 0)
            {
                BossBarUtil.updateBossBar(player, vampire.getTemperature(), KEY);
            }
            else
            {
                BossBarUtil.removeBossBar(KEY, playerId);
            }
        }
    }
}
