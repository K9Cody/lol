package com.github.rfsmassacre.heavenraces.gui.menus;

import com.github.rfsmassacre.heavenlibrary.paper.configs.PaperLocale;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Icon;
import com.github.rfsmassacre.heavenlibrary.paper.menu.Menu;
import com.github.rfsmassacre.heavenlibrary.paper.menu.PageIcon;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import com.github.rfsmassacre.heavenraces.talents.Talent;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Set;

public class ConfirmMenu extends Menu
{
    private final PaperLocale locale;
    private final Origin origin;
    private final Talent talent;

    public ConfirmMenu(Origin origin, String internalName)
    {
        super("", 3, 1);

        this.locale = HeavenRaces.getInstance().getLocale();
        this.origin = origin;
        this.talent = Talent.get(internalName);
    }

    @Override
    public void updateIcons(Player player)
    {
        addIcon(new YesIcon(2, 2));
        addIcon(new TalentIcon(5, 2));
        addIcon(new PageIcon(8, 2, "&cCancel", Material.RED_STAINED_GLASS_PANE,
                new TalentMenu(origin, 1)));
    }

    private class TalentIcon extends Icon
    {
        public TalentIcon(int x, int y)
        {
            super(x, y, 1, origin.hasTalent(talent.getInternalName()), talent.getMaterial(), talent.getName(),
                    talent.getLore());
        }

        @Override
        public void onClick(Player player)
        {
            //Do nothing
        }
    }

    private class YesIcon extends Icon
    {
        public YesIcon(int x, int y)
        {
            super(x, y, 1, false, Material.GREEN_STAINED_GLASS_PANE, "&aConfirm",
                    new ArrayList<>());
        }

        @Override
        public void onClick(Player player)
        {
            if (!origin.hasTalent(talent.getInternalName()))
            {
                Set<Talent> talents = Talent.all();
                for (Talent otherTalent : talents)
                {
                    if (!otherTalent.isRace(origin) || talent.getInternalName().equals(otherTalent.getInternalName()))
                    {
                        origin.removeTalent(otherTalent.getInternalName());
                        continue;
                    }

                    if (talent.getTier() == otherTalent.getTier())
                    {
                        origin.removeTalent(otherTalent.getInternalName());
                    }
                }

                origin.addTalent(talent);
                locale.sendLocale(player, "talent.confirm.self", "{talent}", talent.getName());
                Menu menu = new TalentMenu(origin, 1);
                Menu.addView(player.getUniqueId(), menu);
                player.openInventory(menu.createInventory(player));
            }
            else
            {
                locale.sendLocale(player, "talent.confirm.same-tier", "{tier}",
                        Integer.toString(talent.getTier()));
                player.closeInventory();
            }
        }
    }
}
