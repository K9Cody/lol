package com.github.rfsmassacre.heavenraces.data;

import com.github.rfsmassacre.heavenlibrary.paper.managers.PaperYamlStorage;
import com.github.rfsmassacre.heavenraces.HeavenRaces;
import com.github.rfsmassacre.heavenraces.players.Origin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.function.Consumer;

public class SpawnYamlStorage extends PaperYamlStorage<Location>
{
    public SpawnYamlStorage()
    {
        super(HeavenRaces.getInstance(), "spawns");
    }

    public Location read(Origin.Race race)
    {
        return read(race.toString().toLowerCase());
    }

    public void readAsync(Origin.Race race, Consumer<Location> callback)
    {
        readAsync(race.toString().toLowerCase(), callback);
    }

    public void write(Origin.Race race, Location location)
    {
        write(race.toString().toLowerCase(), location);
    }

    public void writeAsync(Origin.Race race, Location location)
    {
        writeAsync(race.toString().toLowerCase(), location);
    }

    @Override
    public Location load(YamlConfiguration yaml)
    {
        String worldName = yaml.getString("world");
        double x = yaml.getDouble("x");
        double y = yaml.getDouble("y");
        double z = yaml.getDouble("z");
        if (worldName != null)
        {
            World world = Bukkit.getWorld(worldName);
            if (world != null)
            {

                return new Location(world, x, y, z);
            }
        }

        return null;
    }

    @Override
    public YamlConfiguration save(Location location)
    {
        YamlConfiguration yaml = new YamlConfiguration();
        World world = location.getWorld();
        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();
        if (world != null)
        {
            yaml.set("world", world.getName());
            yaml.set("x", x);
            yaml.set("y", y);
            yaml.set("z", z);
        }

        return yaml;
    }
}
